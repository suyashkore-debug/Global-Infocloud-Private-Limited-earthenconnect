<?php

defined('BASEPATH') or exit('No direct script access allowed');

function app_init_admin_sidebar_menu_items()
{
    $CI = &get_instance();

   /* $CI->app_menu->add_sidebar_menu_item('dashboard', [
        'name'     => _l('als_dashboard'),
        'href'     => admin_url(),
        'position' => 1,
        'icon'     => 'fa fa-home',
    ]);*/
    
    
    $CI->app_menu->add_sidebar_menu_item('master', [
            'collapse' => true,
            'name'     => "Masters",
            'position' => 1,
            'icon'     => 'fa fa-balance-scale',
        ]);
    
    
    if (has_permission('customers', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'account-master',
                'name'     => 'Customer',
                'href'     => admin_url('clients'),
                'position' => 1,
        ]);
    }
    
    if (has_permission('ratemaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'rate_master',
                'name'     => 'Rate Master',
                'href'     => admin_url('rate_master'),
                'position' => 2,
        ]);
    }
    
    if (has_permission_new('account_head', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'accounts_master',
                'name'     => 'Accounts Head',
                'href'     => admin_url('accounts_master'),
                'position' => 3,
        ]);
    }
    
    if (has_permission_new('ratemaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'staff_master',
                'name'     => 'Other Staff Master',
                'href'     => admin_url('accounts_master/manage_staff'),
                'position' => 4,
        ]);
    }
    
    if (has_permission_new('routemaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'route_master',
                'name'     => 'Route Master',
                'href'     => admin_url('route_master'),
                'position' => 5,
        ]);
    }
    
    if (has_permission_new('vehiclemaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'vehicle_master',
                'name'     => 'Vehicle Master',
                'href'     => admin_url('vehicles'),
                'position' => 6,
        ]);
    }
    if (has_permission_new('hsnmaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'hsn_master',
                'name'     => 'HSN Master',
                'href'     => admin_url('hsn_master'),
                'position' => 7,
        ]);
    }
    
    if (has_permission('tcsmaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'tcs_master',
                'name'     => 'TCS Master',
                'href'     => admin_url('tcs_master'),
                'position' => 8,
        ]);
    }
            
    if (has_permission_new('items', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'items',
                'name'     => "Item Master",
                'href'     => admin_url('invoice_items'),
                'position' => 9,
        ]);
    }            
    
    if (has_permission_new('hierarchy', '', 'update')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'hierarchy',
                'name'     => 'Hierarchy',
                'href'     => admin_url('hierarchy'),
                'position' => 10,
        ]);
    }
    
    if (has_permission_new('salesperassign', '', 'update')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'company_assign',
                'name'     => 'Attach SalesTeam to Parties',
                'href'     => admin_url('company_assign'),
                'position' => 11,
        ]);
    }
    
    if (has_permission_new('enquiry', '', 'view') || has_permission_new('enquiry', '', 'view_own')) {
        $CI->app_menu->add_sidebar_children_item('master', [
            'name'     => _l('enquiry'),
            'href'     => admin_url('enquiry'),
            'position' => 12,
            'icon'     => 'fa fa-ticket',
        ]);
    }
    
    if (has_permission_new('tour', '', 'view') || has_permission_new('tour', '', 'view_own')) {
    
        $CI->app_menu->add_sidebar_children_item('master', [
            'name'     => _l('tour_plan'),
            'href'     => admin_url('tour'),
            'position' => 13,
            'icon'     => 'fa fa-ticket',
        ]);
    }
    
    /*if (has_permission('salesperassign', '', 'update')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'roles',
                'name'     => 'Role Authorization',
                'href'     => admin_url('roles'),
                'position' => 31,
        ]);
    }*/
    
    /*if (has_permission('salesperassign', '', 'update')) {
        $CI->app_menu->add_sidebar_children_item('master', [
                'slug'     => 'account_group_master',
                'name'     => 'Account Group',
                'href'     => admin_url('accounting/account_group_master'),
                'position' => 31,
        ]);
    }*/
    
    $CI->app_menu->add_sidebar_menu_item('tansaction', [
            'collapse' => true,
            'name'     => "Transactions",
            'position' => 2,
            'icon'     => 'fa fa-balance-scale',
        ]);
    
    if (has_permission_new('orders', '', 'create')) {
        $CI->app_menu->add_sidebar_children_item('tansaction', [
                'slug'     => 'orders',
                'name'     => 'Order',
                'href'     => admin_url('order'),
                'position' => 1,
        ]);
    }
    
    if (has_permission_new('orders', '', 'view') || has_permission_new('orders', '', 'view_own')) {
        $CI->app_menu->add_sidebar_children_item('tansaction', [
                'slug'     => 'orders-list',
                'name'     => 'Order List',
                'href'     => admin_url('order/list_orders'),
                'position' => 2,
        ]);
    }
    
    if (has_permission_new('challan', '', 'create')) {
        $CI->app_menu->add_sidebar_children_item('tansaction', [
                'slug'     => 'challan',
                'name'     => 'Challan',
                'href'     => admin_url('challan'),
                'position' => 3,
        ]);
    }
    
    if (has_permission_new('challan', '', 'view') || has_permission_new('challan', '', 'view_own')) {
        $CI->app_menu->add_sidebar_children_item('tansaction', [
                'slug'     => 'challan-list',
                'name'     => 'Challan List',
                'href'     => admin_url('challan/challan_list'),
                'position' => 4,
        ]);
    }
    
    if (has_permission_new('gatepass', '', 'view') || has_permission_new('gatepass', '', 'view_own')) {
        $CI->app_menu->add_sidebar_children_item('tansaction', [
                'slug'     => 'gatepass',
                'name'     => 'Gatepass',
                'href'     => admin_url('challan/view_gatepass'),
                'position' => 5,
        ]);
    }
    
    if (has_permission_new('orders', '', 'view') || has_permission_new('orders', '', 'view_own')) {
        $CI->app_menu->add_sidebar_children_item('tansaction', [
                'slug'     => 'pending-orders',
                'name'     => 'Pending Orders',
                'href'     => admin_url('order/pending_orders'),
                'position' => 6,
        ]);
    }
    
    if (has_permission_new('sale_return', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('tansaction', [
                'slug'     => 'sale_return',
                'name'     => 'Sales Return',
                'href'     => admin_url('sale_return'),
                'position' => 7,
        ]);
    }
    
    if (has_permission_new('cd_notes', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('tansaction', [
                'slug'     => 'cd_notes',
                'name'     => 'Credit/Debit Note',
                'href'     => admin_url('cd_notes'),
                'position' => 8,
        ]);
    }
    
    $CI->app_menu->add_sidebar_menu_item('pur-reports', [
            'collapse' => true,
            'name'     => "Pur. Reports",
            'position' => 3,
            'icon'     => 'fa fa-user-circle menu-icon',
    ]);
   
   $CI->app_menu->add_sidebar_children_item('pur-reports', [
                'slug'     => 'purchase-register',
                'name'     => 'Purchase Register',
                'href'     => '#',
                'position' => 1,
        ]);
    
    $CI->app_menu->add_sidebar_menu_item('e-filling', [
            'collapse' => true,
            'name'     => "E-Filling",
            'position' => 7,
            'icon'     => 'fa fa-user-circle menu-icon',
    ]);
   
   $CI->app_menu->add_sidebar_children_item('e-filling', [
                'slug'     => 'GSTR-purchase',
                'name'     => 'GSTR Purchase',
                'href'     => '#',
                'position' => 1,
        ]);
    $CI->app_menu->add_sidebar_children_item('e-filling', [
                'slug'     => 'GSTR-sales',
                'name'     => 'GSTR Sales',
                'href'     => '#',
                'position' => 2,
        ]);
    $CI->app_menu->add_sidebar_children_item('e-filling', [
                'slug'     => 'GGSTR-1',
                'name'     => 'GSTR-1',
                'href'     => '#',
                'position' => 3,
        ]);
    $CI->app_menu->add_sidebar_children_item('e-filling', [
                'slug'     => 'GSTR-3B',
                'name'     => 'GSTR-3B',
                'href'     => '#',
                'position' => 4,
        ]);
        
    
      /*if (has_permission('target', '', 'view') || has_permission('target', '', 'view_own')) {
        $CI->app_menu->add_sidebar_menu_item('target', [
            'name'     => _l('Target VS Achievement'),
            'href'     => admin_url('target'),
            'position' => 3,
            'icon'     => 'fa fa-ticket',
        ]);
    } */
    
    

    
    
    
       /* $CI->app_menu->add_sidebar_menu_item('production', [
            'collapse' => true,
            'name'     => "Production",
            'position' => 3,
            'icon'     => 'fa fa-balance-scale',
        ]);*/
    
    /*if (has_permission('ratemaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('production', [
                'slug'     => 'Add Recipe',
                'name'     => 'Add Recipe',
                'href'     => admin_url('production'),
                'position' => 1,
        ]);
    } 
  
  if (has_permission('ratemaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('production', [
                'slug'     => 'View Recipe',
                'name'     => 'View Recipe',
                'href'     => admin_url('production/all_recipe'),
                'position' => 2,
        ]);
    } 
  
  if (has_permission('ratemaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('production', [
                'slug'     => 'Create Production Order',
                'name'     => 'Create Production',
                'href'     => admin_url('production/create_order'),
                'position' => 3,
        ]);
    } 
  
  if (has_permission('ratemaster', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('production', [
                'slug'     => 'View Production Order',
                'name'     => 'View Production',
                'href'     => admin_url('production/view_Order'),
                'position' => 4,
        ]);
    } */
    
    $CI->app_menu->add_sidebar_menu_item('sales_report', [
            'collapse' => true,
            'name'     => "Sales Reports",
            'position' => 4,
            'icon'     => 'fa fa-balance-scale',
        ]);
    
    if (has_permission_new('daily_sale', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('sales_report', [
                'slug'     => 'daily-sale',
                'name'     => 'Daily Sales Report',
                'href'     => admin_url('Sale_reports/daily_sale'),
                'position' => 1,
        ]);
    }
    
    if (has_permission_new('cummulatives_sale', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('sales_report', [
                'slug'     => 'PartyPackWiseCummulativesSales',
                'name'     => 'Party PackWise Cummulatives Sales',
                'href'     => admin_url('Sale_reports/PartyPackWiseCummulativesSales'),
                'position' => 2,
        ]);
    }
    
    $CI->app_menu->add_sidebar_menu_item('Misc_Reports', [
            'collapse' => true,
            'name'     => "Misc. Reports",
            'position' => 5,
            'icon'     => 'fa fa-user-circle menu-icon',
    ]);
    
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'account-list',
                'name'     => 'Account List',
                'href'     => '#',
                'position' => 1,
        ]);
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'item-rate-list',
                'name'     => 'Item Rate List',
                'href'     => '#',
                'position' => 2,
        ]);
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'market-outstanding',
                'name'     => 'Market Outstanding',
                'href'     => '#',
                'position' => 3,
        ]);
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'crate-ledger',
                'name'     => 'Crate Ledger',
                'href'     => '#',
                'position' => 4,
        ]);
        
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'Crates-received-via-vehicle-return',
                'name'     => 'Crates received via Vehicle return',
                'href'     => '#',
                'position' => 5,
        ]);
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'routes-covered-during-a-period',
                'name'     => 'Routes Covered during a period',
                'href'     => '#',
                'position' => 6,
        ]);
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'vehicles-on-route-duty',
                'name'     => 'Vehicles on Route Duty',
                'href'     => '#',
                'position' => 7,
        ]);
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'vehicle-operation-during-a-month',
                'name'     => 'Vehicle Operation during a month',
                'href'     => '#',
                'position' => 8,
        ]);
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'contractor-production-report',
                'name'     => 'Contractor Production Report',
                'href'     => '#',
                'position' => 9,
        ]);
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'contractor-production-MTD',
                'name'     => 'Contractor Production - MTD',
                'href'     => '#',
                'position' => 10,
        ]);
    $CI->app_menu->add_sidebar_children_item('Misc_Reports', [
                'slug'     => 'stock-position',
                'name'     => 'Stock Position',
                'href'     => '#',
                'position' => 11,
        ]);

    /*if (has_permission('subscriptions', '', 'view') || has_permission('subscriptions', '', 'view_own')) {
        $CI->app_menu->add_sidebar_menu_item('subscriptions', [
                'name'     => _l('subscriptions'),
                'href'     => admin_url('subscriptions'),
                'icon'     => 'fa fa-repeat',
                'position' => 15,
        ]);
    }*/

    /*if (has_permission('expenses', '', 'view') || has_permission('expenses', '', 'view_own')) {
        $CI->app_menu->add_sidebar_menu_item('expenses', [
                'name'     => _l('expenses'),
                'href'     => admin_url('expenses'),
                'icon'     => 'fa fa-file-text-o',
                'position' => 20,
        ]);
    }*/

    /*if (has_permission('contracts', '', 'view') || has_permission('contracts', '', 'view_own')) {
        $CI->app_menu->add_sidebar_menu_item('contracts', [
                'name'     => _l('contracts'),
                'href'     => admin_url('contracts'),
                'icon'     => 'fa fa-file',
                'position' => 25,
        ]);
    }*/

    /*$CI->app_menu->add_sidebar_menu_item('projects', [
                'name'     => _l('projects'),
                'href'     => admin_url('projects'),
                'icon'     => 'fa fa-bars',
                'position' => 30,
        ]);*/

    /*$CI->app_menu->add_sidebar_menu_item('tasks', [
                'name'     => _l('als_tasks'),
                'href'     => admin_url('tasks'),
                'icon'     => 'fa fa-tasks',
                'position' => 35,
        ]);*/

    /*if ((!is_staff_member() && get_option('access_tickets_to_none_staff_members') == 1) || is_staff_member()) {
        $CI->app_menu->add_sidebar_menu_item('support', [
                'name'     => _l('support'),
                'href'     => admin_url('tickets'),
                'icon'     => 'fa fa-ticket',
                'position' => 40,
        ]);
    }*/

    /*if (is_staff_member()) {
        $CI->app_menu->add_sidebar_menu_item('leads', [
                'name'     => _l('als_leads'),
                'href'     => admin_url('leads'),
                'icon'     => 'fa fa-tty',
                'position' => 45,
        ]);
    }*/

    /*if (has_permission('knowledge_base', '', 'view')) {
        $CI->app_menu->add_sidebar_menu_item('knowledge-base', [
                'name'     => _l('als_kb'),
                'href'     => admin_url('knowledge_base'),
                'icon'     => 'fa fa-folder-open-o',
                'position' => 50,
        ]);
    }*/

    // Utilities
    /*$CI->app_menu->add_sidebar_menu_item('utilities', [
            'collapse' => true,
            'name'     => _l('als_utilities'),
            'position' => 70,
            'icon'     => 'fa fa-cogs',
        ]);*/

    /*$CI->app_menu->add_sidebar_children_item('utilities', [
                'slug'     => 'media',
                'name'     => _l('als_media'),
                'href'     => admin_url('utilities/media'),
                'position' => 5,
        ]);*/

    /*if (has_permission('bulk_pdf_exporter', '', 'view')) {
        $CI->app_menu->add_sidebar_children_item('utilities', [
                'slug'     => 'bulk-pdf-exporter',
                'name'     => _l('bulk_pdf_exporter'),
                'href'     => admin_url('utilities/bulk_pdf_exporter'),
                'position' => 10,
        ]);
    }*/

    /*$CI->app_menu->add_sidebar_children_item('utilities', [
                'slug'     => 'calendar',
                'name'     => _l('als_calendar_submenu'),
                'href'     => admin_url('utilities/calendar'),
                'position' => 15,
        ]);*/


    /*if (is_admin()) {
        $CI->app_menu->add_sidebar_children_item('utilities', [
                'slug'     => 'announcements',
                'name'     => _l('als_announcements_submenu'),
                'href'     => admin_url('announcements'),
                'position' => 20,
        ]);*/

        /*$CI->app_menu->add_sidebar_children_item('utilities', [
                'slug'     => 'activity-log',
                'name'     => _l('als_activity_log_submenu'),
                'href'     => admin_url('utilities/activity_log'),
                'position' => 25,
        ]);

        $CI->app_menu->add_sidebar_children_item('utilities', [
                'slug'     => 'ticket-pipe-log',
                'name'     => _l('ticket_pipe_log'),
                'href'     => admin_url('utilities/pipe_log'),
                'position' => 30,
        ]);*/
    //}

    /*if (has_permission('reports', '', 'view')) {
        $CI->app_menu->add_sidebar_menu_item('reports', [
                'collapse' => true,
                'name'     => _l('als_reports'),
                'href'     => admin_url('reports'),
                'icon'     => 'fa fa-area-chart',
                'position' => 60,
        ]);
        $CI->app_menu->add_sidebar_children_item('reports', [
                'slug'     => 'sales-reports',
                'name'     => _l('als_reports_sales_submenu'),
                'href'     => admin_url('reports/sales'),
                'position' => 5,
        ]);
        $CI->app_menu->add_sidebar_children_item('reports', [
                'slug'     => 'expenses-reports',
                'name'     => _l('als_reports_expenses'),
                'href'     => admin_url('reports/expenses'),
                'position' => 10,
        ]);
        $CI->app_menu->add_sidebar_children_item('reports', [
                'slug'     => 'expenses-vs-income-reports',
                'name'     => _l('als_expenses_vs_income'),
                'href'     => admin_url('reports/expenses_vs_income'),
                'position' => 15,
        ]);
        $CI->app_menu->add_sidebar_children_item('reports', [
                'slug'     => 'leads-reports',
                'name'     => _l('als_reports_leads_submenu'),
                'href'     => admin_url('reports/leads'),
                'position' => 20,
        ]);

        if (is_admin()) {
            $CI->app_menu->add_sidebar_children_item('reports', [
                    'slug'     => 'timesheets-reports',
                    'name'     => _l('timesheets_overview'),
                    'href'     => admin_url('staff/timesheets?view=all'),
                    'position' => 25,
            ]);
        }

        $CI->app_menu->add_sidebar_children_item('reports', [
                    'slug'     => 'knowledge-base-reports',
                    'name'     => _l('als_kb_articles_submenu'),
                    'href'     => admin_url('reports/knowledge_base_articles'),
                    'position' => 30,
            ]);
    }*/

    // Setup menu
    /*if (has_permission('staff', '', 'view')) {
        $CI->app_menu->add_setup_menu_item('staff', [
                    'name'     => _l('als_staff'),
                    'href'     => admin_url('staff'),
                    'position' => 5,
            ]);
    }*/

    if (is_admin()) {}
        /*$CI->app_menu->add_setup_menu_item('customers', [
                    'collapse' => true,
                    'name'     => _l('clients'),
                    'position' => 10,
            ]);*/

        
        /*$CI->app_menu->add_setup_menu_item('support', [
                    'collapse' => true,
                    'name'     => _l('support'),
                    'position' => 15,
            ]);

        $CI->app_menu->add_setup_children_item('support', [
                    'slug'     => 'departments',
                    'name'     => _l('acs_departments'),
                    'href'     => admin_url('departments'),
                    'position' => 5,
            ]);
        $CI->app_menu->add_setup_children_item('support', [
                    'slug'     => 'tickets-predefined-replies',
                    'name'     => _l('acs_ticket_predefined_replies_submenu'),
                    'href'     => admin_url('tickets/predefined_replies'),
                    'position' => 10,
            ]);
        $CI->app_menu->add_setup_children_item('support', [
                    'slug'     => 'tickets-priorities',
                    'name'     => _l('acs_ticket_priority_submenu'),
                    'href'     => admin_url('tickets/priorities'),
                    'position' => 15,
            ]);
        $CI->app_menu->add_setup_children_item('support', [
                    'slug'     => 'tickets-statuses',
                    'name'     => _l('acs_ticket_statuses_submenu'),
                    'href'     => admin_url('tickets/statuses'),
                    'position' => 20,
            ]);

        $CI->app_menu->add_setup_children_item('support', [
                    'slug'     => 'tickets-services',
                    'name'     => _l('acs_ticket_services_submenu'),
                    'href'     => admin_url('tickets/services'),
                    'position' => 25,
            ]);
        $CI->app_menu->add_setup_children_item('support', [
                    'slug'     => 'tickets-spam-filters',
                    'name'     => _l('spam_filters'),
                    'href'     => admin_url('spam_filters/view/tickets'),
                    'position' => 30,
            ]);*/

        /*$CI->app_menu->add_setup_menu_item('leads', [
                    'collapse' => true,
                    'name'     => _l('acs_leads'),
                    'position' => 20,
            ]);
        $CI->app_menu->add_setup_children_item('leads', [
                    'slug'     => 'leads-sources',
                    'name'     => _l('acs_leads_sources_submenu'),
                    'href'     => admin_url('leads/sources'),
                    'position' => 5,
            ]);
        $CI->app_menu->add_setup_children_item('leads', [
                    'slug'     => 'leads-statuses',
                    'name'     => _l('acs_leads_statuses_submenu'),
                    'href'     => admin_url('leads/statuses'),
                    'position' => 10,
            ]);
        $CI->app_menu->add_setup_children_item('leads', [
                    'slug'     => 'leads-email-integration',
                    'name'     => _l('leads_email_integration'),
                    'href'     => admin_url('leads/email_integration'),
                    'position' => 15,
            ]);
        $CI->app_menu->add_setup_children_item('leads', [
                    'slug'     => 'web-to-lead',
                    'name'     => _l('web_to_lead'),
                    'href'     => admin_url('leads/forms'),
                    'position' => 20,
            ]);*/

        /*$CI->app_menu->add_setup_menu_item('finance', [
                    'collapse' => true,
                    'name'     => _l('acs_finance'),
                    'position' => 25,
            ]);
        $CI->app_menu->add_setup_children_item('finance', [
                    'slug'     => 'taxes',
                    'name'     => _l('acs_sales_taxes_submenu'),
                    'href'     => admin_url('taxes'),
                    'position' => 5,
            ]);
        $CI->app_menu->add_setup_children_item('finance', [
                    'slug'     => 'currencies',
                    'name'     => _l('acs_sales_currencies_submenu'),
                    'href'     => admin_url('currencies'),
                    'position' => 10,
            ]);
        $CI->app_menu->add_setup_children_item('finance', [
                    'slug'     => 'payment-modes',
                    'name'     => _l('acs_sales_payment_modes_submenu'),
                    'href'     => admin_url('paymentmodes'),
                    'position' => 15,
            ]);
        $CI->app_menu->add_setup_children_item('finance', [
                    'slug'     => 'expenses-categories',
                    'name'     => _l('acs_expense_categories'),
                    'href'     => admin_url('expenses/categories'),
                    'position' => 20,
            ]);*/

        /*$CI->app_menu->add_setup_menu_item('contracts', [
                    'collapse' => true,
                    'name'     => _l('acs_contracts'),
                    'position' => 30,
            ]);
        $CI->app_menu->add_setup_children_item('contracts', [
                    'slug'     => 'contracts-types',
                    'name'     => _l('acs_contract_types'),
                    'href'     => admin_url('contracts/types'),
                    'position' => 5,
            ]);*/
        
        $CI->app_menu->add_sidebar_menu_item('hr', [
            'collapse' => true,
            'name'     => "HR",
            'position' => 5,
            'icon'     => 'fa fa-user-circle menu-icon',
        ]);
        
        if(has_permission_new('hrm_hr_records','','view')){
		 $CI->app_menu->add_sidebar_children_item('hr', [
			'slug'     => 'hr_profile_hr_records',
			'name'     => "Staff Member",
			'icon'     => 'fa fa-user',
			'href'     => admin_url('hr_profile/staff_infor'),
			'position' => 1,
		]);
	 }
	 
	 if(has_permission_new('staffmanage_job_position','','view')){
		 $CI->app_menu->add_sidebar_children_item('hr', [
			'slug'     => 'hr_profile_job_position_manage',
			'name'     => "Job Designation",
			'icon'     => 'fa fa-map-pin',
			'href'     => admin_url('hr_profile/job_positions'),
			'position' => 2,
		]);
	 }
	 
	 if(has_permission_new('hrm_dependent_person','','view')){
		$CI->app_menu->add_sidebar_children_item('hr', [
			'slug'     => 'hr_profile_dependent_person',
			'name'     => _l('hr_dependent_persons'),
			'icon'     => 'fa fa-address-card-o',
			'href'     => admin_url('hr_profile/dependent_persons'),
			'position' => 3,
		]);
	}
	
	if (has_permission_new('attendance_management', '', 'view_own') || has_permission_new('attendance_management', '', 'view') || is_admin()) {
		$CI->app_menu->add_sidebar_children_item('hr', [
			'slug'     => 'timesheets_timekeeping',
			'name'     => _l('attendance_sheet'),
			'href'     => admin_url('timesheets/timekeeping'),
			'icon'     => 'fa fa-pencil-square-o',
			'position' =>4,
		]); 
	}
	
	if (has_permission_new('leave_management', '', 'view_own') || has_permission_new('leave_management', '', 'view') || is_admin()) {          
		$CI->app_menu->add_sidebar_children_item('hr', [
			'slug'     => 'timesheets_timekeeping_mnrh',
			'name'     => _l('leave'),
			'icon'     => 'fa fa-clipboard',
			'href'     => admin_url('timesheets/requisition_manage') ,
			'position' => 5,

		]);
	}
	
	if (has_permission_new('route_management', '', 'view_own') || has_permission_new('route_management', '', 'view') || is_admin()) {  
		$allow_attendance_by_route = 0;
		$data_by_route = get_timesheets_option('allow_attendance_by_route');
		if($data_by_route){
			$allow_attendance_by_route = $data_by_route;
		}  
		if($allow_attendance_by_route == 1){
			$CI->app_menu->add_sidebar_children_item('hr', [
				'slug'     => 'timesheets_route_management',
				'name'     => _l('route_management'),
				'icon'     => 'fa fa-map-signs',
				'href'     => admin_url('timesheets/route_management?tab=route') ,
				'position' => 6,

			]);
		}      
	}
	
	if (has_permission_new('table_shiftwork_management', '', 'view_own') || has_permission_new('table_shiftwork_management', '', 'view') || is_admin()) {
		$CI->app_menu->add_sidebar_children_item('hr', [
			'slug'     => 'timesheets_table_shiftwork',
			'name'     => _l('shiftwork'),
			'href'     => admin_url('timesheets/table_shiftwork'),
			'icon'     => 'fa fa-ticket',
			'position' =>7,
		]);
	}
	if (has_permission_new('table_shiftwork_management', '', 'view_own') || has_permission_new('table_shiftwork_management', '', 'view') || is_admin()) {
		$CI->app_menu->add_sidebar_children_item('hr', [
			'slug'     => 'timesheets_shift_management',
			'name'     => _l('shift_management'),
			'href'     => admin_url('timesheets/shift_management'),
			'icon'     => 'fa fa-calendar',
			'position' =>8,
		]);
	}
	if (has_permission_new('table_shiftwork_management', '', 'view_own') || has_permission_new('table_shiftwork_management', '', 'view') || is_admin()) {
		$CI->app_menu->add_sidebar_children_item('hr', [
			'slug'     => 'timesheets_shift_type',
			'name'     => _l('shift_type'),
			'href'     => admin_url('timesheets/manage_shift_type'),
			'icon'     => 'fa fa-magic',
			'position' => 9,
		]);
	}
	$data_attendance_by_coordinates = get_timesheets_option('allow_attendance_by_coordinates');
	if($data_attendance_by_coordinates){
		if($data_attendance_by_coordinates == 1){
			if (has_permission_new('table_workplace_management', '', 'view_own') || has_permission_new('table_workplace_management', '', 'view') || is_admin()) {
				$CI->app_menu->add_sidebar_children_item('hr', [
					'slug'     => 'timesheets_workplace_mgt',
					'name'     => _l('workplace_mgt'),
					'href'     => admin_url('timesheets/workplace_mgt?group=workplace_assign'),
					'icon'     => 'fa fa-street-view',
					'position' => 10,
				]);
			}
		}
	}


	if (has_permission_new('report_management', '', 'view_own') || has_permission_new('report_management', '', 'view') || is_admin()) {
		$CI->app_menu->add_sidebar_children_item('hr', [
			'slug'     => 'timesheets-report',
			'name'     => "Timesheets Report",
			'href'     => admin_url('timesheets/reports'),
			'icon'     => 'fa fa-line-chart',
			'position' =>11,
		]);
	}
	
	/*if(has_permission('hrp_employee','','view') || has_permission('hrp_employee','','view_own')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hr_manage_employees',
            'name'     => _l('hr_manage_employees'),
            'icon'     => 'fa fa-vcard-o',
            'href'     => admin_url('hr_payroll/manage_employees'),
            'position' => 12,
        ]);
    }*/

    /*if(has_permission('hrp_attendance','','view') || has_permission('hrp_attendance','','view_own')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hr_manage_attendance',
            'name'     => _l('hr_manage_attendance'),
            'icon'     => 'fa fa-pencil-square-o menu-icon',
            'href'     => admin_url('hr_payroll/manage_attendance'),
            'position' => 13,
        ]);
    }*/

    if(has_permission_new('hrp_commission','','view') || has_permission_new('hrp_commission','','view_own')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hr_manage_commissions',
            'name'     => _l('hrp_commission_manage'),
            'icon'     => 'fa fa-american-sign-language-interpreting',
            'href'     => admin_url('hr_payroll/manage_commissions'),
            'position' => 14,
        ]);
    }


    if(has_permission_new('hrp_deduction','','view') || has_permission_new('hrp_deduction','','view_own')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hr_manage_deductions',
            'name'     => _l('hrp_deduction_manage'),
            'icon'     => 'fa fa-cut',
            'href'     => admin_url('hr_payroll/manage_deductions'),
            'position' => 15,
        ]);
    }


    if(has_permission_new('hrp_bonus_kpi','','view') || has_permission_new('hrp_bonus_kpi','','view_own')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hr_bonus_kpi',
            'name'     => _l('hr_bonus_kpi'),
            'icon'     => 'fa fa-gift',
            'href'     => admin_url('hr_payroll/manage_bonus'),
            'position' => 16,
        ]);
    }

    if(has_permission_new('hrp_insurrance','','view') || has_permission_new('hrp_insurrance','','view_own')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hrp_insurrance',
            'name'     => _l('hrp_insurrance'),
            'icon'     => 'fa fa-medkit',
            'href'     => admin_url('hr_payroll/manage_insurances'),
            'position' => 17,
        ]);
    }

    /*if(has_permission('hrp_payslip','','view') || has_permission('hrp_payslip','','view_own')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hr_pay_slips',
            'name'     => _l('hr_pay_slips'),
            'icon'     => 'fa fa-money',
            'href'     => admin_url('hr_payroll/payslip_manage'),
            'position' => 18,
        ]);
    }*/

    /*if(has_permission('hrp_payslip_template','','view') || has_permission('hrp_payslip_template','','view_own')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hrp_payslip_template',
            'name'     => _l('hr_pay_slip_templates'),
            'icon'     => 'fa fa-outdent',
            'href'     => admin_url('hr_payroll/payslip_templates_manage'),
            'position' => 19,
        ]);
    }*/

    if(has_permission_new('hrp_income_tax','','view') || has_permission_new('hrp_income_tax','','view_own')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hrp_income_tax',
            'name'     => _l('hrp_income_tax'),
            'icon'     => 'fa fa-calendar-minus-o',
            'href'     => admin_url('hr_payroll/income_taxs_manage'),
            'position' => 20,
        ]);
    }

    /*if(has_permission('hrp_report','','view')){
        $CI->app_menu->add_sidebar_children_item('hr', [
            'slug'     => 'hr_payroll_reports',
            'name'     => _l('hrp_reports'),
            'icon'     => 'fa fa-list-alt',
            'href'     => admin_url('hr_payroll/reports'),
            'position' => 21,
        ]);
    }*/
	

    
        $modules_name = _l('modules');

        if ($modulesNeedsUpgrade = $CI->app_modules->number_of_modules_that_require_database_upgrade()) {
            $modules_name .= '<span class="badge menu-badge bg-warning">' . $modulesNeedsUpgrade . '</span>';
        }

        $CI->app_menu->add_setup_menu_item('modules', [
                    'href'     => admin_url('modules'),
                    'name'     => $modules_name,
                    'position' => 35,
            ]);
        
        

        /*$CI->app_menu->add_setup_menu_item('custom-fields', [
                    'href'     => admin_url('custom_fields'),
                    'name'     => _l('asc_custom_fields'),
                    'position' => 45,
            ]);*/

        /*$CI->app_menu->add_setup_menu_item('gdpr', [
                    'href'     => admin_url('gdpr'),
                    'name'     => _l('gdpr_short'),
                    'position' => 50,
            ]);*/

        /*$CI->app_menu->add_setup_menu_item('roles', [
                    'href'     => admin_url('roles'),
                    'name'     => _l('acs_roles'),
                    'position' => 55,
            ]);*/

/*             $CI->app_menu->add_setup_menu_item('api', [
                          'href'     => admin_url('api'),
                          'name'     => 'API',
                          'position' => 65,
                  ]);*/

    if (has_permission_new('settings', '', 'view')) {
        $CI->app_menu->add_setup_menu_item('settings', [
                    'href'     => admin_url('settings'),
                    'name'     => _l('acs_settings'),
                    'position' => 200,
            ]);
    }

    if (has_permission_new('email_templates', '', 'view')) {
        $CI->app_menu->add_setup_menu_item('email-templates', [
                    'href'     => admin_url('emails'),
                    'name'     => _l('acs_email_templates'),
                    'position' => 40,
            ]);
    }
    
    $CI->app_menu->add_sidebar_menu_item('admin', [
            'collapse' => true,
            'name'     => "Admin",
            'position' => 80,
            'icon'     => 'fa fa-user-circle menu-icon',
    ]);
    
    if (is_admin()) {
        $CI->app_menu->add_sidebar_children_item('admin', [
                'slug'     => 'role_new',
                'name'     => 'User Rights',
                'href'     => admin_url('roles/role_new'),
                'position' => 31,
        ]);
    }
    
    if (is_admin()) {
        $CI->app_menu->add_sidebar_children_item('admin', [
                'slug'     => 'no_show',
                'name'     => 'No Show Accounts',
                'href'     => admin_url('clients/no_show'),
                'position' => 31,
        ]);
    }
    
    if (is_admin()) {
        $CI->app_menu->add_sidebar_children_item('admin', [
                'slug'     => 'customer-groups',
                'name'     => 'Account Type',
                'href'     => admin_url('clients/groups'),
                'position' => 31,
        ]);
    }
    
    if (has_permission_new('accounting_dashboard', '', 'view') || is_admin()) {
			$CI->app_menu->add_sidebar_children_item('admin', [
				'slug' => 'account_group_master',
				'name' => "Account Group",
				'icon' => 'fa fa-book',
				'href' => admin_url('accounting/account_group_master'),
				'position' => 31,
			]);
		}
    if(is_admin()){
    $CI->app_menu->add_sidebar_children_item('admin', [
                    'href'     => admin_url('roles'),
                    'name'     => 'Staff Role',
                    'position' => 31,
            ]);
    }       
    if(has_permission_new('hrm_setting','','view') || is_admin()){
		 $CI->app_menu->add_sidebar_children_item('admin', [
			'slug'     => 'hr_profile_setting',
			'name'     => 'HR Records Setting',
			'icon'     => 'fa fa-cogs',
			'href'     => admin_url('hr_profile/setting?group=contract_type'),
			'position' => 31,
		]);
	 }
	 
	 if(has_permission_new('hrp_setting','','view') || is_admin()){
        $CI->app_menu->add_sidebar_children_item('admin', [
            'slug'     => 'hrp_settings',
            'name'     => 'HR Payroll Setting',
            'icon'     => 'fa fa-cog menu-icon',
            'href'     => admin_url('hr_payroll/setting?group=income_tax_rates'),
            'position' => 31,
        ]);

    }
	
	if (is_admin()) {
		$CI->app_menu->add_sidebar_children_item('admin', [
			'slug'     => 'timesheets_setting',
			'name'     => 'Timesheets Setting',
			'href'     => admin_url('timesheets/setting?group=manage_leave'),
			'icon'     => 'fa fa-gears',
			'position' => 31,
		]);
	}
	
	/*if (is_admin()) {
	$CI->app_menu->add_sidebar_children_item('admin', [
            'slug'     => 'purchase-settings',
            'name'     => 'Purchase Setting',
            'icon'     => 'fa fa-gears',
            'href'     => admin_url('purchase/setting'),
            'position' => 31,
        ]);
	}*/
	if (has_permission_new('settings', '', 'view') || is_admin()) {
        $CI->app_menu->add_sidebar_children_item('admin', [
                    'href'     => admin_url('settings'),
                    'name'     => 'Genaral Setting',
                    'position' => 31,
            ]);
    }

    if (has_permission_new('email_templates', '', 'view') || is_admin()) {
        $CI->app_menu->add_sidebar_children_item('admin', [
                    'href'     => admin_url('emails'),
                    'name'     => _l('acs_email_templates'),
                    'position' => 31,
            ]);
    }
}
