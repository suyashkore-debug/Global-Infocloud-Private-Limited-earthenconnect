<?php

defined('BASEPATH') or exit('No direct script access allowed');


$dimensions = $pdf->getPageDimensions();

$pdf->SetMargins(3, 0, 3, 0);
$pdf->Ln(0);
$get_order_list = get_order_list($invoice->ChallanID);
$count = 0;
$count_order = count($get_order_list);
foreach ($get_order_list as $key => $order_detail) {
    
        $route_detail = get_route_detail($invoice->RouteID);
       
        $company_detail = get_company_name_by_id($order_detail["PlantID"]);
        
        $inv_item = get_item_by_order_id($order_detail["OrderID"]);
        $user_detail = get_staff_detail($invoice->DriverID);
        $user_detail2 = get_staff_detail($invoice->SalesmanID);
       $html = '<div>
       <br>
       <table style="width: 100%; font-size:12px;font-weight:700;" cellspacing="1" cellpadding="4" border="1">
       <tr>
       <td colspan="10" style="text-align:center;">
       <span style="text-align:center;font-size:12px;padding:0px;margin:0px;"><b><u>Gate Pass</u> </b></span><br>
       <span style="font-size:14px;font-weight:700;"> <b>'.$company_detail->company_name.'  </b></span><br>
       <span><b>'.$company_detail->address.'</b></span><br>
       <span><b>(GSTIN '.$company_detail->gst.') Contact No. : '.$company_detail->mobile1." , ".$company_detail->mobile2." , ".$company_detail->mobile3.'</b></span>
       </td>
       </tr>
       <tr>
        <td style="border-left: 0px solid #333;" colspan="2"><b>Challan Id</b></td>
        <td style="border-right: 1px solid #333;" colspan="3"> <b>: '. $invoice->ChallanID .'</b></td>
        
        <td style="border-left: 0px solid #333;" colspan="2"><b>Route Name. </b></td>
        <td style="border-right: 1px solid #333;" colspan="3"> <b>: '.$route_detail->name.'</b></td>
       </tr>
       <tr>
        <td style="border-left: 0px solid #333;" colspan="2"><b>Date</b></td>
        <td style="border-right: 1px solid #333;" colspan="3"> <b>: '. substr($invoice->Transdate,0,10) .'</b></td>
        <td style="border-left: 0px solid #333;" colspan="2"><b>Vehicle No. </b></td>
        <td style="border-right: 1px solid #333;" colspan="3"> <b>: '.$invoice->VehicleID.'</b></td>
       </tr>
       <tr>
        <td style="border-left: 0px solid #333;" colspan="2"><b>Sales Man</b></td>
        <td style="border-right: 1px solid #333;" colspan="3"> <b>: '. $user_detail2->firstname .' '.$user_detail2->lastname.'</b></td>
        <td style="border-left: 0px solid #333;" colspan="2"><b>Driver Name</b></td>
        <td style="border-right: 1px solid #333;" colspan="3"> <b>: '. $user_detail->firstname .' '.$user_detail->lastname.'</b></td>
        
       </tr>
       <tr><td colspan="10"></td></tr>
       <tr>
       <td align="center;"><b>Sr.No.</b></td>
       <td align="center;"><b>Nick Name</b></td>
       <td colspan="5"><b>Item Name</b></td>
       <td align="center;"><b>Packing</b></td>
       <td align="center;"><b>Supplied In</b></td>
       <td align="right;"><b>Cases/Crate</b></td>
       </tr>';
       
       $i = 1;
       $colspan = 3;
       $empty_height= 750;
       
       foreach ($inv_item as $item) {
           if($i>1){
                $empty_height = $empty_height - 25;
            }
            
        if($item['OrderAmt'] == "0.00"){
            
        }else{
            $html .= '<tr>'; 
           $html .= '<td style="text-align:center;"><b>'.$i.'</b></td>'; 
           $html .= '<td class="description" align="center;"><b>'.$item['ItemID'].'</b></td>';
           $html .= '<td class="description" align="left;" colspan="5"><b>'.$item['description'].'</b></td>';
           
           $html .= '<td class="description" align="center;"><b>'. (int) $item['CaseQty'].'</b></td>';
           if($item['SuppliedIn']=="CS"){
               $unit = "Cases";
           }else {
               $unit = "Crate";
           }
           $html .= '<td class="description" align="center;"><b>'.$unit.'</b></td>';
           if(is_null($item["eOrderQty"])){
                            $newqty = $item["OrderQty"] / $item["CaseQty"];
                            
                        }else{
                            
                            $newqty = $item["eOrderQty"] / $item["CaseQty"];
                            
                        }
           $html .= '<td class="description" align="right;"><b>'. $newqty .'</b></td>';
           
           $i++;
           $html .= '</tr>';
        }
        
       }
       $html .= '<tr><td colspan="10" rowspan="2"></td></tr>
       <tr><td></td></tr>';
       
       
       $html .= '<tr>
       <td colspan="9"><b>Total Crate</b></td>
       <td align="right;"><b>'.$order_detail["Crates"].'</b></td>
        </tr>';
        $html .= '<tr>
       <td colspan="9"><b>Total Cases / Gatta</b></td>
       <td align="right;"><b>'.$order_detail["Cases"].'</b></td>
        </tr>';
       $html .= '<tr><td colspan="10" style="height:'.$empty_height.'px;"></td></tr>';
       $html .= '</table></div>';
       $pdf->writeHTML($html, true, false, false, false, '');
    
    $count++;
   // $pdf->Ln(0);
    if($count == $count_order){
    
    }else{
    $pdf->AddPage();
    }

}
/*$html2 ="Madhav SHinde";
$pdf->writeHTML($html2, true, false, false, false, '');
$pdf->Ln(0);*/
?>