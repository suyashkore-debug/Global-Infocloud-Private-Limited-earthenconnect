
<script>

function removeCommas(str) {
  "use strict";
  return(str.replace(/,/g,''));
}
 $('.edit-new-order').on('click', function(){
    $('#transfer-modal').find('button[type="submit"]').prop('disabled', false);
      $('#transfer-modal').modal('show');
      //init_journal_entry_table();
    });

$( "#vendor" ).change(function() {
   if(this.value != 0){
    $.post(admin_url + 'Stock_adjustment/get_vendor_data/'+this.value).done(function(response){
       
     
      response = JSON.parse(response);
     console.log(response);
      $("#c_name").val(response.vendor.company);
      $("#gst").val(response.vendor.vat);
      if(response.customer_groups_name != null){
           $("#group_name").val(response.customer_groups_name.name);
           $("#group_id").val(response.customer_groups_name.id);
      }
     
      $("#location_type").val(response.client_details.location_type);
      if(response.locations != null){
          if(response.locations.LocationTypeID == 1){
              var location_data = 'Local';
          }else{
               var location_data = 'OutStanding';
          }
         $("#location_type").val(location_data);
      }
     
    //   $("#address").val(response.vendor.address);
    //   $("#station_n").val(response.vendor.StationName);
    //   $("#address2").val(response.vendor.Address3);
    //   $("#city").val(response.vendor.city_name);
    //   $("#state_c").val(response.vendor.state);
      $("#state_id").val(response.vendor.state);
      $("#state").val(response.vendor.state_name);
      
    });
   }
});

function dc_percent_change(invoker){
  "use strict";
  var total_mn = $('input[name="total_mn"]').val();
  var t_mn = parseFloat(removeCommas(total_mn));
  var rs = (t_mn*invoker.value)/100;
  var tax_order_amount = $('input[name="tax_order_amount"]').val();

  if(tax_order_amount == ''){
    tax_order_amount = '0';
  }

  var grand_total = t_mn - rs + parseFloat(removeCommas(tax_order_amount));

  $('input[name="grand_total"]').val(numberWithCommas(grand_total));

  $('input[name="dc_total"]').val(numberWithCommas(rs));
  $('input[name="after_discount"]').val(numberWithCommas(t_mn - rs));

}

function tax_percent_change(invoker){
  "use strict";
  var total_mn = $('input[name="total_mn"]').val();
  var t_mn = parseFloat(removeCommas(total_mn));
  var rs = (t_mn*invoker.value)/100;
  var dc_total = $('input[name="dc_total"]').val();
  if(dc_total == ''){
    dc_total = '0';
  }

  var grand_total = t_mn + rs - parseFloat(removeCommas(dc_total));

  $('input[name="tax_order_amount"]').val(numberWithCommas(rs));
  $('input[name="grand_total"]').val(numberWithCommas(grand_total));
}

function dc_total_change(invoker){
  "use strict";
  var total_mn = $('input[name="total_mn"]').val();
  var t_mn = parseFloat(removeCommas(total_mn));
  var rs = t_mn - parseFloat(removeCommas(invoker.value));

  var tax_order_amount = $('input[name="tax_order_amount"]').val();

  if(tax_order_amount == ''){
    tax_order_amount = '0';
  }

  var grand_total = rs + parseFloat(removeCommas(tax_order_amount));

  $('input[name="grand_total"]').val(numberWithCommas(grand_total));

  $('input[name="after_discount"]').val(numberWithCommas(rs));
}

$(function(){
  "use strict";
		validate_purorder_form();
    function validate_purorder_form(selector) {

        selector = typeof(selector) == 'undefined' ? '#pur_order-form' : selector;

        appValidateForm($(selector), {
            pur_order_name: 'required',
            pur_order_number: 'required',
            order_date: 'required',
            vendor: 'required',
            invoce_n: 'required',
        });
    }


});

<?php if(!isset($order_detail)){
 ?>	



function numberWithCommas(x) {
  "use strict";
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
<?php if(!empty($order_detail)){ ?>
    var dataObject = <?php echo html_entity_decode($order_detail); ?>;
    console.log(dataObject);
<?php }else{ ?>
    var dataObject = []; 
<?php }?>
  
  var hotElement = document.querySelector('#example');
    var hotElementContainer = hotElement.parentNode;


    var hotSettings = {
      data: dataObject,
      columns: [
        {
          data: 'id',
          renderer: customDropdownRenderer,
          editor: "chosen",
         
          width: 100,
          chosenOptions: {
              data:  <?php echo json_encode($item_code); ?>
          }
        },
        { 
          data: 'description',
          type: 'text',
           width: 150,
          readOnly: true
        },
       
        {
          data: 'SuppliedIn_data',
          type: 'text',
          
           width: 50,
           readOnly: true
        },
         {
          data: 'case_qty',
          type: 'numeric',
          width: 50,
           readOnly: true
      
        },
        {
          data: 'CaseQty',
          type: 'numeric',
          width: 50,
      
        },
        {
          data: 'all_qty',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 60,
          readOnly: true
        },
         {
          data: 'assigned_rate',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 60,
          readOnly: true
        },
    
          {
          data: 'taxrate',
          type: 'text',
           width: 50,
          readOnly: true
        },
         {
          data: 'cgst_per',
          type: 'numeric',
          
           width: 60,
          readOnly: true
        },
            {
          data: 'sgst_per',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 60,
          readOnly: true
        },
            {
          data: 'igst_per',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 50,
          readOnly: true
        },
        
       
        {
          data: 'ChallanAmt',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 90,
           readOnly: true
        }
      
      ],
      licenseKey: 'non-commercial-and-evaluation',
      stretchH: 'all',
      width: '100%',
    //   autoWrapRow: true,
    //   rowHeights: 30,
      columnHeaderHeight: 40,
      minRows: 10,
      maxRows: 40,
      rowHeaders: true,
      colWidths: [200,10,100,50,100,50,100,50,100,100],
      colHeaders: [
        '<?php echo _l('ItemId'); ?>',
        '<?php echo _l('ItemName'); ?>',
        '<?php echo _l('Case/Create'); ?>',
        '<?php echo _l('PackQty'); ?>',
        '<?php echo _l('Cases'); ?>',
        '<?php echo _l('QTY'); ?>',
        '<?php echo _l('BasicRate'); ?>',
        '<?php echo _l('GST%'); ?>',
        '<?php echo _l('CGST%'); ?>',
        '<?php echo _l('SGST%'); ?>',
        '<?php echo _l('IGST%'); ?>',
        '<?php echo _l('Amount'); ?>',
      ],
       columnSorting: {
        indicator: true
      },
      autoColumnSize: {
        samplingRatio: 23
      },
    //   dropdownMenu: true,
      mergeCells: true,
      contextMenu: true,
      manualRowMove: true,
      manualColumnMove: true,
      multiColumnSorting: {
        indicator: true
      },
      filters: true,
      manualRowResize: true,
      manualColumnResize: true
    };

// first
var hot = new Handsontable(hotElement, hotSettings);
hot.addHook('afterChange', function(changes, src) {
	if(changes !== null){
	    changes.forEach(([row, prop, oldValue, newValue]) => {
	        var count = 1; 
        if(newValue != ''){
             vendor_id = $("#vendor").val();
        
  	      if(prop == 'id'){
  	         vendor_id = $("#vendor").val();
  	         console.log(vendor_id); 
  	          if(vendor_id == ''){
  	              alert("Please Select vendor");return false;
  	          }else{
  	                   var state = $("#state_id").val();
  	                   var group_id = $("#group_id").val();
  	                  $.post(admin_url + 'Stock_adjustment/items_change/'+newValue+'/'+group_id+'/'+state).done(function(response){
          	           
          	          response = JSON.parse(response);
          	          console.log(response)
          	          if(response.value.outst_supply_in == 'CS'){
          	              var case_create = 'Case';
          	          }else{
          	               var case_create = 'Create';
          	          }
                    //   hot.setDataAtCell(row,0, response.value.item_code);
                      hot.setDataAtCell(row,1, response.value.description);
          	          hot.setDataAtCell(row,2, case_create);
          	          hot.setDataAtCell(row,3, response.value.CaseQty);
          	          hot.setDataAtCell(row,4, '');
          	          hot.setDataAtCell(row,5, response.value.CaseQty);
          	          hot.setDataAtCell(row,6, response.basic_r.assigned_rate);
          	          hot.setDataAtCell(row,7, response.value.taxrate);
          	          hot.setDataAtCell(row,8, '');
          	          hot.setDataAtCell(row,9, '');
          	          hot.setDataAtCell(row,10, '');
          	          hot.setDataAtCell(row,11, '');
          	          /*hot.setDataAtCell(row,5, response.value.purchase_price*hot.getDataAtCell(row,4));*/
          	          
          	           count++; 
  	            });
  	              /*}else{
  	                   alert('Selected Item Division not assign to Vendor..')
  	              }*/
  	         // });
  	      
  	        }
  	      
  	      }else if(prop == 'CaseQty'){
  	        console.log(newValue);
  	        var case_q =  newValue*hot.getDataAtCell(row,3)
            hot.setDataAtCell(row,5, case_q);
             var case_quntity =  case_q*hot.getDataAtCell(row,6);
  	     //   hot.setDataAtCell(row,11, newValue*hot.getDataAtCell(row,3));
  	     //   hot.setDataAtCell(row,13, newValue*hot.getDataAtCell(row,3));
  	       	           var gst = hot.getDataAtCell(row,7)
  	       	           console.log(gst)
  	       var state = $("#state_id").val();
  	       if(state == 'UP'){

  	          var new_v =  case_quntity
  	         // alert(new_v)
  	          var prec = (gst*new_v)/100;
  	         var devide_gst = gst/2
  	            hot.setDataAtCell(row,8, devide_gst);
  	               hot.setDataAtCell(row,9, devide_gst);
  	               hot.setDataAtCell(row,10, 0);
  	                hot.setDataAtCell(row,11, parseFloat(new_v).toFixed(2));
  	             //   hot.setDataAtCell(row,13, (parseFloat(new_v) + prec));
  	       }else{
  	            
  	          var new_v =  case_quntity
  	          var prec = (gst*new_v)/100;
  	            hot.setDataAtCell(row,8, 0);
  	               hot.setDataAtCell(row,9, 0);
  	          hot.setDataAtCell(row,10, gst);
  	           hot.setDataAtCell(row,11, parseFloat(new_v.toFixed(2)));
  	         //  hot.setDataAtCell(row,13, (parseFloat(new_v) + prec));
  	       }
  	       if(gst == null){
  	            hot.setDataAtCell(row,7, 0);
  	            hot.setDataAtCell(row,8, 0);
  	               hot.setDataAtCell(row,9, 0);
  	               hot.setDataAtCell(row,10, 0);
  	       }
  	      }
         else if(prop == 'ChallanAmt'){ 
           var t_cases = 0;
           var full_total_d = 0;
           var total_value = 0;
           var total_cgst = 0;
           var total_sgst = 0;
           var total_igst = 0;
            round_off_v =0;
            
            for (var row_index = 0; row_index <= 40; row_index++) {
                 if(parseFloat(hot.getDataAtCell(row_index, 13)) > 0){
                full_total_d += (parseFloat(hot.getDataAtCell(row_index, 13)));
                 round_money = Math.round(full_total_d);
        
         if(full_total_d <= round_money ){
             
             round_off_v = full_total_d-round_money;
             round_off_v += round_off_v*(-1);
         }else{
              
                round_off_v += round_money-full_total_d;
            
         }
              }
              if(parseFloat(hot.getDataAtCell(row_index, 11)) > 0){
                total_value += (parseFloat(hot.getDataAtCell(row_index, 11)));
               
              }
               if(parseFloat(hot.getDataAtCell(row_index, 5)) > 0){
                t_cases += (parseFloat(hot.getDataAtCell(row_index, 5)));
               
              }
           
            }
             $('input[name="t_cases"]').val(t_cases);
             $('input[name="adjust_value"]').val(total_value);
            
             
             
          }
        }else{console.log('test')}
	    });
	}
  });
  
 
$('.save_detail').on('click', function() {
  $('input[name="pur_order_detail"]').val(JSON.stringify(hot.getData()));   
});



<?php } else{ ?>


function numberWithCommas(x) {
  "use strict";
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
// var dataobjj = 'test'; 
	var dataObject = <?php echo html_entity_decode($order_detail); ?>;
	console.log(dataObject);
  var hotElement = document.querySelector('#example');
    var hotElementContainer = hotElement.parentNode;
    var hotSettings = {
      data: dataObject,
      columns: [
      	
        {
          data: 'id',
          renderer: customDropdownRenderer,
          editor: "chosen",
          width: 100,
          chosenOptions: {
              data: <?php echo json_encode($item_code); ?>
          },
          
        },
        {
          data: 'description',
          type: 'text',
          width: 150,
          readOnly: true
        },
        
        {
          data: 'SuppliedIn_data',
          type: 'text',
          
           width: 50,
           readOnly: true
        },
         {
          data: 'case_qty',
          type: 'numeric',
          width: 50,
           readOnly: true
      
        },
        {
          data: 'CaseQty',
          type: 'numeric',
          width: 50,
      
        },
        {
          data: 'all_qty',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 60,
          readOnly: true
        },
         {
          data: 'assigned_rate',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 60,
          readOnly: true
        },
    
          {
          data: 'taxrate',
          type: 'text',
           width: 50,
          readOnly: true
        },
         {
          data: 'cgst_per',
          type: 'numeric',
          
           width: 60,
          readOnly: true
        },
            {
          data: 'sgst_per',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 60,
          readOnly: true
        },
            {
          data: 'igst_per',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 50,
          readOnly: true
        },
        
       
        {
          data: 'ChallanAmt',
          type: 'numeric',
          numericFormat: {
            pattern: '0,0'
          },
           width: 90,
           readOnly: true
        }
      
      ],
      licenseKey: 'non-commercial-and-evaluation',
      stretchH: 'all',
      width: '100%',
      autoWrapRow: true,
      rowHeights: 30,
      columnHeaderHeight: 40,
      minRows: 10,
      maxRows: 40,
      rowHeaders: true,
      colWidths: [0,0,200,50,100,50,100,50,100,50,100,100],
      colHeaders: [
      	
        '<?php echo _l('ItemId'); ?>',
        '<?php echo _l('ItemName'); ?>',
        '<?php echo _l('Case/Create'); ?>',
        '<?php echo _l('PackQty'); ?>',
        '<?php echo _l('Cases'); ?>',
        '<?php echo _l('QTY'); ?>',
        '<?php echo _l('BasicRate'); ?>',
        '<?php echo _l('GST%'); ?>',
        '<?php echo _l('CGST%'); ?>',
        '<?php echo _l('SGST%'); ?>',
        '<?php echo _l('IGST%'); ?>',
        '<?php echo _l('Amount'); ?>',
      ],
       columnSorting: {
        indicator: true
      },
      autoColumnSize: {
        samplingRatio: 23
      },
      dropdownMenu: true,
      mergeCells: true,
      contextMenu: true,
      manualRowMove: true,
      manualColumnMove: true,
      multiColumnSorting: {
        indicator: true
      },
      hiddenColumns: {
        columns: [0,1],
        indicators: true
      },
      filters: true,
      manualRowResize: true,
      manualColumnResize: true
    };

// second
var hot = new Handsontable(hotElement, hotSettings);
hot.addHook('afterChange', function(changes, src) {
	if(changes !== null){
	    changes.forEach(([row, prop, oldValue, newValue]) => {
	        var count = 1; 
        if(newValue != ''){
             vendor_id = $("#vendor").val();
        
  	      if(prop == 'id'){
  	         vendor_id = $("#vendor").val();
  	         console.log(vendor_id); 
  	          if(vendor_id == ''){
  	              alert("Please Select vendor");return false;
  	          }else{
  	                   var state = $("#state_id").val();
  	                   var group_id = $("#group_id").val();
  	                  $.post(admin_url + 'Stock_adjustment/items_change/'+newValue+'/'+group_id+'/'+state).done(function(response){
          	           
          	          response = JSON.parse(response);
          	          //console.log(response)
          	          if(response.value.outst_supply_in == 'CS'){
          	              var case_create = 'Case';
          	          }else{
          	               var case_create = 'Create';
          	          }
                      hot.setDataAtCell(row,0, response.value.item_code);
                      hot.setDataAtCell(row,1, response.value.description);
          	          hot.setDataAtCell(row,2, case_create);
          	          hot.setDataAtCell(row,3, response.value.case_qty);
          	          hot.setDataAtCell(row,4, '');
          	          hot.setDataAtCell(row,5, '');
          	          hot.setDataAtCell(row,6, response.basic_r.assigned_rate);
          	          hot.setDataAtCell(row,7, response.value.taxrate);
          	          hot.setDataAtCell(row,8, '');
          	          hot.setDataAtCell(row,9, '');
          	          hot.setDataAtCell(row,10, '');
          	          hot.setDataAtCell(row,11, '');
          	          /*hot.setDataAtCell(row,5, response.value.purchase_price*hot.getDataAtCell(row,4));*/
          	          
          	           count++; 
  	            });
  	              /*}else{
  	                   alert('Selected Item Division not assign to Vendor..')
  	              }*/
  	         // });
  	      
  	        }
  	      
  	      }else if(prop == 'CaseQty'){
  	        //console.log(newValue);
  	        var case_q =  newValue*hot.getDataAtCell(row,5)
            hot.setDataAtCell(row,5, case_q);
             var case_quntity =  case_q*hot.getDataAtCell(row,8);
  	       	 var gst = hot.getDataAtCell(row,9)
  	       	           //console.log(gst)
  	       var state = $("#state_id").val();
  	       if(state == 'UP'){

  	          var new_v =  case_quntity
  	         // alert(new_v)
  	          var prec = (gst*new_v)/100;
  	         var devide_gst = gst/2
  	            hot.setDataAtCell(row,10, devide_gst);
  	               hot.setDataAtCell(row,11, devide_gst);
  	               hot.setDataAtCell(row,11, 0);
  	                hot.setDataAtCell(row,12, parseFloat(new_v).toFixed(2));
  	             //   hot.setDataAtCell(row,13, (parseFloat(new_v) + prec));
  	       }else{
  	            
  	          var new_v =  case_quntity
  	          var prec = (gst*new_v)/100;
  	          hot.setDataAtCell(row,10, 0);
  	          hot.setDataAtCell(row,11, 0);
  	          hot.setDataAtCell(row,12, gst);
  	           hot.setDataAtCell(row,13, parseFloat(new_v.toFixed(2)));
  	         //  hot.setDataAtCell(row,13, (parseFloat(new_v) + prec));
  	       }
  	       if(gst == null){
  	            hot.setDataAtCell(row,9, 0);
  	            hot.setDataAtCell(row,10, 0);
  	            hot.setDataAtCell(row,11, 0);
  	            hot.setDataAtCell(row,13, 0);
  	       }
  	      }
         else if(prop == 'ChallanAmt'){ 
           var t_cases = 0;
           var full_total_d = 0;
           var total_value = 0;
           var total_cgst = 0;
           var total_sgst = 0;
           var total_igst = 0;
            round_off_v =0;
            
            for (var row_index = 0; row_index <= 40; row_index++) {
                 if(parseFloat(hot.getDataAtCell(row_index, 13)) > 0){
                full_total_d += (parseFloat(hot.getDataAtCell(row_index, 13)));
                 round_money = Math.round(full_total_d);
        
         if(full_total_d <= round_money ){
             
             round_off_v = full_total_d-round_money;
             round_off_v += round_off_v*(-1);
         }else{
              
                round_off_v += round_money-full_total_d;
            
         }
              }
              if(parseFloat(hot.getDataAtCell(row_index, 11)) > 0){
                total_value += (parseFloat(hot.getDataAtCell(row_index, 11)));
               
              }
               if(parseFloat(hot.getDataAtCell(row_index, 5)) > 0){
                t_cases += (parseFloat(hot.getDataAtCell(row_index, 5)));
               
              }
           
            }
     
         
         
         
             $('input[name="t_cases"]').val(t_cases);
             $('input[name="adjust_value"]').val(total_value);
            
             
             
          }
        }else{console.log('test')}
	    });
	}
  });
$('.save_detail').on('click', function() {
  $('input[name="pur_order_detail"]').val(JSON.stringify(hot.getData()));   
});

id = $('select[name="vendor"]').val();


var total_money = 0;
for (var row_index = 0; row_index <= 40; row_index++) {
  if(parseFloat(hot.getDataAtCell(row_index, 12)) > 0){
    total_money += (parseFloat(hot.getDataAtCell(row_index, 12)));
  }
  
 
}
$('input[name="total_mn"]').val(numberWithCommas(total_money));



<?php } ?>
function customRenderer(instance, td, row, col, prop, value, cellProperties) {
  "use strict";
    Handsontable.renderers.TextRenderer.apply(this, arguments);
    if(td.innerHTML != ''){
      td.innerHTML = td.innerHTML + '%'
      td.className = 'htRight';
    }
}

function customDropdownRenderer(instance, td, row, col, prop, value, cellProperties) {
  "use strict";
	  var selectedId;
	  var optionsList = cellProperties.chosenOptions.data;
	  
	  if(typeof optionsList === "undefined" || typeof optionsList.length === "undefined" || !optionsList.length) {
	      Handsontable.cellTypes.text.renderer(instance, td, row, col, prop, value, cellProperties);
	      return td;
	  }

	  var values = (value + "").split("|");
	  value = [];
	  for (var index = 0; index < optionsList.length; index++) {

	      if (values.indexOf(optionsList[index].id + "") > -1) {
	          selectedId = optionsList[index].id;
	          value.push(optionsList[index].item_code);
	      }
	  }
	  value = value.join(", ");

	  Handsontable.cellTypes.text.renderer(instance, td, row, col, prop, value, cellProperties);
	  return td;
}

</script>