<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>

<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
              <div class="_buttons">
                <div class="row"> 
                <div class="col-md-9">
                   <div class="">
                       <div class="col-md-2">
                            <?php echo render_date_input('from_date','FROM',$from_date);  ?>
                        </div>
                        
                        <div class="col-md-2">
                            <?php echo render_date_input('to_date','TO',$to_date); ?>
                        </div>
                        
                        <div class="col-md-4">
                            <?php echo render_select( 'states',$states,array( 'short_name',array( 'state_name')), 'client_state',$selected,array('data-none-selected-text'=>_l('dropdown_non_selected_tex'))); ?>
                        </div>
                        
                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="control-label">Loc Type</label>
                                <select name="loc_type" id="loc_type" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true">
                                <option value="1">Local</option>
                                <option value="2">OutStation</option>
                                <option value="3">NotDefined</option>
                            </select>
                            </div>
                        </div>
                        
                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="control-label">Reports In</label>
                                <select name="report_in" id="report_in" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true">
                                <option value="value">Value</option>
                                <option value="unit">Unit</option>
                                <option value="cases">Cases</option>
                                <option value="tonnage">Tonnage</option>
                            </select>
                            </div>
                        </div>
                        
                        <div class="clearfix"></div>
                        
                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="control-label">Reports In</label>
                                <select name="report_in2" id="report_in2" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true">
                                <option value="sales">Sales</option>
                                <option value="netsales">NetSales</option>
                                
                                <option value="freshrtn">FreshRtn</option>
                                <option value="damage">Damage</option>
                                
                            </select>
                            </div>
                        </div>
                        
                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="control-label">Reports In</label>
                                <select name="report_in3" id="report_in3" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
                                <option value=""></option>
                                <option value="vp">VP</option>
                                <option value="dgm">DGM</option>
                                <option value="4">RSM</option>
                                <option value="5">ASM</option>
                                <option value="8">SO</option>
                            </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="control-label">Staff Name</label>
                                <select name="staff_name" id="staff_name" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
                                <option value=""></option>
                                
                            </select>
                            </div>
                        </div>
                        
                        <div class="col-md-2">
                            <?php echo render_select('client_type',$groups,array('id','name'),'distributor_type'); ?>
                        </div>
                        
                        <div class="col-md-1" style="margin-top:10px;">
                            <br>
                            
                          <button class="btn btn-info pull-left mleft5 search_data" id="search_data" style="font-size:12px;">Show</button>
                        </div>
                        
                        <div class="col-md-1" style="margin-top:10px;">
                        <div class="custom_button">
                            <br>
                        <a class="btn btn-default buttons-excel buttons-html5" tabindex="0" aria-controls="daily_report" href="#" id="caexcel" style="font-size:12px;"><span>Export</span></a>
                        <!--<a class="dt-button buttons-pdf buttons-html5" tabindex="0" aria-controls="ca_datatable" href="#"><span>Export to PDF</span></a>-->
                        </div>
                        </div>
                        
                        <div class="col-md-12">
                            <p style="color:red;">Note : Amount includes GST</p>
                        </div>
             
                    </div> 
                </div>
                <div class="col-md-3">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <table id="itemdivision" class="fixed_headers" >
                                    <thead>
                                        <tr>
                                            <th ><input id="All" name="All" type="checkbox" value="true"><input name="All" type="hidden" value="false"> &nbsp;All
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody style="width:100%;height:140px;" class="itemgroup_body">
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
             
           
        
             </div>
        
               
            </div>
            <div class="clearfix"></div>
            
        <?php
        //print_r($company_detail);
        ?>
            <div class="fixTableHead load_data">
              
            </div>
            <span id="searchh" style="display:none;">
                                Loading.....
                            </span>
    
              
          </div>
</div>
</div>
</div>
</div>
</div>


<?php init_tail(); ?>
<!--new update -->
<script src="<?= base_url() ?>public/plugins/jquery.table2excel.js"></script>
<script type="text/javascript" language="javascript" >
$(document).ready(function(){
    
    var from_date = $("#from_date").val();
	var to_date = $("#to_date").val();
	get_item_group(from_date,to_date);
 
  function get_item_group(from_date,to_date)
  {
    $.ajax({
      url:"<?php echo admin_url(); ?>sale_reports/get_item_group",
      dataType:"JSON",
      method:"POST",
      data:{from_date:from_date, to_date:to_date},
      success:function(data){
          var html = '';
        if(data.length === 0){
            html += '<tr>';
            html += '<td style="border-bottom:none;width:100px;"> No sale for selected date</td></tr>';
            $('.itemgroup_body').html(html);
        }else{
            
            for(var count = 0; count < data.length; count++)
            {
                
            html += '<tr>';
            html += '<td style="border-bottom:none;width:18px;">';
            html += '<input id="'+data[count].id+'" name="chk" class="chk" type="checkbox" value="'+data[count].id+'" checked>';
            html += '</td>';
            html += '<td style="border-bottom:none;width:100px;">';
            html += '<label for="'+data[count].name+'">'+data[count].name+'</label>';
            html += '</td>';
            html += '</tr>';
            }
            
            $('.itemgroup_body').html(html);
        }
        
      }
    });
  }
 $('#from_date').on('change',function(){
        var from_date = $("#from_date").val();
	    var to_date = $("#to_date").val();
        get_item_group(from_date,to_date);
        
 });
 
 $('#to_date').on('change',function(){
        var from_date = $("#from_date").val();
	    var to_date = $("#to_date").val();
        get_item_group(from_date,to_date);
        
 });
 
 $('#report_in3').on('change', function() {
	var id = $(this).val();
	//alert(id);
	var url = "<?php echo base_url(); ?>admin/sale_reports/staff_list_by_role";
        jQuery.ajax({
                type: 'POST',
                url:url,
                data: {id: id},
                dataType:'json',
                success: function(data) {
                           
                    $("#staff_name").children().remove();
                    $('#staff_name').append('<option value="">Non Selected</option>');
                    $.each(data, function (index, value) {
                    // APPEND OR INSERT DATA TO SELECT ELEMENT.
                    $('#staff_name').append('<option value="' + value.staffid + '">' + value.firstname + value.lastname + '</option>');
                    });
                               
                    $("#staff_name").selectpicker("refresh");
                             
                            
                    }
        });
	});

function load_commulatives_data(from_date,to_date,report_in,states,client_type,item_group,loc_type)
  {
    $.ajax({
      url:"<?php echo admin_url(); ?>sale_reports/get_commulative_data",
      dataType:"JSON",
      method:"POST",
      data:{from_date:from_date, to_date:to_date, report_in:report_in, states:states, client_type:client_type, item_group:item_group, loc_type:loc_type},
      beforeSend: function () {
               
        $('#searchh').css('display','block');
        $('.load_data').css('display','none');
        
     },
      complete: function () {
                            
        $('.load_data').css('display','');
        $('#searchh').css('display','none');
     },
      success:function(data){
          
            $('.load_data').html(data);
       
        
      }
    });
  }
 
 $('#search_data').on('click',function(){
        var from_date = $("#from_date").val();
	    var to_date = $("#to_date").val();
	    var report_in = $("#report_in").val();
	    var states = $("#states").val();
	    var client_type = $("#client_type").val();
	    var loc_type = $("#loc_type").val();
	    var item_group = '';
	    var favorite = [];
            $.each($("input[name='chk']:checked"), function(){
                favorite.push($(this).val());
            });
            //alert("My favourite sports are: " + favorite.join(", "));
	    var item_group = favorite.join(",");
	    var msg = "Sales Report "+from_date +" To " + to_date;
	    $(".report_for").text(msg);
	    $.ajax({
          url:"<?php echo admin_url(); ?>sale_reports/get_commulative_data",
          dataType:"JSON",
          method:"POST",
          cache: false,
          data:{from_date:from_date, to_date:to_date, report_in:report_in, states:states, client_type:client_type, item_group:item_group, loc_type:loc_type},
          beforeSend: function () {
                   
            $('#searchh').css('display','block');
            $('.load_data').css('display','none');
            
         },
          complete: function () {
                                
            $('.load_data').css('display','');
            $('#searchh').css('display','none');
         },
          success:function(data){
              
                $('.load_data').html(data);
           
            
          }
        });
        //load_commulatives_data(from_date,to_date,report_in,states,client_type,item_group,loc_type);
        
 });


  

 
  
});

 $("#caexcel").click(function(){
  $("#daily_report").table2excel({
    // exclude CSS class
    exclude: ".noExl",
    action: newexportaction,
    name: "Worksheet Name",
    filename: "Daily-report", //do not include extension
    fileext: ".xls" // file extension
  }); 
});

function newexportaction(e, dt, button, config) {
         var self = this;
         var oldStart = dt.settings()[0]._iDisplayStart;
         dt.one('preXhr', function (e, s, data) {
             // Just this once, load all data from the server...
             data.start = 0;
             data.length = 2147483647;
             dt.one('preDraw', function (e, settings) {
                 // Call the original action function
                 if (button[0].className.indexOf('buttons-copy') >= 0) {
                     $.fn.dataTable.ext.buttons.copyHtml5.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-excel') >= 0) {
                     $.fn.dataTable.ext.buttons.excelHtml5.available(dt, config) ?
                         $.fn.dataTable.ext.buttons.excelHtml5.action.call(self, e, dt, button, config) :
                         $.fn.dataTable.ext.buttons.excelFlash.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-csv') >= 0) {
                     $.fn.dataTable.ext.buttons.csvHtml5.available(dt, config) ?
                         $.fn.dataTable.ext.buttons.csvHtml5.action.call(self, e, dt, button, config) :
                         $.fn.dataTable.ext.buttons.csvFlash.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-pdf') >= 0) {
                     $.fn.dataTable.ext.buttons.pdfHtml5.available(dt, config) ?
                         $.fn.dataTable.ext.buttons.pdfHtml5.action.call(self, e, dt, button, config) :
                         $.fn.dataTable.ext.buttons.pdfFlash.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-print') >= 0) {
                     $.fn.dataTable.ext.buttons.print.action(e, dt, button, config);
                 }
                 dt.one('preXhr', function (e, s, data) {
                     // DataTables thinks the first item displayed is index 0, but we're not drawing that.
                     // Set the property to what it was before exporting.
                     settings._iDisplayStart = oldStart;
                     data.start = oldStart;
                 });
                 // Reload the grid with the original page. Otherwise, API functions like table.cell(this) don't work properly.
                 setTimeout(dt.ajax.reload, 0);
                 // Prevent rendering of the full data to the DOM
                 return false;
             });
         });
         // Requery the server with the new one-time export settings
         dt.ajax.reload();
     }
     
    $(document).ready(function() {
  $('tbody').scroll(function(e) { //detect a scroll event on the tbody
  	/*
    Setting the thead left value to the negative valule of tbody.scrollLeft will make it track the movement
    of the tbody element. Setting an elements left value to that of the tbody.scrollLeft left makes it maintain 			it's relative position at the left of the table.    
    */
    $('thead').css("left", -$("tbody").scrollLeft()); //fix the thead relative to the body scrolling
    $('thead th:nth-child(1)').css("left", $("tbody").scrollLeft()); //fix the first cell of the header
    $('tbody td:nth-child(1)').css("left", $("tbody").scrollLeft()); //fix the first column of tdbody
  });
});
</script>
<style>
.fixTableHead {
      overflow-y: auto;
      height: 350px;
    }
    .fixTableHead thead th {
      position: sticky;
      top: 0;
    }
    .fixTableHead table {
      border-collapse: collapse;        
      width: 100%;
      
    }
   .fixTableHead th,
    td {
      padding: 5px 5px;
      border: 2px solid #529432;
    }
    .fixTableHead th {
      background: #ABDD93;
      padding: 5px 5px;
      text-align: left;
    vertical-align: middle;
    }
    
    .fixed_headers tbody {
    overflow-y: scroll;
    display: block;
    width: 100%;
}
.acctname {
    white-space: nowrap;
}
.fixed_headers thead {
    background-color: #f5f5f5;
    color: #333;
    height: 20px;
    width: 100%;
}
.fixed_headers {
    table-layout: fixed;
    border-collapse: collapse;
    border: 1px solid #E3E3E3;
    border-radius: 4px;
}
.col-md-2{
    padding:2px;
}
.col-md-1{
    padding:2px;
}
.col-md-4{
    padding:2px;
}
.fixed_headers tbody td {
    border: 1px solid #E3E3E3;
    padding: 0px 5px;
   
}
</style>

<script>
$(document).ready(function(){
    var maxEndDate = new Date('Y/m/d');
    var fin_y = "<?php echo $this->session->userdata('finacial_year')?>";
    
    var year = "20"+fin_y;
    
    
    var cur_y = new Date().getFullYear().toString().substr(-2);
    if(cur_y > fin_y){
        var year2 = parseInt(fin_y) + parseInt(1);
        var year2_new = "20"+year2;
        
        var e_dat = new Date(year2_new+'/03/31');
        var maxEndDate_new = e_dat;
    }else{
         var maxEndDate_new = maxEndDate;
    }
    
    var minStartDate = new Date(year, 03);
   /* console.log(minStartDate);
    console.log(maxEndDate_new);*/
    
    $('#from_date').datetimepicker({
        format: 'd/m/Y',
        minDate: minStartDate,
        maxDate: maxEndDate_new,
        timepicker: false
    });
    
    $('#to_date').datetimepicker({
        format: 'd/m/Y',
        minDate: minStartDate,
        maxDate: maxEndDate_new,
        timepicker: false
    });
    
});
</script> 