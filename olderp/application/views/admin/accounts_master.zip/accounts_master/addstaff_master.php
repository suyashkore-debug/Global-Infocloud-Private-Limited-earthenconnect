<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
                <div class="row">
                  <div class="col-md-12">
                  <h4 class="no-margin font-bold">Add New Staff</h4>
                  </div>
                  </div>
                  <?php echo form_open('admin/accounts_master/manage_staff',array('id'=>'other_staff')); ?>
                <div class="row">
                    <?php $value = (isset($account_detail) ? $account_detail->AccountID : ''); ?>
                        <?php
                        $date_attrs = array();
                            if(isset($account_detail)){
                                
                                $date_attrs['disabled'] = true;
                                $opening_bal = get_opening_bal($value);
                                $bal_on_bill = get_bal_on_bill($value);
                                
                            }
                            
                        ?>
                    <div class="col-md-3">
                        <input type="hidden" value="<?php echo $value; ?>" name="edit_account_id">
                        
                        <?php echo render_input('account_id','Account ID',$value,'',$date_attrs); ?>
                    </div>
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->company : ''); ?>
                        <?php echo render_input('account_name','Account Name',$value); ?>
                    </div>
                    
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->SubActGroupID : ''); 
                        
                        ?>
                        <?php echo render_select('Account_Group',$account_subgroup,array('SubActGroupID','SubActGroupName'),'ActGroup Name',$value,$date_attrs); ?>
                    </div>
                    <div class="col-md-3">
                       
                        <?php //echo render_select('Account_sldtype',$account_department,array('DeptID','DeptName'),'Account Designation'); ?>
                      <div class="form-group">
						<label for="Account_sldtype" class="control-label">Account Designation</label>
						<select class="form-control " name="Account_sldtype" data-live-search="true" id="Account_sldtype">
                		
                			<?php
                			    foreach ($account_department as $key => $value) {
                                    # code...
                                    ?>
                                    <option value="<?php echo $value["SLDTypeID"]; ?>" <?php if($account_designation->SLDTypeID ==$value["SLDTypeID"] ) echo "selected"; ?>><?php echo $value["SLDTypeName"]; ?></option>
                                <?php
                                }
                			?>					    
                		</select>
					 </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->firstname : ''); ?>
                        <?php echo render_input('contact_person','Contact Person',$value); ?>
                    </div>
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->state : ''); ?>
                        <?php echo render_select('state',$state_list,array('short_name','state_name'),'State',$value); ?>
                    </div>
                    <div class="col-md-3">
                        <?php $value=( isset($account_detail) ? $account_detail->city : ''); ?>
                        <?php
                            $city_name = get_city_name_by_state_id($account_detail->state);
                            ?>
                        <div class="form-group">
                            <label for="city" class="control-label"> City</label>
                                                
                            <select class="form-control city" name="city" id="city" >
                                <option value="<?php echo $value; ?>"><?php echo $value; ?></option>
                                <?php foreach($city_name as $cn){ ?>
                            		<option value="<?php echo $cn['id'];?>" <?php if($cn['id']==$client->city){ echo 'selected'; }?>><?php echo $cn["city_name"]; ?></option>
                            	<?php } ?>						    
                            </select>
                                                
                        </div>
                    </div>
                    <div class="col-md-3">
                         <?php $value = (isset($account_detail) ? $account_detail->address : ''); ?>
                        <?php echo render_input('address','Address',$value); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                         <?php $value = (isset($account_detail) ? $account_detail->Address3 : ''); ?>
                        <?php echo render_input('address2','Address2',$value); ?>
                    </div>
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->pincode : ''); ?>
                        <?php echo render_input('pin','Pin',$value); ?>
                    </div>
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->kms : ''); ?>
                        <?php echo render_input('km','KM',$value); ?>
                    </div>
                    
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->Officeno : ''); ?>
                        <?php echo render_input('office_no','Office No.',$value); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <?php //echo render_input('mobile_no','Mobile No.'); ?>
                        <?php $value = (isset($account_detail) ? $account_detail->mobile1 : ''); ?>
                        <label for="mobile_no" class="control-label">Mobile No.</label>
                            <input type="text" maxlength="10" pattern="[6789][0-9]{9}" id="mobile_no" name="mobile_no" class="form-control" autocomplete="off" value="<?php echo $value; ?>">
                            <span class="mob_denger" style="color:red;"></span>
                        
                    </div>
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->email : '');
                       
                        ?>
                        <?php echo render_input('email_id','Email ID',$value,'email'); ?>
                    </div>
                    <!--<div class="col-md-3">
                        <?php echo render_input('opening_bal','Opening Bal.'); ?>
                    </div>
                    <div class="col-md-3">
                        <?php echo render_input('security_dep','Security Dep.'); ?>
                    </div>-->
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->Blockyn : ''); ?>
                        <?php //echo render_input('block_ac','Block A/C'); ?>
                        <div class="form-group">
						<label for="block_ac" class="control-label">Block A/C</label>
						<select class="form-control " name="block_ac" data-live-search="true" id="block_ac">
						    <option value="N" <?php if($value == "N") echo "selected"; ?>>No</option>
						    <option value="Y" <?php if($value == "Y") echo "selected"; ?>>Yes</option>
						</select>
						</div>
                    </div>
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->StartDate : date('Y-m-d')); 
                        if(isset($account_detail)){
                            $new_val = substr($value,0,10);
                        }else{
                            $new_val = $value;
                        }
                        
                        ?>
                        <?php echo render_date_input('start_date','Start Date',$new_val); ?>
                    </div>
                </div>
                <div class="row">
                    
                    
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->StationName : ''); ?>
                        <?php echo render_input('station_name','Station Name',$value); ?>
                    </div>
                    <div class="col-md-3">
                       
                        <?php $value = (isset($account_detail) ? $account_detail->Pan : ''); ?>
                        <label for="pan_number" class="control-label">PAN number</label>
                            <input type="text" maxlength="10"  name="pan_number" pattern="[0-9 A-Z] {10}" id="pan_number" class="form-control" value="<?php echo $value?>">
                            <span class="pan_denger" style="color:red;"></span>
                    </div>
                    <div class="col-md-3">
                        <?php $value = (isset($account_detail) ? $account_detail->Aadhaarno : ''); ?>
                        <label for="aadhaar" class="control-label">Aadhar number</label>
                            <input type="text" maxlength="12"  name="aadhaar" pattern="[0-9] {10}" id="aadhaar" class="form-control" value="<?php echo $value?>">
                            <span class="aadhar_denger" style="color:red;"></span>
                    </div>
                    
                    <div class="col-md-3">
                        <?php $value = 24;
                                $date_attrs = array();
                                $date_attrs['disabled'] = true;
                  
                        ?>
                        <?php echo render_select('distributor_type',$distributor_type,array('id','name'),'Distributor Type',$value,$date_attrs); ?>
                      
                    </div>
                </div>
                <div class="row">
                    
                    <div class="col-md-1" style="margin-top: 10px;">
                       <br>
                    <button type="submit" class="btn btn-info"><?php echo _l('submit'); ?></button>
                    </div>
                    <div class="col-md-2" style="margin-top: 10px;">
                       <br>
                       <?php $redUrl = admin_url('accounts_master/staff_master'); ?>
                        <a href="<?php echo $redUrl;?>" class="btn btn-info">staff list</a>
                    </div>
                </div>
                
                  <?php echo form_close(); ?>
                
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php init_tail(); ?>
<script>

$(function(){
        'use strict';
        appValidateForm($('#other_staff'), {
            
            account_id: {
				required: true,
				remote: {
					url: site_url + "admin/misc/accountID_exists",
					type: 'post',
					data: {
						account_id: function() {
							return $('input[name="account_id"]').val();
						},
					}
				}
			},
            account_name: 'required',
            Account_Group: 'required',
            state: 'required',
            city: 'required',
            mobile_no: {
				required: true,
				remote: {
					url: site_url + "admin/misc/accountmobile_exists",
					type: 'post',
					data: {
						mobile_no: function() {
							return $('input[name="mobile_no"]').val();
						},
						userid: function() {
							return $('input[name="edit_account_id"]').val();
						},
					}
				}
			},
            
        });
        
    $('#state').on('change', function() {
                var id = $(this).val();
                //alert(roleid);
                var url = "<?php echo base_url(); ?>admin/hr_profile/select_city";
                    jQuery.ajax({
                        type: 'POST',
                        url:url,
                        data: {id: id},
                        dataType:'json',
                        success: function(data) {
                           
                            $(".city").html(data);
                            //alert(data);
                            
                        }
                    });
            });
    $('#Account_Group').on('change', function() {
                var id = $(this).val();
                //alert(roleid);
                if(id == "30000004"){
                    $( "#Account_sldtype" ).prop( "disabled", false );
                }else{
                    $( "#Account_sldtype" ).prop( "disabled", true );
                }
            });
    
    $('#mobile_no').keyup(function(e) {
            e.preventDefault();
            if(!$('#mobile_no').val().match('[0-9]{10}'))  {
                
                $(".mob_denger").text("Enter valid 10 digit mobile number");
            }else{
                $(".mob_denger").text(" ");
            }
            

        });
        
        $('#pan_number').keyup(function(e) {
            e.preventDefault();
            if(!$('#pan_number').val().match('[0-9 A-Z]{10}'))  {
                
                $(".pan_denger").text("Enter valid PAN number");
            }else{
                $(".pan_denger").text(" ");
            }
            

        });
        
        $('#aadhaar').keyup(function(e) {
            e.preventDefault();
            if(!$('#aadhaar').val().match('[0-9]{12}'))  {
                
                $(".aadhar_denger").text("Enter valid 12 digit Aadhar number");
            }else{
                $(".aadhar_denger").text(" ");
            }
            

        });
        
        
    });
</script>
</body>
</html>