<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <?php if(has_permission('hsnmaster','','delete')){ ?>
            <!-- <a href="#" data-toggle="modal" data-table=".table-invoice-items" data-target="#items_bulk_actions" class="hide bulk-actions-btn table-btn"><?php echo _l('bulk_actions'); ?></a>-->
             <div class="modal fade bulk_actions" id="items_bulk_actions" tabindex="-1" role="dialog">
              <div class="modal-dialog" role="document">
               <div class="modal-content">
                <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                 <h4 class="modal-title"><?php echo _l('bulk_actions'); ?></h4>
               </div>
               <div class="modal-body">
                 <?php if(has_permission('leads','','delete')){ ?>
                   <div class="checkbox checkbox-danger">
                    <input type="checkbox" name="mass_delete" id="mass_delete">
                    <label for="mass_delete"><?php echo _l('mass_delete'); ?></label>
                  </div>
                  <!-- <hr class="mass_delete_separator" /> -->
                <?php } ?>
              </div>
              <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _l('close'); ?></button>
               <a href="#" class="btn btn-info" onclick="items_bulk_action(this); return false;"><?php echo _l('confirm'); ?></a>
             </div>
           </div>
           <!-- /.modal-content -->
         </div>
         <!-- /.modal-dialog -->
       </div>
       <!-- /.modal -->
     <?php } ?>
     <?php hooks()->do_action('before_items_page_content'); ?>
     <?php if(has_permission('hsnmaster','','create')){ ?>
       <div class="_buttons">
        <!--<a href="#" class="btn btn-info pull-left" data-toggle="modal" data-target="#hsn_modal">Add HSN</a>-->
        <!--<a href="#" class="btn btn-info pull-left mleft5" data-toggle="modal" data-target="#groups"><?php echo _l('item_groups'); ?></a>
        <a href="#" class="btn btn-info pull-left mleft5" data-toggle="modal" data-target="#maingroups"><?php echo _l('item_main_groups'); ?></a>
        <a href="#" class="btn btn-info pull-left mleft5" data-toggle="modal" data-target="#subgroups"><?php echo _l('item_sub_groups'); ?></a>
        <a href="<?php echo admin_url('invoice_items/import'); ?>" class="btn btn-info pull-left mleft5"><?php echo _l('import_items'); ?></a>-->
        <h4>Add New TCS</h4>
      </div>
      <div class="clearfix"></div>
      <!--<hr class="hr-panel-heading" />-->
      <?php echo form_open('admin/tcs_master/manage',array('id'=>'hsn_form')); ?>
            <div class="row">
                <div class="col-md-3">
                    <?php echo render_input('tcspercent','TCS %'); ?>
                    &nbsp;<span id="errmsg"></span>
                </div>
                <div class="col-md-3">
                    <?php echo render_date_input('tcsdate','TCS Date'); ?>
                </div>
                <div class="col-md-3" style="margin-top:10px;">
                    <br>
                    <button type="submit" class="btn btn-info"><?php echo _l('submit'); ?></button>
                </div>
            </div>
      <?php echo form_close(); ?>
    <?php } ?>
    <?php
    //$table_data = [];

    /*$table_data = array_merge($table_data, array(
        'HSN Code',
        "Description",
      "Date",
     
      ));*/

    
    //render_datatable($table_data,'hsn-table'); ?>
  </div>
</div>
</div>
</div>
</div>
</div>
<?php //$this->load->view('admin/hsn_master/add_model'); ?>



<?php init_tail(); ?>
<style>
    #errmsg
{
color: red;
}
</style>
<script>
    $(document).ready(function () {
  /*//called when key is pressed in textbox
  $("#tcspercent").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
        $("#errmsg").html("Digits Only").show().fadeOut("slow");
               return false;
    }
   });*/
   
   $("#tcspercent").on("input", function(evt) {
   var self = $(this);
   self.val(self.val().replace(/[^0-9\.]/g, ''));
   if ((evt.which != 46 || self.val().indexOf('.') != -1) && (evt.which < 48 || evt.which > 57)) 
   {
     evt.preventDefault();
     
   }
 });
});
</script>
<script>
  /*$(function(){

    var notSortableAndSearchableItemColumns = [];
    <?php if(has_permission('hsnmaster','','delete')){ ?>
      notSortableAndSearchableItemColumns.push(0);
    <?php } ?>

    initDataTable('.table-hsn-table', admin_url+'hsn_master/table', notSortableAndSearchableItemColumns, notSortableAndSearchableItemColumns,'undefined',[0,'asc']);

     
    
    
    
   });*/
  function items_bulk_action(event) {
    if (confirm_delete()) {
      var mass_delete = $('#mass_delete').prop('checked');
      var ids = [];
      var data = {};

      if(mass_delete == true) {
        data.mass_delete = true;
      }

      var rows = $('.table-invoice-items').find('tbody tr');
      $.each(rows, function() {
        var checkbox = $($(this).find('td').eq(0)).find('input');
        if (checkbox.prop('checked') === true) {
          ids.push(checkbox.val());
        }
      });
      data.ids = ids;
      $(event).addClass('disabled');
      setTimeout(function() {
        $.post(admin_url + 'invoice_items/bulk_action', data).done(function() {
          window.location.reload();
        }).fail(function(data) {
          alert_float('danger', data.responseText);
        });
      }, 200);
    }
  }
 </script>
</body>
</html>
