<?php 
/*foreach($result2 as $row){
 $id=$row['id'];
}*/
//$sql ="SELECT * FROM tblrecipe_details where rec_id=$id"; 
//$query = $this->db->query($sql); ?>
 
<table class="table table-striped table-bordered" id="data_table" width="100%">
          <thead>
            <tr>
			   <!--<th>Id</th>-->
               <th>Item Code</th>
               <th>Item Name</th>
               <th>Req. Qty</th>
               <th>Measured In</th>
            </tr>
          </thead>		  
 	
		    <tbody id="tbody">
			<?php
			
			//if ($result2->num_rows() > 0) {
				$i = 1;
			foreach ($result2 as $row1) {
            //print_r($row1); exit();			
			 $qt=$row1['req_qty'] * $batch_qty; 
			 ?>  
               <tr>  
			   <input type="hidden" name="count_of_rec" value="<?php echo count($result2); ?>">
			   
               <input type="hidden" name="rec_detid[]<?php echo $i;?>" value="<?php echo $row1['id']; ?>" class="form-control" style="width: 60px;border-radius: 2px;height: 30px;" readonly>
			   
               <td><input type="text" name="item_id[]<?php echo $i;?>" value="<?php echo $row1['item_id']; ?>" class="form-control" style="width: 60px;border-radius: 2px;height: 30px;" readonly></td>
								
               <td><input type="text" name="item_name[]<?php echo $i;?>" value="<?php echo $row1['item_name'];?>" class="form-control" style="width: 300px;border-radius: 2px;height: 30px;" readonly></td>
							
               <td><input type="text" name="pro_req_qty[]<?php echo $i;?>" value="<?php echo $qt; ?>" class="form-control" style="width: 260px;border-radius: 2px;height: 30px;" readonly>
			   <input type="hidden" name="req_qty[]<?php echo $i;?>" value="<?php echo $row1['req_qty']; ?>" readonly>
			   </td> 
								 
               <td><input type="text" name="unit[]<?php echo $i;?>" value="<?php echo $row1['unit']; ?>" class="form-control" style="width: 260px;border-radius: 2px;height: 30px;" readonly></td>
                                
            </tr>
			<?php
			$i++;
				  }
				//}
			?> 
				
            </tbody>
	</table>