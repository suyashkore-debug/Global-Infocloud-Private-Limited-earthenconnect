<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Sale_reports extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        
        $this->load->model('sale_reports_model');
        $this->load->model('challan_model');
    }

    /* Get all invoices in case user go on index page */
    public function index($id = '')
    {
        //$this->list_orders($id);
        $this->daily_sale();
    }
    
    
    
    /* List all Dialy sales datatables */
    public function daily_sale()
    {
        if (!has_permission('orders', '', 'view')
            && !has_permission('orders', '', 'view_own')
            && get_option('allow_staff_view_invoices_assigned') == '0') {
            access_denied('orders');
        }

        close_setup_menu();

        
        $data['title']                = "Daily Sale reports";
       
        $data['company_detail'] = $this->sale_reports_model->get_company_detail();
        
        $data['bodyclass']            = 'invoices-total-manual';
        $this->load->view('admin/sale_reports/daily_sale', $data);
    }
    
    /* List all Party Pack Wise Commulatives Sales datatables */
    public function PartyPackWiseCummulativesSales()
    {
        if (!has_permission('orders', '', 'view')
            && !has_permission('orders', '', 'view_own')
            && get_option('allow_staff_view_invoices_assigned') == '0') {
            access_denied('orders');
        }

        close_setup_menu();

        
        $data['title']                = "Party Pack Wise Commulatives Sales";
        $this->load->model('clients_model');
        $data['states'] = $this->clients_model->getallstate();
        $data['groups'] = $this->clients_model->get_groups();
        $data['company_detail'] = $this->sale_reports_model->get_company_detail();
        
        $cur_date = date('d/m/Y');
        $m = date('m');
        $y = date('Y');
        $date1 = "01/".$m."/".$y;
        $data['from_date'] = $date1;
        $data['to_date'] = $cur_date;
        //$data['item_group'] = $this->sale_reports_model->get_sale_item_group($date1,$cur_date);
        /*echo "<pre>";
        echo count($data['item_group']);
        print_r($data['item_group']);
        die;*/
        $data['bodyclass']            = 'invoices-total-manual';
        $this->load->view('admin/sale_reports/PartyPackWiseCommulativesSales', $data);
    }
    
    public function load_data()
     {
        $data = array(
           'from_date' => $this->input->post('from_date'),
           'to_date'  => $this->input->post('to_date')
          );
      $data = $this->sale_reports_model->load_data($data);
      echo json_encode($data);
     }
     
    public function get_item_group()
     {
        $data = array(
           'from_date' => $this->input->post('from_date'),
           'to_date'  => $this->input->post('to_date')
          );
      $data = $this->sale_reports_model->get_sale_item_group2($data);
      echo json_encode($data);
    }
     
     public function staff_list_by_role()
     {  
        $data = $this->sale_reports_model->get_reported_by_staff($this->input->post('id'));
      echo json_encode($data);
     }
     
    
    public function get_commulative_data()
     {
        $filterdata = array(
           'from_date' => $this->input->post('from_date'),
           'to_date'  => $this->input->post('to_date'),
           'report_in'  => $this->input->post('report_in'),
           'states'  => $this->input->post('states'),
           'client_type'  => $this->input->post('client_type'),
           'item_group'  => $this->input->post('item_group'),
           'loc_type'  => $this->input->post('loc_type')
          );
          $report_in = $this->input->post('report_in');
          
          $states = $this->input->post('states');
          $state_name = $this->sale_reports_model->get_state_name($states);
          
          $client_type = $this->input->post('client_type');
          $client_type_name = $this->sale_reports_model->get_client_type_name($client_type);
          
          $item_group = $this->input->post('item_group');
          $item_group_name = $this->sale_reports_model->get_item_group_name($item_group);
          
          $loc_type = $this->input->post('loc_type');
          if($loc_type == 1){
              $loc_type_name = "Local";
          }elseif($loc_type == 2){
              $loc_type_name = "OutStation";
          }elseif($loc_type == 3){
              $loc_type_name = "NotDefined";
          }
          
        $selected_company = $this->session->userdata('root_company');
        
        $account_ids = array();
        $item_ids_desc = array();
        
        $table_header_data = $this->sale_reports_model->get_orders_itemlist_new($filterdata,$item_group);
        if(empty($table_header_data)){
            $error = "No record found...";
            echo json_encode($error);
        die;
        }
        
        foreach ($table_header_data as $value) {
            array_push($account_ids,$value['AccountID']);
            $item_ids_desc[$value["ItemID"]] = $value["description"];
        }
        /*echo json_encode($item_ids_desc);
        die;*/
        $html = '';
            $html .= '<table class="table-striped table-bordered daily_report" id="daily_report">';
            $html .= '<thead style="font-size:11px;">';
            
            $html .= '<tr style="display:none;">';
            $html .= '<th></th>';
            $html .= '<th><b>Report Date : </b></th>';
            $html .= '<th>'.$this->input->post('from_date').' To '.$this->input->post('to_date').'</th>';
            $html .= '</tr>';
            
            $html .= '<tr style="display:none;">';
            $html .= '<th></th>';
            $html .= '<th><b>State : </b></th>';
            $html .= '<th>'.$state_name->state_name.'</th>';
            $html .= '</tr>';
            
            $html .= '<tr style="display:none;">';
            $html .= '<th></th>';
            $html .= '<th><b>Loc Type : </b></th>';
            $html .= '<th>'.$loc_type_name.'</th>';
            $html .= '</tr>';
            
            $html .= '<tr style="display:none;">';
            $html .= '<th></th>';
            $html .= '<th><b>Reports In : </b></th>';
            $html .= '<th>'.$report_in.'</th>';
            $html .= '</tr>';
            
            $html .= '<tr style="display:none;">';
            $html .= '<th></th>';
            $html .= '<th><b>Reports In : </b></th>';
            $html .= '<th>Sales</th>';
            $html .= '</tr>';
            
            $html .= '<tr style="display:none;">';
            $html .= '<th></th>';
            $html .= '<th><b>Distributor Type : </b></th>';
            $html .= '<th>'.$client_type_name->name.'</th>';
            $html .= '</tr>';
            
            $html .= '<tr style="display:none;">';
            $html .= '<th></th>';
            $html .= '<th><b>Item Group : </b></th>';
            $html .= '<th>'.$item_group_name.'</th>';
            $html .= '</tr>';
            
            $html .= '<tr style="display:none;">';
            $html .= '<th></th>';
            $html .= '<th></th>';
            $html .= '<th></th>';
            $html .= '</tr>';
            
            $html .= '<tr>';
            $html .= '<th>SOID</th>';
            $html .= '<th >Station Name</th>';
            $html .= '<th width="20%" class="acctname">Account Name</th>';
            foreach ($item_ids_desc as $key => $value) {
            $html .='<th style="text-align:right;">'.$value.'</th>';
            
            }
            /*echo json_encode($account_ids);
        die;*/
            $html .= '<th>Item Value</th>';
            $html .= '<th>Crates</th>';
            $html .= '<th>Cases</th>';
            $html .= '</tr>';
            $html .= '</thead>';
            $html .= '<tbody>';
            $account_ids = array_unique($account_ids);
            $account_ids_str = "";
            $ii = 1;
            foreach ($account_ids as $id) {
                if($ii == "1"){
                    $account_ids_str = '"'.$id.'"';
                }else{
                    $account_ids_str = $account_ids_str.',"'.$id.'"';
                }
                $ii++;
            }
            $body_data = $this->sale_reports_model->get_itemdetails_for_body_data($account_ids_str,$filterdata);
            $footer_data = $this->sale_reports_model->get_itemdetails_for_footer_data($account_ids_str,$filterdata);
            $col_total_val = 0.00;
            $col_total_cases = 0.00;
            $col_total_unit = 0.00;
            foreach ($account_ids as $AccountId) {
            $html .='<tr>';
            $account_name = get_account_name($AccountId,$selected_company);
            $account_station = get_station_name($AccountId,$selected_company);
            $html .='<td></td>';
            $html .='<td>'.$account_station->StationName.'</td>';
            $html .='<td width="20%" class="acctname">'.$account_name->company.'</td>';
            //$sumamt = "A";
            $row_value = 0.00;
            $row_cases = 0.00;
            $row_unit = 0.00;
            
            foreach ($item_ids_desc as $key => $value) {
                $sumamt = "";
                $sumcases = "";
                $sumunit = "";
                foreach ($body_data as $key2 => $value2) {
                    if($value2["AccountID"] == $AccountId && $value2["ItemID"] == $key){
                        $sumamt = $value2["amt_sum"];
                        $sumcases = $value2["sumcases"];
                        $sumunit = $value2["sumunit"];
                        $row_value = $row_value + $value2["amt_sum"];
                        $row_cases = $row_cases + $value2["sumcases"];
                        $row_unit = $row_unit + $value2["sumunit"];
                    }
                }
                if($report_in == "value"){
                        $item_value_new = $sumamt;
                    }elseif($report_in == "cases"){
                        $item_value_new = $sumcases;
                    }
                    elseif($report_in == "unit"){
                        $item_value_new = $sumunit;
                    }
            $html .='<td style="text-align:right;">'.number_format($item_value_new,2).'</td>';
            
            }
            $col_total_val = $col_total_val + $row_value;
            $col_total_cases = $col_total_cases + $row_cases;
            $col_total_unit = $col_total_unit + $row_unit;
            $html .='<td>'.$row_value.'</td>';
            $html .='<td></td>';
            $html .='<td>'.$row_cases.'</td>';
            $html .='</tr>';
            }
            
            // footer data
            
            $html .='<tr>';
            $html .='<td></td>';
            $html .='<td></td>';
            $html .='<td style="color:#e93232;font-weight:700;">Total Value(Incl GST)</td>';
        foreach ($item_ids_desc as $key => $value) {
            
            foreach ($account_ids as $AccountId) {
            
            $colsumamt = "";
                foreach ($footer_data as $key3 => $value3) {
                    if($value3["ItemID"] == $key){
                        $colsumamt = $value3["amt_sum"];
                    }
                }
            
            }
            $html .='<td style="color:#e93232;font-weight:700;text-align:right;">'.number_format($colsumamt,2).'</td>';
            }
            $html .='<td style="color:#e93232;font-weight:700;text-align:right;">'.number_format($col_total_val,2).'</td>';
            $html .='<td></td>';
            $html .='<td style="color:#e93232;font-weight:700;text-align:right;">'.number_format($col_total_cases,2).'</td>';
            $html .='</tr>';
            
        // Cases Selection
        if($report_in == "cases"){
          
            $html .='<tr>';
            $html .='<td></td>';
            $html .='<td></td>';
            $html .='<td style="color:#e93232;font-weight:700;">Total Cases</td>';
        foreach ($item_ids_desc as $key => $value) {
            
            foreach ($account_ids as $AccountId) {
            
            $colsumcases = "";
                foreach ($footer_data as $key3 => $value3) {
                    if($value3["ItemID"] == $key){
                        $colsumcases = $value3["sumcases"];
                    }
                }
            
            }
            $html .='<td style="color:#e93232;font-weight:700;text-align:right;">'.number_format($colsumcases,2).'</td>';
        }
            $html .='<td style="color:#e93232;font-weight:700;text-align:right;">'.number_format($col_total_cases,2).'</td>';
            $html .='<td></td>';
            $html .='<td style="color:#e93232;font-weight:700;text-align:right;">'.number_format($col_total_cases,2).'</td>';
            $html .='</tr>';
        }
        
        // Unit Selection
        if($report_in == "unit"){
            $html .='<tr>';
            $html .='<td></td>';
            $html .='<td></td>';
            $html .='<td style="color:#e93232;font-weight:700;">Total Unit</td>';
        foreach ($item_ids_desc as $key => $value) {
            
            foreach ($account_ids as $AccountId) {
            
            $colsumunit = "";
                foreach ($footer_data as $key3 => $value3) {
                    if($value3["ItemID"] == $key){
                        $colsumunit = $value3["sumunit"];
                    }
                }
            
            }
            $html .='<td style="color:#e93232;font-weight:700;text-align:right;">'.number_format($colsumunit,2).'</td>';
        }
            $html .='<td style="color:#e93232;font-weight:700;text-align:right;">'.number_format($col_total_unit,2).'</td>';
            $html .='<td></td>';
            $html .='<td style="color:#e93232;font-weight:700;text-align:right;">'.number_format($col_total_cases,2).'</td>';
            $html .='</tr>';
        }
            
            $html .= '</tbody>';
            $html .= '</table>';
           
        echo json_encode($html);
        die;
        
    }
}
