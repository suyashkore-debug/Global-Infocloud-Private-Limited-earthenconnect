<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @since  2.3.3
 * Get available staff permissions, modules can use the filter too to hook permissions
 * @param  array  $data additional data passed from view role.php and member.php
 * @return array
 */
function get_available_staff_permissions($data = [])
{
    $viewGlobalName = _l('permission_view') . '(' . _l('permission_global') . ')';

    $allPermissionsArray = [
        'view_own' => _l('permission_view_own'),
        'view'     => $viewGlobalName,
        'create'   => _l('permission_create'),
        'edit'     => _l('permission_edit'),
        'delete'   => _l('permission_delete'),
    ];

    $withoutViewOwnPermissionsArray = [
        'view_own' => ['not_applicable' => true, 'name' => _l('permission_view_own')],
        'view'   => $viewGlobalName,
        'create' => _l('permission_create'),
        'edit'   => _l('permission_edit'),
        'delete' => _l('permission_delete'),
    ];
    
    $oneoptionPermissionsArray = [
        'view_own' => ['not_applicable' => true, 'name' => _l('permission_view_own')],
        'view' => ['not_applicable' => true, 'name' => $viewGlobalName],
        'create' => ['not_applicable' => true, 'name' => _l('permission_create')],
        'update' => "update",
        'delete' => ['not_applicable' => true, 'name' => _l('permission_delete')]
    ];
    $onlyview = [
        'view_own' => ['not_applicable' => true, 'name' => _l('permission_view_own')],
        'view'     => $viewGlobalName,
        'create' => ['not_applicable' => true, 'name' => _l('permission_create')],
        'edit' => ['not_applicable' => true, 'name' => _l('permission_edit')],
        'delete' => ['not_applicable' => true, 'name' => _l('permission_delete')]
    ];
    $createview = [
        'view_own' => ['not_applicable' => true, 'name' => _l('permission_view_own')],
        'view'     => $viewGlobalName,
        'create' => _l('permission_create'),
        'edit' => ['not_applicable' => true, 'name' => _l('permission_edit')],
        'delete' => ['not_applicable' => true, 'name' => _l('permission_delete')]
    ];
    
    
    
    $withNotApplicableViewOwn = array_merge(['view_own' => ['not_applicable' => true, 'name' => _l('permission_view_own')]], $withoutViewOwnPermissionsArray);

    $corePermissions = [
        /*'bulk_pdf_exporter' => [
            'name'         => _l('bulk_pdf_exporter'),
            'capabilities' => [
                'view' => $viewGlobalName,
            ],
        ],*/
        /*'contracts' => [
            'name'         => _l('contracts'),
            'capabilities' => $allPermissionsArray,
        ],*/
        'cd_notes' => [
            'name'         => _l('credit_notes'),
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'sale_return' => [
            'name'         => "Sale Return",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'account_group' => [
            'name'         => "Account Group",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'items' => [
            'name'         => "Item Master",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'itemsdivision' => [
            'name'         => "Item Division",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'itemsmaingrp' => [
            'name'         => "Item Main Group",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'itemssubgrp' => [
            'name'         => "Item Sub Group",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'ratemaster' => [
            'name'         => "Rate Master",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'routemaster' => [
            'name'         => "Route Master",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'vehiclemaster' => [
            'name'         => "Vehicle Master",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'hsnmaster' => [
            'name'         => "HSN Master",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'tcsmaster' => [
            'name'         => "TCS Master",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'hierarchy' => [
            'name'         => "Hierarchy",
            'capabilities' => $oneoptionPermissionsArray,
        ],
        'salesperassign' => [
            'name'         => "Sales Person Assign",
            'capabilities' => $oneoptionPermissionsArray,
        ],
        'account_head' => [
            'name'         => "Account Head",
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        'customers' => [
            'name'         => _l('clients'),
            'capabilities' => $withNotApplicableViewOwn,
            'help'         => [
                'view_own' => _l('permission_customers_based_on_admins'),
            ],
        ],
        'enquiry' => [
            'name'         => "Enquiry",
            'capabilities' => $allPermissionsArray,
        ],
        'tour' => [
            'name'         => "Tour Plan",
            'capabilities' => $allPermissionsArray,
        ],
        'daily_sale' => [
            'name'         => "Daily Sale Reports",
            'capabilities' => $onlyview,
        ],
        'cummulatives_sale' => [
            'name'         => "Cummulatives Sale Reports",
            'capabilities' => $onlyview,
        ],
        'orders' => [
            'name'         => "order",
            'capabilities' => $allPermissionsArray,
        ],
        'challan' => [
            'name'         => "Challan",
            'capabilities' => $allPermissionsArray,
        ],
        'invoices' => [
            'name'         => _l('invoices'),
            'capabilities' => $onlyview,
        ],
        'gatepass' => [
            'name'         => "Gatepass",
            'capabilities' => $createview,
        ],
        /*'email_templates' => [
            'name'         => _l('email_templates'),
            'capabilities' => [
                'view' => $viewGlobalName,
                'edit' => _l('permission_edit'),
            ],
        ],
        'estimates' => [
            'name'         => _l('estimates'),
            'capabilities' => $allPermissionsArray,
        ],*/
        /*'expenses' => [
            'name'         => _l('expenses'),
            'capabilities' => $allPermissionsArray,
        ],*/
        
        
        
        
        
        
        
        
        
        
        
        /*'knowledge_base' => [
            'name'         => _l('knowledge_base'),
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],*/
        /*'payments' => [
            'name'         => _l('payments'),
            'capabilities' => $withNotApplicableViewOwn,
            'help'         => [
                'view_own' => _l('permission_payments_based_on_invoices'),
            ],
        ],*/
        /*'projects' => [
            'name'         => _l('projects'),
            'capabilities' => $withNotApplicableViewOwn,
            'help'         => [
                'view'     => _l('help_project_permissions'),
                'view_own' => _l('permission_projects_based_on_assignee'),
            ],
        ],
        'proposals' => [
            'name'         => _l('proposals'),
            'capabilities' => $allPermissionsArray,
        ],*/
        /*'reports' => [
            'name'         => _l('reports'),
            'capabilities' => [
                'view' => $viewGlobalName,
            ],
        ],*/
        'roles' => [
            'name'         => _l('roles'),
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],
        
        /*'view_own' => ['not_applicable' => true, 'name' => _l('permission_view_own')],
        'view'     => $viewGlobalName,
        'create' => ['not_applicable' => true, 'name' => _l('permission_create')],
        'edit' => ['not_applicable' => true, 'name' => _l('permission_edit')],
        'delete' => ['not_applicable' => true, 'name' => _l('permission_delete')]*/
        
        'settings' => [
            'name'         => _l('settings'),
            'capabilities' => [
                'view_own' => ['not_applicable' => true, 'name' => _l('permission_view_own')],
                'view' => $viewGlobalName,
                'create' => ['not_applicable' => true, 'name' => _l('permission_create')],
                'edit' => _l('permission_edit'),
                'delete' => ['not_applicable' => true, 'name' => _l('permission_delete')]
            ],
        ],
        /*'staff' => [
            'name'         => _l('staff'),
            'capabilities' => $withoutViewOwnPermissionsArray,
        ],*/
        
        /*'subscriptions' => [
            'name'         => _l('subscriptions'),
            'capabilities' => $allPermissionsArray,
        ],
        'tasks' => [
            'name'         => _l('tasks'),
            'capabilities' => $withNotApplicableViewOwn,
             'help'        => [
                'view'     => _l('help_tasks_permissions'),
                'view_own' => _l('permission_tasks_based_on_assignee'),
            ],
        ],
        'checklist_templates' => [
            'name'         => _l('checklist_templates'),
            'capabilities' => [
                'create' => _l('permission_create'),
                'delete' => _l('permission_delete'),
            ],
        ],*/
    ];

    /*$addLeadsPermission = true;
    if (isset($data['staff_id']) && $data['staff_id']) {
        $is_staff_member = is_staff_member($data['staff_id']);
        if (!$is_staff_member) {
            $addLeadsPermission = false;
        }
    }

    if ($addLeadsPermission) {
        $corePermissions['leads'] = [
            'name'         => _l('leads'),
            'capabilities' => [
                'view'   => $viewGlobalName,
                'delete' => _l('permission_delete'),
            ],
            'help' => [
                'view' => _l('help_leads_permission_view'),
            ],
        ];
    }*/

    return hooks()->apply_filters('staff_permissions', $corePermissions, $data);
}

function get_dist_name($id)
{
    $CI = &get_instance();
    $CI->db->select('company')->from(db_prefix() . 'clients')->where('userid', $id);

    return $CI->db->get()->row()->company;
}
/**
 * Get staff by ID or current logged in staff
 * @param  mixed $id staff id
 * @return mixed
 */
function get_staff($id = null)
{
    if (empty($id) && isset($GLOBALS['current_user'])) {
        return $GLOBALS['current_user'];
    }

    // Staff not logged in
    if (empty($id)) {
        return null;
    }

    if (!class_exists('staff_model', false)) {
        get_instance()->load->model('staff_model');
    }

    return get_instance()->staff_model->get($id);
}

function get_staff_permission($id)
{
    if (empty($id) && isset($GLOBALS['current_user'])) {
        return $GLOBALS['current_user'];
    }
    // Staff not logged in
    if (empty($id)) {
        return null;
    }

    $CI = & get_instance();
    $CI->db->select('*');
    $CI->db->from(db_prefix() . 'staff');
    $CI->db->where('staffid', $id);
    $staff_details =  $CI->db->get()->row();
    
    $CI->db->select(db_prefix() . 'setup.FIRMNAME,'.db_prefix() . 'setup.YEARFROM,'.db_prefix() . 'setup.YEARTO,'.db_prefix() . 'setup.PlantID');
        $CI->db->from(db_prefix() . 'setup');
        
    if($staff_details->admin == "1"){
        
    }else{
        $CI->db->join(db_prefix() . 'staff_permissions', '' . db_prefix() . 'staff_permissions.plant_id = ' . db_prefix() . 'setup.PlantID AND '. db_prefix() . 'staff_permissions.year = ' . db_prefix() . 'setup.FY');
        $CI->db->where(db_prefix() . 'staff_permissions.staff_id', $id);
        $CI->db->group_by(db_prefix() . 'staff_permissions.year,'.db_prefix() . 'staff_permissions.plant_id');
    }
    
    
    return $CI->db->get()->result_array();
}

/**
 * Return staff profile image url
 * @param  mixed $staff_id
 * @param  string $type
 * @return string
 */
function staff_profile_image_url($staff_id, $type = 'small')
{
    $url = base_url('assets/images/user-placeholder.jpg');

    if ((string) $staff_id === (string) get_staff_user_id() && isset($GLOBALS['current_user'])) {
        $staff = $GLOBALS['current_user'];
    } else {
        $CI = & get_instance();
        $CI->db->select('profile_image')
        ->where('staffid', $staff_id);

        $staff = $CI->db->get(db_prefix() . 'staff')->row();
    }

    if ($staff) {
        if (!empty($staff->profile_image)) {
            $profileImagePath = 'uploads/staff_profile_images/' . $staff_id . '/' . $type . '_' . $staff->profile_image;
            if (file_exists($profileImagePath)) {
                $url = base_url($profileImagePath);
            }
        }
    }

    return $url;
}

/**
 * Staff profile image with href
 * @param  boolean $id        staff id
 * @param  array   $classes   image classes
 * @param  string  $type
 * @param  array   $img_attrs additional <img /> attributes
 * @return string
 */
function staff_profile_image($id, $classes = ['staff-profile-image'], $type = 'small', $img_attrs = [])
{
    $url = base_url('assets/images/user-placeholder.jpg');

    $id = trim($id);

    $_attributes = '';
    foreach ($img_attrs as $key => $val) {
        $_attributes .= $key . '=' . '"' . html_escape($val) . '" ';
    }

    $blankImageFormatted = '<img src="' . $url . '" ' . $_attributes . ' class="' . implode(' ', $classes) . '" />';

    if ((string) $id === (string) get_staff_user_id() && isset($GLOBALS['current_user'])) {
        $result = $GLOBALS['current_user'];
    } else {
        $CI     = & get_instance();
        $result = $CI->app_object_cache->get('staff-profile-image-data-' . $id);

        if (!$result) {
            $CI->db->select('profile_image,firstname,lastname');
            $CI->db->where('staffid', $id);
            $result = $CI->db->get(db_prefix() . 'staff')->row();
            $CI->app_object_cache->add('staff-profile-image-data-' . $id, $result);
        }
    }

    if (!$result) {
        return $blankImageFormatted;
    }

    if ($result && $result->profile_image !== null) {
        $profileImagePath = 'uploads/staff_profile_images/' . $id . '/' . $type . '_' . $result->profile_image;
        if (file_exists($profileImagePath)) {
            $profile_image = '<img ' . $_attributes . ' src="' . base_url($profileImagePath) . '" class="' . implode(' ', $classes) . '" />';
        } else {
            return $blankImageFormatted;
        }
    } else {
        $profile_image = '<img src="' . $url . '" ' . $_attributes . ' class="' . implode(' ', $classes) . '" />';
    }

    return $profile_image;
}

/**
 * Get staff full name
 * @param  string $userid Optional
 * @return string Firstname and Lastname
 */
function get_staff_full_name($userid = '')
{
    $tmpStaffUserId = get_staff_user_id();
    if ($userid == '' || $userid == $tmpStaffUserId) {
        if (isset($GLOBALS['current_user'])) {
            return $GLOBALS['current_user']->firstname . ' ' . $GLOBALS['current_user']->lastname;
        }
        $userid = $tmpStaffUserId;
    }

    $CI = & get_instance();

    $staff = $CI->app_object_cache->get('staff-full-name-data-' . $userid);

    if (!$staff) {
        $CI->db->where('staffid', $userid);
        $staff = $CI->db->select('firstname,lastname')->from(db_prefix() . 'staff')->get()->row();
        $CI->app_object_cache->add('staff-full-name-data-' . $userid, $staff);
    }

    return html_escape($staff ? $staff->firstname . ' ' . $staff->lastname : '');
}

/**
 * Get Root Company name
 
 */
function get_root_company_name($compid = '')
{
    
    $CI = & get_instance();
    $selected_year = $CI->session->userdata("finacial_year");
    $CI->db->select('FIRMNAME,FY');
    $CI->db->from(db_prefix() . 'setup');
    $CI->db->where('PlantID', $compid);
    $CI->db->where('FY', $selected_year);
    $company_data = $CI->db->get()->row();
    if ($company_data) {
        return $company_data->FIRMNAME."(".$company_data->FY.")";
    }
}

function get_days_new($feature_name = '')
{
    
    $CI = & get_instance();
    $selected_year = $CI->session->userdata("finacial_year");
    $selected_company = $CI->session->userdata("root_company");
    $curr_user = $GLOBALS['current_user'];
    $CI->db->select('days');
    //$CI->db->from(db_prefix() . 'staff_permissions');
    $CI->db->LIKE('feature', $feature_name);
    $CI->db->where('staff_id', $curr_user);
    $CI->db->where('plant_id', $selected_company);
    $CI->db->where('year', $selected_year);
     return $CI->db->get(db_prefix() . 'staff_permissions')->row();
    
    
}

function get_route_name($routeid = '',$selected_company)
{
    
    $CI = & get_instance();
    
    $selected_company = $CI->session->userdata("root_company");
    $CI->db->where('PlantID', $selected_company);
    $CI->db->where('RouteID', $routeid);
    $route_data = $CI->db->get(db_prefix() . 'route')->row();
    if ($route_data) {
        return $route_data->name;
    }
}

function get_account_details($ChallanID = '',$selected_company)
{
    
    $CI = & get_instance();
    $CI->db->select('AccountID');
    $CI->db->from(db_prefix() . 'ordermaster');
    $CI->db->where('ChallanID', $ChallanID);
    $CI->db->where('PlantID', $selected_company);
    $acc_data = $CI->db->get()->result_array();
    return $acc_data;
    
}

function get_travel_detail_by_staff_id($staff_id = '',$date)
{
    
    $CI = & get_instance();
    $CI->db->select('*');
    $CI->db->from(db_prefix() . 'travel_report');
    $CI->db->where('staff_id', $staff_id);
    $CI->db->where('date', $date);
    $travel_data = $CI->db->get()->result_array();
    return $travel_data;
    
}

function get_party_detail($AccountID = '',$selected_company)
{
    
    $CI = & get_instance();
    $CI->db->select('company,state,StationName,city');
    $CI->db->from(db_prefix() . 'clients');
    $CI->db->where('AccountID', $AccountID);
    $CI->db->where('PlantID', $selected_company);
    $acc_details = $CI->db->get()->row();
    return $acc_details;
    /*if ($route_data) {
        return $route_data->name;
    }*/
}

/**
 * Get Root Company name
 
 */
function get_all_root_company($compid = '')
{
    
    $CI = & get_instance();
    $CI->db->select('company_name,id');
    $CI->db->from(db_prefix() . 'rootcompany');
    //$CI->db->where('id', $compid);
    return $CI->db->get()->result_array();
    /*if ($company_data) {
        return $company_data;
    }*/
}

/**
 * Get staff default language
 * @param  mixed $staffid
 * @return mixed
 */
function get_staff_default_language($staffid = '')
{
    if (!is_numeric($staffid)) {
        // checking for current user if is admin
        if (isset($GLOBALS['current_user'])) {
            return $GLOBALS['current_user']->default_language;
        }

        $staffid = get_staff_user_id();
    }
    $CI = & get_instance();
    $CI->db->select('default_language');
    $CI->db->from(db_prefix() . 'staff');
    $CI->db->where('staffid', $staffid);
    $staff = $CI->db->get()->row();
    if ($staff) {
        return $staff->default_language;
    }

    return '';
}

function get_staff_recent_search_history($staff_id = null)
{
    $recentSearches = get_staff_meta($staff_id ? $staff_id : get_staff_user_id(), 'recent_searches');

    if ($recentSearches == '') {
        $recentSearches = [];
    } else {
        $recentSearches = json_decode($recentSearches);
    }

    return $recentSearches;
}

function update_staff_recent_search_history($history, $staff_id = null)
{
    $totalRecentSearches = hooks()->apply_filters('total_recent_searches', 5);
    $history             = array_reverse($history);
    $history             = array_unique($history);
    $history             = array_splice($history, 0, $totalRecentSearches);

    update_staff_meta($staff_id ? $staff_id : get_staff_user_id(), 'recent_searches', json_encode($history));

    return $history;
}


/**
 * Check if user is staff member
 * In the staff profile there is option to check IS NOT STAFF MEMBER eq like contractor
 * Some features are disabled when user is not staff member
 * @param  string  $staff_id staff id
 * @return boolean
 */
function is_staff_member($staff_id = '')
{
    $CI = & get_instance();
    if ($staff_id == '') {
        if (isset($GLOBALS['current_user'])) {
            return $GLOBALS['current_user']->is_not_staff === '0';
        }
        $staff_id = get_staff_user_id();
    }

    $CI->db->where('staffid', $staff_id)
    ->where('is_not_staff', 0);

    return $CI->db->count_all_results(db_prefix() . 'staff') > 0 ? true : false;
}
