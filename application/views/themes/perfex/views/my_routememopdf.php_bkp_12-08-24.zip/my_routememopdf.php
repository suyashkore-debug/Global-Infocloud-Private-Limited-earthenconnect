<?php
	
	defined('BASEPATH') or exit('No direct script access allowed');
	
	
	$dimensions = $pdf->getPageDimensions();
	$pdf = new TCPDF('L', 'mm', 'A4'); // 'L' specifies landscape orientation
	
	// Set margins
	$pdf->SetMargins(5, 7, 5 , 0);
	
	// Add a page
	$pdf->AddPage();
	
	
	
	$get_order_list = get_order_list($invoice->ChallanID);
	$count = 0;
	$count_order = count($get_order_list);
	$GetLoggedInName = GetLoginFullName();
	$html = '';
	
	$GetLoggedInName = GetLoginFullName();
	$html = '';
	
	$FY = $invoice->FY;
	$PlantID = $invoice->PlantID;
	$PlantDetail = GetPlantDetails($PlantID,$FY);
	
	$Order_item = array();
	$OrderIds = array();
	$AccountIds = array();
	$Accountdetail = array();
	$Order_itemdetail = array();
	$Crate_detail = array();
	$Crate_total = array();
	$Qty_total = array();
	// Existing order
	$challan    = getNew($invoice->ChallanID);
	// echo "<pre>";
	// print_r($challan);
	foreach ($challan as $key => $code) {
		$new_arr = array(
		'ItemID' => $code["ItemID"],
		'description' => $code["description"],
		);
		$arr_company = array(
		'AccountID' => $code["AccountID"],
		'company' => $code["company"],
		);
		$arr_crate = array(
		'AccountID' => $code["AccountID"],
		'ItemID' => $code["ItemID"],
		'Crates' => ($code["BilledQty"]/$code["CaseQty"]),
		);
		$arr_Pkt = array(
		'AccountID' => $code["AccountID"],
		'ItemID' => $code["ItemID"],
		'Qty' => $code["BilledQty"],
		);
		
		$new_arr_crate = array(
		'AccountID' => $code["AccountID"],
		'Crates' => $code["Crates"]+$code["Cases"],
		);
		
		array_push($Qty_total, $arr_Pkt);
		array_push($Crate_total, $arr_crate);
		array_push($Crate_detail, $new_arr_crate);
		array_push($Order_itemdetail, $new_arr);
		array_push($Order_item, $code["ItemID"]);
		array_push($OrderIds, $code["OrderID"]);
		array_push($AccountIds, $code["AccountID"]);
		array_push($Accountdetail, $arr_company);
	}
	$Order_item =  array_unique($Order_item);
	//$Order_itemdetail =  array_unique($Order_itemdetail);
	$OrderIds =  array_unique($OrderIds);
	$AccountIds =  array_unique($AccountIds);
	
	$Itemdetails = array_column($Order_itemdetail, 'ItemID');
	// Get unique AccountID values
	$uniqueItemsdetails = array_unique($Itemdetails);
	// Filter the original array to keep only unique entries
	$uniqueAccountdetail = array_filter($Order_itemdetail, function($item) use (&$uniqueItemsdetails) {
		// If the AccountID exists in uniqueAccountIds, keep the item and remove the AccountID from uniqueAccountIds
		if (in_array($item['ItemID'], $uniqueItemsdetails)) {
			// Remove the AccountID from uniqueAccountIds to ensure uniqueness
			$uniqueItemsdetails = array_diff($uniqueItemsdetails, [$item['ItemID']]);
			return true;
		}
		return false;
	});
	// Reset array keys
	$Order_itemdetail = array_values($uniqueAccountdetail);
	
	
	$accountIds = array_column($Accountdetail, 'AccountID');
	// Get unique AccountID values
	$uniqueAccountIds = array_unique($accountIds);
	// Filter the original array to keep only unique entries
	$uniqueAccountdetail = array_filter($Accountdetail, function($item) use (&$uniqueAccountIds) {
		// If the AccountID exists in uniqueAccountIds, keep the item and remove the AccountID from uniqueAccountIds
		if (in_array($item['AccountID'], $uniqueAccountIds)) {
			// Remove the AccountID from uniqueAccountIds to ensure uniqueness
			$uniqueAccountIds = array_diff($uniqueAccountIds, [$item['AccountID']]);
			return true;
		}
		return false;
	});
	// Reset array keys
	$Accountdetail = array_values($uniqueAccountdetail);
	
	
	
	// echo "<pre>";
	// print_r($uniqueAccountdetail);
	// print_r($Crate_detail);
	$title = "ROUTE MEMO";
	
	//$pdf->Ln(hooks()->apply_filters('pdf_info_and_table_separator', 1));
	//$html .= '<div class="page-break-after: always;">';
	$html .= '<table style="width: 100%; font-size:10px;" border="1" >';
	
	$html .= '<thead>';
	$html .= '<tr >
	<th colspan="34" style="border: 1px solid #333;"><p style="text-align:center;font-size:10px;"><b>'.$title.'</b><br><b>'.$PlantDetail->FIRMNAME.'</b><br><b>'.$PlantDetail->ADDRESS1.' '.$PlantDetail->ADDRESS2.'<br></b><b>GSTIN '.$PlantDetail->GSTNO.', <i>fssai</i> Lic.no '.$PlantDetail->FLNO1.' </b><br><b>Contact No. : '.$PlantDetail->PHONENO.'</b></p></th>
	</tr>';
	
	$driver = (isset($invoice) ? $invoice->driver_fn." ".$invoice->driver_ln : '');
	$width="3%";
	$html .= '</thead>';
	$html .= '<tbody>';
	$html .= '
	<tr>
	<td colspan="8">Challan No : <b>'.$invoice->ChallanID.'</b></td>
	<td colspan="8">Date : <b>'._d(substr($invoice->Transdate,0,10)).'</b></td>
	<td colspan="8">Vehicle No : <b>'.$invoice->VehicleID.'</b></td>
	<td colspan="18">Name : '.$driver.'</td>
	</tr>';
	
	$colmn_width = 8.6;
	$html.= '<tr>
	<td width="16%" style="height:50px;">FG Code</td>';
	$totrow = 22;
	$arr_nomes = array();
	$x = 53;
	$y = 50;
	$m = 1;
	foreach ($Order_item as $code ) {
	    $new_array = array($code,$x,$y);
	    array_push($arr_nomes,$new_array);
	    $x = $x + $colmn_width;
		$html.= '<td width="'.$width.'" ></td>';
		$totrow --;
		$m++;
	}
	if($totrow >0){
		for($i = 1; $i <= $totrow ;$i++){
		    $x = $x + $colmn_width;
		    $new_array = array('',$x,$y);
	        array_push($arr_nomes,$new_array);
			$html.= '<td width="'.$width.'" ></td>';
			//$totrow--;
		}
	}
	$new_array = array('',$x,$y);
    array_push($arr_nomes,$new_array);
    $x = $x + $colmn_width;
    $new_array = array('',$x,$y);
    array_push($arr_nomes,$new_array);
    $x = $x + $colmn_width;
    $new_array = array('',$x,$y);
    $x = $x + $colmn_width;
    array_push($arr_nomes,$new_array);
	$html.= '<td width="'.$width.'" ></td>';
	$html.= '<td width="'.$width.'" ></td>';
	$html.= '<td width="'.$width.'" ></td>';
	
	
	$new_array = array('CR Send',$x,$y);
	array_push($arr_nomes,$new_array);
	$x = $x + $colmn_width;
	$html.= '<td width="'.$width.'" ></td>';
	
	$new_array = array('CR Rcvd.',$x,$y);
	array_push($arr_nomes,$new_array);
	$x = $x + $colmn_width;
	$html.= '<td width="'.$width.'" ></td>';
	
	$new_array = array('Sign',$x,$y);
	array_push($arr_nomes,$new_array);
	$html.= '<td width="'.$width.'" ></td>';
	$html.= '</tr>';
	
	
	
	$arr_nomes1 = array();
	$x = 53;
	$y = 92;
	$html.= '<tr>
	<td width="16%" style="height:120px;">Party Name</td>';
	$totrow = 22;
	
	foreach ($Order_item as $itemid) {
		foreach($Order_itemdetail as $key => $desc){
			if($desc['ItemID'] == $itemid){
			    $new_array = array(substr($desc['description'],0,20),$x,$y);
	            array_push($arr_nomes1,$new_array);
	            $x = $x + $colmn_width;
				$html.= '<td width="'.$width.'" style="font-size:8px!important;"></td>';
				$totrow --;
			}
		}
	}
	if($totrow >0){
		for($i = 1; $i <= $totrow ;$i++){
		    $x = $x + $colmn_width;
		    $new_array = array('',$x,$y);
		    array_push($arr_nomes1,$new_array);
			$html.= '<td width="'.$width.'" ></td>';
			//$totrow--;
		}
	}
	$totrow2 = 6;
	for($i = 1; $i <= $totrow2 ;$i++){
	    $x = $x + $colmn_width;
	    $new_array = array('',$x,$y);
	    array_push($arr_nomes1,$new_array);
		$html.= '<td width="'.$width.'" ></td>';
	}
	$html.= '</tr>';    
	
	foreach ($Accountdetail as $key => $code) {
		$totrow = 22;
		$html.= '<tr>
		<td width="16%" >'.substr($code['company'],0,21).'</td>';
		
		foreach ($Order_item as $itemid) {
			$notmatch = true;
			foreach($Crate_total as $key => $crate){
				if($crate['ItemID'] == $itemid && $crate['AccountID'] == $code['AccountID']){
					$html.= '<td width="'.$width.'" style="text-align:right;">'.number_format($crate['Crates'],0).'</td>';
					$totrow --;
					$notmatch = false;
				}
			}
			if($notmatch == true){
				$html.= '<td width="'.$width.'" ></td>';
				$totrow --;
			}
		}
		if($totrow >0){
			for($i = 1; $i <= $totrow ;$i++){
				$html.= '<td width="'.$width.'" ></td>';
			}
		}
		$html.= '<td width="'.$width.'" ></td>';
		$html.= '<td width="'.$width.'" ></td>';
		$html.= '<td width="'.$width.'" ></td>';
		$chk = 0;
		// print_r($Crate_detail);
		foreach($Crate_detail as $key => $crate){
			if($code['AccountID'] == $crate['AccountID']){
				if($chk <= 0){
					$html.= '<td width="'.$width.'" style="text-align:right;">'.number_format($crate['Crates'],0).'</td>';
					$chk++;
				}
			}
		}
		$html.= '<td width="'.$width.'" ></td>';
		$html.= '<td width="'.$width.'" ></td>';
		$html.='</tr>';
		$totrow3 = 22;
		$html.= '<tr>
		<td width="16%" >Pkt Qty</td>';
		
		foreach ($Order_item as $itemid) {
			$notmatch = true;
			foreach($Qty_total as $key => $crate){
				if($crate['ItemID'] == $itemid && $crate['AccountID'] == $code['AccountID']){
					$html.= '<td width="'.$width.'" style="text-align:right;">'.(int) $crate['Qty'].'</td>';
					$totrow3 --;
					$notmatch = false;
				}
			}
			if($notmatch == true){
				$html.= '<td width="'.$width.'" ></td>';
				$totrow3 --;
			}
		}
		if($totrow3 >0){
			for($i = 1; $i <= $totrow3 ;$i++){
				$html.= '<td width="'.$width.'" ></td>';
			}
		}
		$html.= '<td width="'.$width.'" ></td>';
		$html.= '<td width="'.$width.'" ></td>';
		$html.= '<td width="'.$width.'" ></td>';
		$chk = 0;
		// print_r($Crate_detail);
		foreach($Crate_detail as $key => $crate){
			if($code['AccountID'] == $crate['AccountID']){
				if($chk <= 0){
					$html.= '<td width="'.$width.'" style="text-align:right;"></td>';
					$chk++;
				}
			}
		}
		$html.= '<td width="'.$width.'" ></td>';
		$html.= '<td width="'.$width.'" ></td>';
		$html.='</tr>';
		
		$totrow2 = 28;
		$html.= '<tr>
		<td width="16%" >Fresh Return</td>';
		
		if($totrow2 >0){
			for($i = 1; $i <= $totrow2 ;$i++){
				$html.= '<td width="'.$width.'" style="height:22px;" ></td>';
			}
		}
		$html.='</tr>';
		$totrow3 = 28;
		$html.= '<tr>
		<td width="16%" >Damage Return</td>';
		
		if($totrow3 >0){
			for($i = 1; $i <= $totrow3 ;$i++){
				$html.= '<td width="'.$width.'" style="height:22px;"></td>';
			}
		}
		$html.='</tr>';
		
	}
	
	$html .= '</tbody>';
	$html .= '</table>';
	
	// $html .= '<pagebreak> ';
	
	
	$pdf->writeHTML($html, true, false, false, false, '');
	
	$ttPages = $pdf->getNumPages();
//for($i=1; $i<=$ttPages; $i++) {
    // set page
    //$pdf->setPage($i);
    // all columns of current page
    foreach( $arr_nomes as $num => $arrCols ) {
        $x = $pdf->xywalter[$num][0] + $arrCols[1]; // new X
        $y = $pdf->xywalter[$num][1] + $arrCols[2]; // new Y
        $n = $arrCols[0]; // column name
		$pdf->SetFont('helvetica', '', 8);
        // transforme Rotate
        $pdf->StartTransform();
        // Rotate 90 degrees counter-clockwise
        $pdf->Rotate(90, $x, $y);
        $pdf->Text($x, $y, $n);
        // Stop Transformation
        $pdf->StopTransform();
    }
    
    foreach( $arr_nomes1 as $num => $arrCols ) {
        $x = $pdf->xywalter[$num][0] + $arrCols[1]; // new X
        $y = $pdf->xywalter[$num][1] + $arrCols[2]; // new Y
        $n = $arrCols[0]; // column name
		
		$pdf->SetFont('helvetica', '', 8);
        // transforme Rotate
        $pdf->StartTransform();
        // Rotate 90 degrees counter-clockwise
        $pdf->Rotate(90, $x, $y);
        $pdf->Text($x, $y, $n);
        // Stop Transformation
        $pdf->StopTransform();
    }
//}
	
	// Output the PDF
	$pdf->Output('example.pdf', 'I');
?>			