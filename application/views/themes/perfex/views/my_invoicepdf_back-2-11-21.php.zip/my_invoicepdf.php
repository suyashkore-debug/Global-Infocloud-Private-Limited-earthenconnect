<?php

defined('BASEPATH') or exit('No direct script access allowed');


$dimensions = $pdf->getPageDimensions();

$pdf->SetMargins(3, 0, 3, 0);
$pdf->Ln(0);



$get_order_list = get_order_list($invoice->ChallanID);
$count = 0;
$count_order = count($get_order_list);


    foreach ($get_order_list as $key => $order_detail) {
       
        $client_detail = get_client_detail($order_detail["AccountID"]);
        $company_detail = get_company_name_by_id($order_detail["PlantID"]);
        $gst_type = get_gst_type();
        $sales_detail = get_sales_details($invoice->ChallanID,$order_detail["OrderID"]);
        $state_detail = get_state_detail($client_detail->state);
        $billing_state_detail = get_state_detail($client_detail->billing_state);
        $shipping_state_detail = get_state_detail($client_detail->shipping_state);
        
        //$html = '<h1>Madhav Shinde'.$client_detail->company.'</h1>';
        $html = '<div class="col-md-12">
        
       
       <table style="width: 100%; font-size:14px;font-weight:400;" cellspacing="1" cellpadding="4" border="1">
        <tr >
        <td colspan="4" style="border: 1px solid #333;"><p style="text-align:center;font-size:14px;"><b>TAX INVOICE</b><br><b>'.$company_detail->company_name.'</b><br><b>'.$company_detail->address.'<br></b><b>GSTIN '.$company_detail->gst.', <i>fssai</i> Lic.no '.$company_detail->food_lic.' </b><br><b>Contact No. : '.$company_detail->mobile1." , ".$company_detail->mobile2.'</b></p></td>
        </tr>
        <tr>
        <td style="border-left: 1px solid #333;" width="20%">Invoice No.</td>
        <td style="border-right: 1px solid #333;" width="30%"><b>'.$sales_detail->SalesID.'</b></td>
        <td width="20%" style="border-left: 1px solid #333;">Ack No.</td>
        <td style="border-right: 1px solid #333;" width="30%"><b></b></td>
        </tr>
        <tr>
        <td style="border-left: 1px solid #333;" width="20%">Invoice Date</td>
        <td style="border-right: 1px solid #333;" width="30%"><b>'. substr($sales_detail->Transdate,0,10) .'</b></td>
        <td width="20%" style="border-left: 1px solid #333;">Ack Date</td>
        <td style="border-right: 1px solid #333;" width="30%"><b></b></td>
        </tr>
        <tr>
        <td style="border-left: 1px solid #333;" width="20%">Challan No</td>
        <td style="border-right: 1px solid #333;" width="30%"><b>'. $invoice->ChallanID .'</b></td>
        <td width="20%" style="border-left: 1px solid #333;">Vehicle No</td>
        <td style="border-right: 1px solid #333;" width="30%"><b>'.$invoice->VehicleID.'</b></td>
        </tr>
        <tr>
        <td style="border-left: 1px solid #333;border-bottom: 1px solid #333;" width="20%">Order No</td>
        <td style="border-right: 1px solid #333;border-bottom: 1px solid #333;" width="30%"><b>'. $order_detail["OrderID"] .'</b></td>
        <td width="20%" style="border-bottom: 1px solid #333;border-left: 1px solid #333;">eWayBillNo</td>
        <td style="border-right: 1px solid #333;border-bottom: 1px solid #333;" width="30%"><b></b></td>
        </tr>
        
        <tr>
        <td style="border-left: 1px solid #333;border-right: 1px solid #333;" width="50%" colspan="2"><b>Bill To</b></td>
        <td style="border-right: 1px solid #333;border-left: 1px solid #333;" width="50%" colspan="2"><b>Ship To</b></td>
        
        </tr>
        
        <tr>
        <td style="border-left: 1px solid #333;border-right: 1px solid #333;" width="50%" colspan="2"><b>'.$client_detail->company.'</b></td>
        <td style="border-right: 1px solid #333;border-left: 1px solid #333;" width="50%" colspan="2"><b>'.$client_detail->company.'</b></td>
        
        </tr>';
        
        if(is_null($client_detail->address3)){
            
        }else{
        $html .= '<tr>
        <td style="border-left: 1px solid #333;border-right: 1px solid #333;" width="50%" colspan="2">'.$client_detail->address3.'</td>
        <td style="border-right: 1px solid #333;border-left: 1px solid #333;" width="50%" colspan="2">'.$client_detail->address3.'</td>
        </tr>';
        }
        $city_name = get_city_by_id($client_detail->city);
        if(empty($city_name)){
            $new_city_name = $client_detail->city;
        }else {
            $new_city_name = $city_name->city_name;
        }
        $html .= '<tr>
        <td style="border-left: 1px solid #333;border-right: 1px solid #333;" width="50%" colspan="2">'.$client_detail->address.'</td>
        <td style="border-right: 1px solid #333;border-left: 1px solid #333;" width="50%" colspan="2">'.$client_detail->address.'</td>
        </tr>
        
        <tr>
        <td style="border-left: 1px solid #333;border-right: 1px solid #333;" width="50%" colspan="2">'.$new_city_name.'</td>
        <td style="border-right: 1px solid #333;border-left: 1px solid #333;" width="50%" colspan="2">'.$new_city_name.'</td>
        </tr>
        
        <tr>
        <td style="border-left: 1px solid #333;border-right: 1px solid #333;" width="50%" colspan="2">GSTIN  <b>'.$client_detail->vat.'</b></td>
        <td style="border-right: 1px solid #333;border-left: 1px solid #333;" width="50%" colspan="2">GSTIN  <b>'.$client_detail->vat.'</b></td>
        </tr>
        
        <tr>
        <td style="border-left: 1px solid #333;border-right: 1px solid #333;" width="50%" colspan="2">Mobile No  <b>'.$client_detail->cmobile.'</b></td>
        <td style="border-right: 1px solid #333;border-left: 1px solid #333;" width="50%" colspan="2">Mobile No  <b>'.$client_detail->cmobile.'</b></td>
        </tr>
        
        <tr>
        <td style="border-left: 1px solid #333;border-right: 1px solid #333;border-bottom: 1px solid #333;" width="50%" colspan="2">Food Lic No  <b>'.$client_detail->FLNO1.'</b></td>
        <td style="border-right: 1px solid #333;border-bottom: 1px solid #333;border-left: 1px solid #333;" width="50%" colspan="2">Food Lic No  <b>'.$client_detail->FLNO1.'</b></td>
        </tr>
        
        </table>
        </div>';
        $pdf->writeHTML($html, true, false, false, false, '');
        
        
        $rowspan = 'rowspan="2"';
        $item_name_width = "26%";
        $hsn_width = "9%";
       
    
    $pdf->Ln(0);

    
    // The items table
//$items = get_items_table_data($invoice, 'invoice', 'pdf');


$html2 = '<div class="col-md-12">

<table style="width: 100%; font-size:12px;font-weight:400;" cellspacing="1" cellpadding="4" border="1">
        <tr>
        <td width="3.5%" '.$rowspan.' style="text-align:center;"><b>Sr.No.</b></td>
        <td width="'.$item_name_width.'" '.$rowspan.'><b>Name of Product</b></td>
        <td width="'.$hsn_width.'" '.$rowspan.'><b>HSN Code</b></td>
        <td width="6%" '.$rowspan.' style="text-align:center;"><b>CR/CS Pack</b></td>
        <td width="6%" '.$rowspan.' style="text-align:center;"><b>CR/CS Qty.</b></td>
        <td width="7%" '.$rowspan.' style="text-align:center;"><b>In Units</b></td>
        <td width="5%" '.$rowspan.' style="text-align:center;"><b>Rate</b></td>
        <td width="7%" '.$rowspan.' style="text-align:center;"><b>Amount</b></td>
        <td width="6.2%" '.$rowspan.' style="text-align:center;"><b>Disc Amount</b></td>
        <td width="7.3%" '.$rowspan.' style="text-align:center;"><b>Taxable Amount</b></td>';
    /*if($client_detail->state == "UP"){
        $html2 .= '<td colspan="2" style="text-align:center;">GST</td>
        <td colspan="2" style="text-align:center;">SGST</td>';
    } else{
        $html2 .= '<td colspan="2" style="text-align:center;">IGST</td>';
    }*/
    $html2 .= '<td style="text-align:center;" width="7%"><b>GST</b></td>';
    $html2 .= '<td style="text-align:center;" width="10%"><b>Total</b></td>';
    //$html2 .= '<td '.$rowspan.' style="text-align:center;">Total Amt</td>';    
    $html2 .= '</tr>';  
    /*if($client_detail->state == "UP"){
    $html2 .= '<tr>
        
        <td style="text-align:center;">Rate</td>
        <td style="text-align:center;">Amt</td>
        <td style="text-align:center;">Rate</td>
        <td style="text-align:center;">Amt</td>
        </tr>';    
    }else {
        $html2 .= '<tr>
        
        <td style="text-align:center;">Rate</td>
        <td style="text-align:center;">Amt</td>
        </tr>'; 
    }*/
    
    $html2 .= '<tr>
        
        <td style="text-align:center;"><b>%</b></td>
        <td style="text-align:center;"><b>Amount</b></td>
        </tr>';
    
    $i = 1;
        $qty = 0;
        $units = 0;
        $amt = 0;
        $dis_amt = 0;
        $taxable_amt = 0;
        $csgst_total = 0;
        $csgst = 0;
        $gst_total = 0;
        $order_total = 0;
        $empty_height= 280;
        foreach ($gst_type as $gstkey => $gastvalue) {
                # code...
                $gst.$gastvalue["taxrate"] = 0;
                
            }
        
    $inv_item = get_item_by_order_id($order_detail["OrderID"]);    
        foreach ($inv_item as $item) {
            $hsn_code = get_hsn_byitem_id($item['ItemID']);
            if($i>1){
                $empty_height = $empty_height - 30;
            }
           $html2 .= '<tr>'; 
           $html2 .= '<td style="text-align:center;">'.$i.'</td>'; 
           $html2 .= '<td class="description" align="left;" width="'.$item_name_width.'"><b>'.$item['description'].'</b></td>';
           $html2 .= '<td width="'.$hsn_width.'" style="text-align:center;"><b>'.$hsn_code->hsn_code.'</b></td>';
           $html2 .= '<td style="text-align:right;"><b>'. (int) $item['CaseQty'].'</b></td>';
           if(is_null($item['eOrderQty'])){
               
               $html2 .= '<td style="text-align:right;"><b>'. (int) $item['OrderQty'] / $item['CaseQty'].'</b></td>';
               $html2 .= '<td style="text-align:right;"><b>'. (int) $item['OrderQty'].'</b></td>';
               $units = $units + $item['OrderQty'];
               $qty = $qty + $item['OrderQty'] / $item['CaseQty'];
           }else{
               $html2 .= '<td style="text-align:right;"> <b>'. (int) $item['eOrderQty'] / $item['CaseQty'].'</b></td>';
               $html2 .= '<td style="text-align:right;"><b>'. (int) $item['eOrderQty'].'</b></td>';
               $units = $units + $item['eOrderQty'];
               $qty = $qty + $item['eOrderQty'] / $item['CaseQty'];
           }
           
           $html2 .= '<td style="text-align:right;"><b>'.$item['BasicRate'].'</b></td>';
           $html2 .= '<td style="text-align:right;"><b>'.$item['OrderAmt'].'</b></td>';
           $amt = $amt + $item['OrderAmt'];
           $html2 .= '<td style="text-align:right;"><b>'.round($item['DiscAmt'],2) .'</b></td>';
           $dis_amt = $dis_amt + $item['DiscAmt'];
           $html2 .= '<td style="text-align:right;"><b>'.$item['OrderAmt'].'</b></td>';
           
           $taxable_amt = $taxable_amt + $item['OrderAmt'];
           /*if($client_detail->state == "UP"){
               $cgst_rate = $item['cgst'];
               $cgst_amt = $item['cgstamt'];
            $html2 .= '<td style="text-align:right;">'.$cgst_rate.'</td>';
            $html2 .= '<td style="text-align:right;">'.$cgst_amt.'</td>';
            $csgst = $csgst + $cgst_amt;
            $html2 .= '<td style="text-align:right;">'.$cgst_rate.'</td>';
            $html2 .= '<td style="text-align:right;">'.$cgst_amt.'</td>';   
           }else {
               $html2 .= '<td style="text-align:right;">'.$item['igst'].'</td>
               <td style="text-align:right;">'.$item['igstamt'].'</td>';
               $gst_total = $gst_total + $item['igstamt'];
           }*/
           if($client_detail->state == "UP"){
               $gst_rate = $item['cgst'] + $item['sgst'];
               $scgst = $item['cgstamt'] * 2;
               $gst_total = $gst_total + $scgst;
           }else {
               $gst_rate = $item['igst'];
               $gst_total = $gst_total + $item['igstamt'];
           }
           
           
           
           $html2 .= '<td style="text-align:center;"><b>'.$gst_rate.'.00</b></td>';
           $html2 .= '<td style="text-align:right;"><b>'.$item['NetOrderAmt'].'</b></td>';
           $order_total = $order_total + $item['NetOrderAmt'];
           $html2 .= '</tr>';
           $i++;
        }
          
        
        $amt = (double) $amt;
    $html2 .='<tr>'; 
    //$html2 .='<td></td>';
    $html2 .='<td colspan="2" style="text-align:center;"><b>Total</b></td>'; 
    $html2 .='<td style="text-align:center;"></td>';
    $html2 .='<td style="text-align:center;"></td>';
    $html2 .='<td style="text-align:right;"><b>'.$qty.'</b></td>';
    $html2 .='<td style="text-align:right;"><b>'.$units.'</b></td>';
    $html2 .='<td></td>';
    $html2 .='<td style="text-align:right;"><b>'.round($amt,2).'</b></td>';
    $html2 .='<td style="text-align:right;"><b>'.round($dis_amt,2).'</b></td>';
    $html2 .='<td style="text-align:right;"><b>'.round($taxable_amt,2).'</b></td>';
    /*if($client_detail->state == "UP"){
        $html2 .='<td></td>';
        $html2 .='<td style="text-align:right;">'.round($csgst,2).'</td>';
        $html2 .='<td style="text-align:right;"></td>';
        $html2 .='<td style="text-align:right;">'.round($csgst,2).'</td>';
    }else {
        $html2 .='<td></td>';
        $html2 .='<td style="text-align:right;">'.round($gst_total,2).'</td>';
    }*/
    $html2 .='<td style="text-align:center;"><b></b></td>'; 
    $html2 .='<td style="text-align:right;"><b>'.round($order_total,2).'</b></td>';
    $html2 .='</tr>'; 
    //$html2 .='<tr>'; 
   
    //$html2 .='<td '.$empty_col.'></td>';
    //$html2 .='<td></td>';
    //$html2 .='</tr>';
    $html2 .='<tr><td colspan="12" style="height:'.$empty_height.'px;"></td></tr>';
    $html2 .='<tr>
    <td colspan="2" width="20%" style="text-align:center;"><b>GST Breakup</b></td>
    <td width="6%" style="text-align:center;"><b>GST %</b></td>
    <td width="13.9%" style="text-align:center;"><b>Taxable Amt</b></td>
    <td width="7%" style="text-align:center;"><b>CGST %</b></td>
    <td width="9%" style="text-align:center;"><b>CGST Amt</b></td>
    <td width="7%" style="text-align:center;"><b>SGST %</b></td>
    <td width="9%" style="text-align:center;"><b>SGST Amt</b></td>
    <td width="6%" style="text-align:center;"><b>IGST %</b></td>
    <td width="8%" style="text-align:center;"><b>IGST Amt</b></td>
    <td width="9%" style="text-align:center;"><b>GST Amt</b></td>
    <td width="5%" style="text-align:center;"><b>Item </b></td>
    
    </tr>';
    
    if($client_detail->state == "UP"){
    $gst_detail = get_gst_details($order_detail["OrderID"]);
    
    $gst_count = count($gst_detail);
    $i = 0;
           foreach ($gst_detail as $gvalue) {
                # code...
                
                $html2 .='<tr>';
                if($i == 0){
                    $html2 .='<td rowspan="'.$gst_count.'" colspan="2" width="20%"></td>';
                }
                $gst_per = $gvalue["cgst"] * 2;
                $gst_per = $gst_per;
                $taxable_amt = get_gst_taxable_amt($order_detail["OrderID"],$gvalue["cgst"]);
                $cs_gst_amt = get_gst_amt($order_detail["OrderID"],$gvalue["cgst"]);
                $gst_total_amt = $cs_gst_amt * 2;
                $item_count = get_gst_item_count($order_detail["OrderID"],$gvalue["cgst"]);
                $item_count_new = count($item_count);
                $html2 .='<td width="6%" style="text-align:center;"><b>'.$gst_per.'.00%</b></td>
                <td width="13.9%" style="text-align:center;"><b>'.$taxable_amt.'</b></td>
                <td width="7%" style="text-align:center;"><b>'.$gvalue["cgst"].'</b></td>
                <td width="9%" style="text-align:center;"><b>'.$cs_gst_amt.'</b></td>
                <td width="7%" style="text-align:center;"><b>'.$gvalue["cgst"].'</b></td>
                <td width="9%" style="text-align:center;"><b>'.$cs_gst_amt.'</b></td>
                <td width="6%" style="text-align:center;"></td>
                <td width="8%" style="text-align:center;"></td>
                <td width="9%" style="text-align:center;"><b>'.$gst_total_amt.'</b></td>
                <td width="5%" style="text-align:center;"><b>'.$item_count_new.'</b></td>
                
                </tr>';
            $i++;
            }
        }else {
            
            
            
            $igst_detail = get_igst_details($order_detail["OrderID"]);
    
            $igst_count = count($igst_detail);
            $i = 0;
            
           foreach ($igst_detail as $igvalue) {
                # code...
                
                $html2 .='<tr>';
                if($i == 0){
                    $html2 .='<td rowspan="'.$igst_count.'" colspan="2" width="20%"></td>';
                }
                $igst_per = $igvalue["igst"];
                $igst_per = $igst_per;
                $taxable_amt = get_igst_taxable_amt($order_detail["OrderID"],$igvalue["igst"]);
                $i_gst_amt = get_igst_amt($order_detail["OrderID"],$igvalue["igst"]);
                $i_item_count = get_igst_item_count($order_detail["OrderID"],$igvalue["igst"]);
                $i_item_count_new = count($i_item_count);
                $html2 .='<td width="6%" style="text-align:center;">'.$igst_per.'%</td>
                <td width="13.9%" style="text-align:center;">'.$taxable_amt.'</td>
                <td width="7%" style="text-align:center;"></td>
                <td width="9%" style="text-align:center;"></td>
                <td width="7%" style="text-align:center;"></td>
                <td width="9%" style="text-align:center;"></td>
                <td width="6%" style="text-align:center;">'.$igvalue["igst"].'</td>
                <td width="8%" style="text-align:center;">'.$i_gst_amt.'</td>
                <td width="9%" style="text-align:center;">'.$i_gst_amt.'</td>
                <td width="5%" style="text-align:center;">'.$i_item_count_new.'</td>
                
                </tr>';
            $i++;
           }  
        }    
    $html2 .='<tr><td colspan="12" style="height:20px;"></td></tr>';
    $html2 .='<tr>'; 
    //$html2 .='<td></td>';
    $html2 .='<td colspan="2" style="border-right:none;" width="20%"><b>Pending Crates : 0</b></td>';
    $html2 .='<td colspan="3" style="border-right:none; border-left:none;" width="20%"><b>Crates on bill : '.$order_detail["Crates"].'</b></td>';
    $html2 .='<td colspan="3" style="border-right:none;" width="20%"><b>Cases on bill  :    '.$order_detail["Cases"].'</b></td>';
    /*if($client_detail->state == "UP"){
        $colspan_taxable = 'colspan="3"';
        $colspan_taxable_amt = 'colspan="2"';
    }else {
        $colspan_taxable = 'colspan="2"';
        $colspan_taxable_amt = '';
    }*/
    
    $html2 .='<td colspan="3" width="25%"><b>Taxable Value/ Amt</b></td>';
    $html2 .='<td  style="text-align:right;" width="14.9%"><b>'.round($taxable_amt,2).'</b></td>';
    $html2 .='</tr>'; 
    $html2 .='<tr>'; 
    if($client_detail->state == "UP"){
        $bank_rowspan='rowspan="6"';
    }else {
        $bank_rowspan='rowspan="5"';
    }
    $html2 .='<td colspan="9" '.$bank_rowspan.'><b>Bank A/c Details<br>Punjab National Bank, Bank road Gorakhpur<br> IFSC Code- PUNB0187500<br>A/c No.- 1875008700013389</b></td>';
    if($client_detail->state == "UP"){
        $html2 .='<td colspan="2"><b>Add CGST</b></td>';
        $grand_csgst = $gst_total / 2;
        $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;"><b>'.round($grand_csgst,2).'</b></td>';
    }else {
        $html2 .='<td colspan="2"><b>Add IGST</b></td>';
        $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;"><b>'.round($gst_total,2).'</b></td>';
    }
    
    $html2 .='</tr>'; 
    if($client_detail->state == "UP"){
    $html2 .='<tr>'; 
    $html2 .='<td colspan="2"><b>Add SGST</b></td>';
    $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;"><b>'.round($grand_csgst,2).'</b></td>';
    $html2 .='</tr>'; 
    }
    $sale_data = get_is_tcs($order_detail["SalesID"]);
    $html2 .='<tr>'; 
    $html2 .='<td colspan="2"><b>Add TCS @ %</b></td>';
    $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;"><b>'.round($sale_data->tcs,2).'</b></td>';
    $html2 .='</tr>'; 
    $html2 .='<tr>'; 
    $html2 .='<td colspan="2"><b>Amount after GST + TCS</b></td>';
    $tcs_amt = $sale_data->tcsAmt;
    $inc_tcs_amt = $order_total + $tcs_amt;
    $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;"><b>'.round($sale_data->BillAmt,2).'</b></td>';
    $html2 .='</tr>'; 
    
    
            
    
    $html2 .='<tr>'; 
    $html2 .='<td colspan="2"><b>Previous Balance</b></td>';
    $html2 .='<td '.$colspan_taxable_amt.'></td>';
    $html2 .='</tr>';
    $html2 .='<tr>'; 
    $html2 .='<td colspan="2"><b>Balance Amt (Rnd)</b></td>';
    $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;"></td>';
    $html2 .='</tr>';
    $html2 .='<tr>'; 
    
    $html2 .='<td colspan="9"></td>';
    $html2 .='<td colspan="3"><br><br>For<b> '.$company_detail->company_name.'<br><br><br><br>Authorized Signatory</b></td>';
    $html2 .='</tr>';
    /*$html2 .='<tr>'; 
    $html2 .='<td '.$sign.'>Authorized Signature</td>';
    $html2 .='</tr>';*/
    
    $html2 .= '</table>';
    $html2 .= '</div>';
 $pdf->writeHTML($html2, true, false, false, false, ''); 
    

//$tblhtml = $items->table();
//print_r($items);
//$pdf->writeHTML($html2, true, false, false, false, '');
//$tblhtml = $items->table();

//$pdf->writeHTML($tblhtml, true, false, false, false, '');
$count++;
//$pdf->Ln(0);
if($count == $count_order){
    
}else{
    $pdf->AddPage();
}

        
        
    }


