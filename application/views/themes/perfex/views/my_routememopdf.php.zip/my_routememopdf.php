<?php
	
	defined('BASEPATH') or exit('No direct script access allowed');
	
	
	$dimensions = $pdf->getPageDimensions();
	$pdf = new TCPDF('L', 'mm', 'A4'); // 'L' specifies landscape orientation
	
	// Set margins
	$pdf->SetMargins(5, 7, 5 , 0);
	
	// Add a page
	$pdf->AddPage();
	
	// Function to write vertical text
	function writeVerticalText($pdf, $x, $y, $text) {
		$pdf->StartTransform();
		$pdf->Rotate(90, $x, $y);
		$pdf->Text($x, $y, $text);
		$pdf->StopTransform();
	}
	
	// $pdf->SetMargins(5, 7, 5, 0);
	//$pdf->Ln(0);
	
	$get_order_list = get_order_list($invoice->ChallanID);
	$count = 0;
	$count_order = count($get_order_list);
	$GetLoggedInName = GetLoginFullName();
	$html = '';
	
	$GetLoggedInName = GetLoginFullName();
	$html = '';
	
	$FY = $invoice->FY;
	$PlantID = $invoice->PlantID;
	$PlantDetail = GetPlantDetails($PlantID,$FY);
	
	$Order_item = array();
	$OrderIds = array();
	$AccountIds = array();
	$Accountdetail = array();
	$Order_itemdetail = array();
	$Crate_detail = array();
	$Crate_total = array();
	// Existing order
	$challan    = getNew($invoice->ChallanID);
	// echo "<pre>";
	// print_r($challan);
	foreach ($challan as $key => $code) {
		$new_arr = array(
		'ItemID' => $code["ItemID"],
		'description' => $code["description"],
		);
		$arr_company = array(
		'AccountID' => $code["AccountID"],
		'company' => $code["company"],
		);
		$arr_crate = array(
		'AccountID' => $code["AccountID"],
		'ItemID' => $code["ItemID"],
		'Crates' => ($code["BilledQty"]/$code["CaseQty"]),
		);
		
		$new_arr_crate = array(
		'AccountID' => $code["AccountID"],
		'Crates' => $code["Crates"],
		);
		
		array_push($Crate_total, $arr_crate);
		array_push($Crate_detail, $new_arr_crate);
		array_push($Order_itemdetail, $new_arr);
		array_push($Order_item, $code["ItemID"]);
		array_push($OrderIds, $code["OrderID"]);
		array_push($AccountIds, $code["AccountID"]);
		array_push($Accountdetail, $arr_company);
	}
	$Order_item =  array_unique($Order_item);
	$OrderIds =  array_unique($OrderIds);
	$AccountIds =  array_unique($AccountIds);
	
	$accountIds = array_column($Accountdetail, 'AccountID');
	
	// Get unique AccountID values
	$uniqueAccountIds = array_unique($accountIds);
	
	// Filter the original array to keep only unique entries
	$uniqueAccountdetail = array_filter($Accountdetail, function($item) use (&$uniqueAccountIds) {
		// If the AccountID exists in uniqueAccountIds, keep the item and remove the AccountID from uniqueAccountIds
		if (in_array($item['AccountID'], $uniqueAccountIds)) {
			// Remove the AccountID from uniqueAccountIds to ensure uniqueness
			$uniqueAccountIds = array_diff($uniqueAccountIds, [$item['AccountID']]);
			return true;
		}
		return false;
	});
	
	// Reset array keys
	$Accountdetail = array_values($uniqueAccountdetail);
	
	
	
	// echo "<pre>";
	// print_r($uniqueAccountdetail);
	// print_r($Crate_detail);
	$title = "ROUTE MEMO";
	
	$pdf->Ln(hooks()->apply_filters('pdf_info_and_table_separator', 1));
	//$html .= '<div class="page-break-after: always;">';
	$html .= '<table style="width: 100%; font-size:12px;font-weight:400;" cellspacing="1" cellpadding="3" border="1" >';
	
	$html .= '<thead>';
	$html .= '<tr >
	<th colspan="4" style="border: 1px solid #333;"><p style="text-align:center;font-size:14px;"><b>'.$title.'</b><br><b>'.$PlantDetail->FIRMNAME.'</b><br><b>'.$PlantDetail->ADDRESS1.' '.$PlantDetail->ADDRESS2.'<br></b><b>GSTIN '.$PlantDetail->GSTNO.', <i>fssai</i> Lic.no '.$PlantDetail->FLNO1.' </b><br><b>Contact No. : '.$PlantDetail->PHONENO.'</b></p></th>
	</tr>';
	
	$driver = (isset($invoice) ? $invoice->driver_fn." ".$invoice->driver_ln : '');
	$width="2.54%";
	$html .= '
	<tr>
	<td>Date</td>
	<td colspan="7"><b>'._d(substr($invoice->Transdate,0,10)).'</b></td>
	</tr>
	<tr>
	<td>Name</td>
	<td colspan="7">'.$driver.'</td>
	</tr>
	<tr>
	<td>Vehicle No</td>
	<td colspan="7"><b>'.$invoice->VehicleID.'</b></td>
	</tr>';
	
	$html.= '<tr>
	<td width="10%">FG Code</td>';
	$totrow = 28;
	
	foreach ($Order_item as $code ) {
		$html.= '<th width="'.$width.'" >'.$code.'</th>';
		$totrow --;
	}
	if($totrow >0){
		for($i = 1; $i <= $totrow ;$i++){
			$html.= '<th width="'.$width.'" ></th>';
		}
	}
	$html.= '<th width="'.$width.'" ></th>';
	$html.= '<th width="'.$width.'" ></th>';
	$html.= '<th width="'.$width.'" ></th>';
	$html.= '<th width="'.$width.'" >CR Send</th>';
	$html.= '<th width="'.$width.'" >CR Receieved</th>';
	$html.= '<th width="'.$width.'" >Rcv With Sign</th>';
	$html.= '</tr>';
	
	$html.= '<tr>
	<th width="10%">Party Name</th>';
	$totrow = 28;
	// Assume you're using an A4 page (210mm x 297mm)
	$pdf_width = 210;  // A4 width in mm
	$pdf_height = 297; // A4 height in mm
	
	// Calculate the center position
	$center_x = $pdf_width / 2;
	$center_y = $pdf_height / 2;
	
	// Adjust $x and $yStart to start from the center
	$x = $center_x - (10 / 2); // Adjust based on the width of your table
	$yStart = $center_y - (20 / 2); // Adjust based on the height of your table
	// writeVerticalText($pdf, $x, $yStart, substr($desc['description'], 0, 15))
	
	foreach ($Order_item as $itemid) {
		foreach($Order_itemdetail as $key => $desc){
			if($desc['ItemID'] == $itemid){
				$html.= '<th width="'.$width.'" style="font-size:10px;">'.substr($desc['description'], 0, 12).'</th>';
				
				$x += 10; // Adjust based on the width of your columns
				$totrow --;
			}
		}
	}
	if($totrow >0){
		for($i = 1; $i <= $totrow ;$i++){
			$html.= '<th width="'.$width.'" ></th>';
		}
	}
	
	$html.= '<th width="'.$width.'" ></th>';
	$html.= '<th width="'.$width.'" ></th>';
	$html.= '<th width="'.$width.'" ></th>';
	$html.= '<th width="'.$width.'" ></th>';
	$html.= '<th width="'.$width.'" ></th>';
	$html.= '<th width="'.$width.'" ></th>';
	$html.= '</tr>';
	
	foreach ($Accountdetail as $key => $code) {
		$totrow = 28;
		$html.= '<tr>
		<td width="10%" >'.$code['company'].'</td>';
		
		foreach ($Order_item as $itemid) {
			$notmatch = true;
			foreach($Crate_total as $key => $crate){
				if($crate['ItemID'] == $itemid && $crate['AccountID'] == $code['AccountID']){
					$html.= '<th width="'.$width.'">'.number_format($crate['Crates'],0).'</th>';
					$totrow --;
					$notmatch = false;
				}
			}
			if($notmatch == true){
				$html.= '<th width="'.$width.'" ></th>';
				$totrow --;
			}
		}
		if($totrow >0){
			for($i = 1; $i <= $totrow ;$i++){
				$html.= '<th width="'.$width.'" ></th>';
			}
		}
		$html.= '<th width="'.$width.'" ></th>';
		$html.= '<th width="'.$width.'" ></th>';
		$html.= '<th width="'.$width.'" ></th>';
		$chk = 0;
		foreach($Crate_detail as $key => $crate){
			if($code['AccountID'] == $crate['AccountID']){
				if($chk <= 0){
					$html.= '<th width="'.$width.'" >'.number_format($crate['Crates'],0).'</th>';
					$chk++;
				}
			}
		}
		$html.= '<th width="'.$width.'" ></th>';
		$html.= '<th width="'.$width.'" ></th>';
		$html.='</tr>';
		
		$totrow2 = 34;
		$html.= '<tr>
		<td width="10%" >Fresh Return</td>';
		
		if($totrow2 >0){
			for($i = 1; $i <= $totrow2 ;$i++){
				$html.= '<th width="'.$width.'" ></th>';
			}
		}
		$html.='</tr>';
		$totrow3 = 34;
		$html.= '<tr>
		<td width="10%" >Damage Return</td>';
		
		if($totrow3 >0){
			for($i = 1; $i <= $totrow3 ;$i++){
				$html.= '<th width="'.$width.'" ></th>';
			}
		}
		$html.='</tr>';
		
	}
	
	
	$html .= '</table>';
	
	// $html .= '<pagebreak> ';
	
	
	$pdf->writeHTML($html, true, false, false, false, '');
	
	// Output the PDF
	$pdf->Output('example.pdf', 'I');
?>			