<?php

defined('BASEPATH') or exit('No direct script access allowed');

$dimensions = $pdf->getPageDimensions();
$state_detail = get_state_detail($invoice->client->state);
$billing_state_detail = get_state_detail($invoice->billing_state);
$shipping_state_detail = get_state_detail($invoice->shipping_state);
$city_name = get_city_name_id($invoice->client->city);
$user_detail = get_user_detail($invoice->addedfrom);
$user_comp = unserialize($user_detail->staff_comp);
$company_detail = get_company_name_by_id($user_comp[0]);
$html1 = '<div class="col-md-12">
       <h4 style="text-align:center;">'.$company_detail->company_name.'</h4>
       <p style="text-align:center;margin-bottom:0px;padding-bottom:0px;font-size:12px;line-height:16px;">'.$company_detail->address.'<br><b>GSTIN '.$company_detail->gst." ".$company_detail->state.'</b><br>Contact No. : '.$company_detail->mobile1." , ".$company_detail->mobile2.'</p>
       
        <table style="width: 100%; font-size:12px;font-weight:700;" cellspacing="1" cellpadding="4" border="1">
        <tr>
        <td width="75%" rowspan="3" style="text-align:center;"><h4 style="font-size:30px;">TAX INVOICE</h4></td>
        <td width="5%" ></td>
        <td width="20%">Original for Receipient</td>
        </tr>
        <tr>
        
        <td width="5%"></td>
        <td width="20%">Duplicate for Transport</td>
        </tr>
        <tr>
        
        <td width="5%"></td>
        <td width="20%">Triplicate for Supplier</td>
        </tr>
        </table>
        <table style="width: 100%; border: 2px solid #333;font-size:13px; font-weight:700;" id="invoice_data1" cellspacing="1" cellpadding="5" border="0">
           
           <tr>
              <td width="10%">Invoice No. </td>
              <td width="15.5%"> : '. $invoice_number .'</td>
              <td width="10%">Challan Id</td>
              <td width="12%" style="border-right: 2px solid #333;"> : CHL20900</td>
              <td width="15%">Vehicle No. </td>
              <td width:"30%" colspan="3"> : '.$company_detail->company_name.'</td>
           </tr>
           
           <tr>
              <td width="10%">Invoice Date </td>
              <td width="15.5%"> : '. _d($invoice->date) .'</td>
              <td width="10%">Order Id</td>
              <td width="12%" style="border-right: 2px solid #333;"> : ORD-'.$invoice->order_id.'</td>
              <td width="15%">Date of Supply </td>
              <td width:"30%" colspan="3"> : '. _d($invoice->date) .'</td>
           </tr>
           
           <tr>
              <td width="10%">State </td>
              <td width="15.5%"> : '.$state_detail->state_name.'</td>
              <td width="10%">State Code</td>
              <td width="12%"style="border-right: 2px solid #333;"> : '.$state_detail->short_name.'</td>
              <td width="15%">Place of Supply</td>
              <td width:"30%" colspan="3"> : '.$invoice->client->address.' '.$city_name->city_name.'</td>
           </tr>
           
           <tr>
               <td width="47.5%" colspan="4" style="text-align:center;border-right: 2px solid #333;border-top: 2px solid #333;border-bottom: 2px solid #333;" >Detail of Receiver / Billed to</td>
               <td width="52.5%" colspan="4" style="text-align:center;border-top: 2px solid #333;border-bottom: 2px solid #333;">Details of Consignee/Shipped to</td>
           </tr>
           
           <tr>
           <td width="10%">Name </td>
           <td width="37.75%" colspan="2" style="border-right: 2px solid #333;">: '.$invoice->client->company.'</td>
           <td width="10%">Name </td>
           <td width="40%" colspan="4">: '.$invoice->client->company.'</td>
           </tr>
           
           <tr>
           <td width="10%">Mob </td>
           <td width="37.75%" colspan="2" style="border-right: 2px solid #333;">: '.$invoice->client->phonenumber.'</td>
           <td width="10%">Mob </td>
           <td width="40%" colspan="4">: '.$invoice->client->phonenumber.'</td>
           </tr>
           
           <tr>
           <td width="10%">Address </td>
           <td width="37.75%" colspan="2" style="border-right: 2px solid #333;">: '.$invoice->billing_street." ".$invoice->billing_city." ".$invoice->billing_zip.' </td>
           <td width="10%">Address </td>
           <td width="40%" colspan="4">: '.$invoice->shipping_street." ".$invoice->shipping_city." ".$invoice->shipping_zip.'</td>
           </tr>
           
           <tr>
           <td width="10%">GSTIN </td>
           <td width="37.75%" colspan="2" style="border-right: 2px solid #333;">: '.$invoice->client->vat.'</td>
           
           <td width="10%">GSTIN </td>
           <td width="40%" colspan="4">: '.$invoice->client->vat.'</td>
           </tr>
           
           <tr>
           <td width="10%">State </td>
           <td width="18.75%">: '.$billing_state_detail->state_name.'</td>
           <td width="19%" style="border-right: 2px solid #333;">State Code  : '.$billing_state_detail->short_name.'</td>
           <td width="10%">State </td>
           <td width="20%">: '.$shipping_state_detail->state_name.'</td>
           <td style="border-right: 2px solid #333;" colspan="3">State Code  : '.$shipping_state_detail->short_name.'</td>
           </tr>
           
        </table>
       
   </div>';
$pdf->writeHTML($html1, true, false, false, false, '');

$pdf->Ln(0);

// The items table
//$items = get_items_table_data($invoice, 'invoice', 'pdf');

$inv_item = get_item_by_invoice_id($invoice->id);
$rowspan = 'rowspan="2"';
$item_name_width = "26%";
$hsn_width = "12%";
if($invoice->client->state == "9"){
    $rowspan = 'rowspan="2"';
    $item_name_width = "19%";
    $hsn_width = "8%";
    
}
$html2 = '<div class="col-md-12">

<table style="width: 100%; font-size:12px;font-weight:700;" cellspacing="1" cellpadding="4" border="1">
        <tr>
        <td width="3%" '.$rowspan.' style="text-align:center;">Sr.No.</td>
        <td width="'.$item_name_width.'" '.$rowspan.'>Product Descripotion</td>
        <td width="'.$hsn_width.'" '.$rowspan.'>HSN Code</td>
        <td width="5%" '.$rowspan.' style="text-align:center;">Pkg</td>
        <td width="5%" '.$rowspan.' style="text-align:center;">Qty.</td>
        <td width="5%" '.$rowspan.' style="text-align:center;">Rate</td>
        <td width="7%" '.$rowspan.' style="text-align:center;">Amt</td>
        <td width="5%" '.$rowspan.' style="text-align:center;">Disc. Amt</td>
        <td width="7%" '.$rowspan.' style="text-align:center;">Taxable Amt</td>';
    if($invoice->client->state == "9"){
        $html2 .= '<td colspan="2" style="text-align:center;">CGST</td>
        <td colspan="2" style="text-align:center;">SGST</td>';
    } else{
        $html2 .= '<td colspan="2" style="text-align:center;">IGST</td>';
    }
    
    $html2 .= '<td '.$rowspan.' style="text-align:center;">Total Amt</td>';    
    $html2 .= '</tr>';  
    if($invoice->client->state == "9"){
    $html2 .= '<tr>
        
        <td style="text-align:center;">Rate</td>
        <td style="text-align:center;">Amt</td>
        <td style="text-align:center;">Rate</td>
        <td style="text-align:center;">Amt</td>
        </tr>';    
    }else {
        $html2 .= '<tr>
        
        <td style="text-align:center;">Rate</td>
        <td style="text-align:center;">Amt</td>
        </tr>'; 
    }
    
    
        $i = 1;
        $qty = 0;
        $amt = 0;
        $dis_amt = 0;
        $taxable_amt = 0;
        $csgst_total = 0;
        $gst_total = 0;
        $order_total = 0;
        foreach ($inv_item as $item) {
           $html2 .= '<tr>'; 
           $html2 .= '<td style="text-align:center;">'.$i.'</td>'; 
           $html2 .= '<td class="description" align="left;" width="'.$item_name_width.'">'.$item['description'].'</td>';
           $html2 .= '<td width="'.$hsn_width.'" style="text-align:center;">'.$item['hsn_code'].'</td>';
           $html2 .= '<td style="text-align:right;">'. (int) $item['pack_qty'].'</td>';
           $html2 .= '<td style="text-align:right;">'. (int) $item['qty'].'</td>';
           $qty = $qty + $item['qty'];
           $html2 .= '<td style="text-align:right;">'.$item['rate'].'</td>';
           $html2 .= '<td style="text-align:right;">'.$item['total_amt'].'</td>';
           $amt = $amt + $item['total_amt'];
           $html2 .= '<td style="text-align:right;">'.$item['discount_amt'].'</td>';
           $dis_amt = $dis_amt + $item['discount_amt'];
           $html2 .= '<td style="text-align:right;">'.$item['taxable_amt'].'</td>';
           $taxable_amt = $taxable_amt + $item['taxable_amt'];
           if($invoice->client->state == "9"){
               $cgst_rate = $item['gst'] /2;
               $cgst_amt = $item['gst_amt'] /2;
            $html2 .= '<td style="text-align:right;">'.$cgst_rate.'</td>';
            $html2 .= '<td style="text-align:right;">'.$cgst_amt.'</td>';
            $csgst = $csgst + $cgst_amt;
            $html2 .= '<td style="text-align:right;">'.$cgst_rate.'</td>';
            $html2 .= '<td style="text-align:right;">'.$cgst_amt.'</td>';   
           }else {
               $html2 .= '<td style="text-align:right;">'.$item['gst'].'</td>
               <td style="text-align:right;">'.$item['gst_amt'].'</td>';
               $gst_total = $gst_total + $item['gst_amt'];
           }
           
           
           $html2 .= '<td style="text-align:right;">'.$item['grand_total'].'</td>';
           $order_total = $order_total + $item['grand_total'];
           $html2 .= '</tr>';
           $i++;
        }
        $amt = (double) $amt;
    $html2 .='<tr>'; 
    $html2 .='<td></td>';
    $html2 .='<td colspan="3" style="text-align:center;">Total</td>'; 
    $html2 .='<td style="text-align:right;">'.$qty.'</td>';
    $html2 .='<td></td>';
    $html2 .='<td style="text-align:right;">'.round($amt,2).'</td>';
    $html2 .='<td style="text-align:right;">'.round($dis_amt,2).'</td>';
    $html2 .='<td style="text-align:right;">'.round($taxable_amt,2).'</td>';
    if($invoice->client->state == "9"){
        $html2 .='<td></td>';
        $html2 .='<td style="text-align:right;">'.round($csgst,2).'</td>';
        $html2 .='<td style="text-align:right;"></td>';
        $html2 .='<td style="text-align:right;">'.round($csgst,2).'</td>';
    }else {
        $html2 .='<td></td>';
        $html2 .='<td style="text-align:right;">'.round($gst_total,2).'</td>';
    }
    $html2 .='<td style="text-align:right;">'.round($order_total,2).'</td>';
    $html2 .='</tr>'; 
    $html2 .='<tr>'; 
    if($invoice->client->state == "9"){
        $empty_col = 'colspan="14"';
    }else {
        $empty_col = 'colspan="12"';
    }
    $html2 .='<td '.$empty_col.'></td>';
    //$html2 .='<td></td>';
    $html2 .='</tr>';
    
    $html2 .='<tr>'; 
    //$html2 .='<td></td>';
    $html2 .='<td colspan="2" style="border-right:none;">Pending Crates : 0.00</td>';
    $html2 .='<td colspan="3" style="border-right:none; border-left:none;">Crates on bill : 0</td>';
    $html2 .='<td colspan="4" style="border-right:none;">Cases on bill  :    '.$invoice->total_cases.'</td>';
    if($invoice->client->state == "9"){
        $colspan_taxable = 'colspan="3"';
        $colspan_taxable_amt = 'colspan="2"';
    }else {
        $colspan_taxable = 'colspan="2"';
        $colspan_taxable_amt = '';
    }
    $html2 .='<td '.$colspan_taxable.'>Taxable Value/ Amt</td>';
    $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;">'.round($taxable_amt,2).'</td>';
    $html2 .='</tr>'; 
    $html2 .='<tr>'; 
    if($invoice->client->state == "9"){
        $bank_rowspan='rowspan="6"';
    }else {
        $bank_rowspan='rowspan="5"';
    }
    $html2 .='<td colspan="9" '.$bank_rowspan.'>SBIN0017640 A/c No. -35077329639,<br>
 PUNB0187500 A/c No. 1875008700013389,<br>
HDFC Bank Code-HDFC0000284 A/c 50200023148526</td>';
    if($invoice->client->state == "9"){
        $html2 .='<td '.$colspan_taxable.'>Add CGST</td>';
        $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;">'.round($csgst,2).'</td>';
    }else {
        $html2 .='<td '.$colspan_taxable.'>Add IGST</td>';
        $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;">'.round($gst_total,2).'</td>';
    }
    
    $html2 .='</tr>'; 
    if($invoice->client->state == "9"){
    $html2 .='<tr>'; 
    $html2 .='<td '.$colspan_taxable.'>Add SGST</td>';
    $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;">'.round($csgst,2).'</td>';
    $html2 .='</tr>'; 
    }
    $html2 .='<tr>'; 
    $html2 .='<td '.$colspan_taxable.'>Add TCS @ %</td>';
    $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;">0</td>';
    $html2 .='</tr>'; 
    $html2 .='<tr>'; 
    $html2 .='<td '.$colspan_taxable.'>Amount after GST + TCS</td>';
    $html2 .='<td '.$colspan_taxable_amt.' style="text-align:right;">'.round($order_total,2).'</td>';
    $html2 .='</tr>'; 
    $html2 .='<tr>'; 
    $html2 .='<td '.$colspan_taxable.'>Previous Balance</td>';
    $html2 .='<td '.$colspan_taxable_amt.'></td>';
    $html2 .='</tr>';
    $html2 .='<tr>'; 
    $html2 .='<td '.$colspan_taxable.'>Balance Amt (Rnd)</td>';
    $html2 .='<td '.$colspan_taxable_amt.'></td>';
    $html2 .='</tr>';
    $html2 .='<tr>'; 
    if($invoice->client->state == "9"){
        $sign = 'colspan="5"';
        
    }else {
        $sign = 'colspan="3"';
        
    }
    $html2 .='<td colspan="9"></td>';
    $html2 .='<td '.$sign.'><br>'.$company_detail->company_name.'<br><br>Authorized Signature</td>';
    $html2 .='</tr>';
    /*$html2 .='<tr>'; 
    $html2 .='<td '.$sign.'>Authorized Signature</td>';
    $html2 .='</tr>';*/
    
    
    $html2 .='</table></div>';

//$tblhtml = $items->table();
//print_r($items);
$pdf->writeHTML($html2, true, false, false, false, '');
//$tblhtml = $items->table();

//$pdf->writeHTML($tblhtml, true, false, false, false, '');

$pdf->Ln(8);


$info_right_column = '';
$info_left_column  = '';

$info_right_column .= '<span style="font-weight:bold;font-size:27px;">' . _l('invoice_pdf_heading') . '</span><br />';
$info_right_column .= '<b style="color:#4e4e4e;"># ' . $invoice_number . '</b>';

if (get_option('show_status_on_pdf_ei') == 1) {
    $info_right_column .= '<br /><span style="color:rgb(' . invoice_status_color_pdf($status) . ');text-transform:uppercase;">' . format_invoice_status($status, '', false) . '</span>';
}

if ($status != Invoices_model::STATUS_PAID && $status != Invoices_model::STATUS_CANCELLED && get_option('show_pay_link_to_invoice_pdf') == 1
    && found_invoice_mode($payment_modes, $invoice->id, false)) {
    $info_right_column .= ' - <a style="color:#84c529;text-decoration:none;text-transform:uppercase;" href="' . site_url('invoice/' . $invoice->id . '/' . $invoice->hash) . '"><1b>' . _l('view_invoice_pdf_link_pay') . '</1b></a>';
}

// Add logo
$info_left_column .= pdf_logo_url();

// Write top left logo and right column info/text
//pdf_multi_row($info_left_column, $info_right_column, $pdf, ($dimensions['wk'] / 2) - $dimensions['lm']);

$pdf->ln(10);

$organization_info = '<div style="color:#424242;">';

$organization_info .= format_organization_info();

$organization_info .= '</div>';

// Bill to
$invoice_info = '<b>' . _l('invoice_bill_to') . '</b>';
$invoice_info .= '<div style="color:#424242;">';
    $invoice_info .= format_customer_info($invoice, 'invoice', 'billing');
$invoice_info .= '</div>';

// ship to to
if ($invoice->include_shipping == 1 && $invoice->show_shipping_on_invoice == 1) {
    $invoice_info .= '<br /><b>' . _l('ship_to') . '</b>';
    $invoice_info .= '<div style="color:#424242;">';
    $invoice_info .= format_customer_info($invoice, 'invoice', 'shipping');
    $invoice_info .= '</div>';
}

$invoice_info .= '<br />' . _l('invoice_data_date') . ' ' . _d($invoice->date) . '<br />';

if (!empty($invoice->duedate)) {
    $invoice_info .= _l('invoice_data_duedate') . ' ' . _d($invoice->duedate) . '<br />';
}

if ($invoice->sale_agent != 0 && get_option('show_sale_agent_on_invoices') == 1) {
    $invoice_info .= _l('sale_agent_string') . ': ' . get_staff_full_name($invoice->sale_agent) . '<br />';
}

if ($invoice->project_id != 0 && get_option('show_project_on_invoice') == 1) {
    $invoice_info .= _l('project') . ': ' . get_project_name_by_id($invoice->project_id) . '<br />';
}

foreach ($pdf_custom_fields as $field) {
    $value = get_custom_field_value($invoice->id, $field['id'], 'invoice');
    if ($value == '') {
        continue;
    }
    $invoice_info .= $field['name'] . ': ' . $value . '<br />';
}

$left_info  = $swap == '1' ? $invoice_info : $organization_info;
$right_info = $swap == '1' ? $organization_info : $invoice_info;

//pdf_multi_row($left_info, $right_info, $pdf, ($dimensions['wk'] / 2) - $dimensions['lm']);

// The Table
$pdf->Ln(hooks()->apply_filters('pdf_info_and_table_separator', 6));

// The items table
$items = get_items_table_data($invoice, 'invoice', 'pdf');

$tblhtml = $items->table();

//$pdf->writeHTML($tblhtml, true, false, false, false, '');

$pdf->Ln(8);

$tbltotal = '';
$tbltotal .= '<table cellpadding="6" style="font-size:' . ($font_size + 4) . 'px">';
$tbltotal .= '
<tr>
    <td align="right" width="85%"><strong>' . _l('invoice_subtotal') . '</strong></td>
    <td align="right" width="15%">' . app_format_money($invoice->subtotal, $invoice->currency_name) . '</td>
</tr>';

if (is_sale_discount_applied($invoice)) {
    $tbltotal .= '
    <tr>
        <td align="right" width="85%"><strong>' . _l('invoice_discount');
    if (is_sale_discount($invoice, 'percent')) {
        $tbltotal .= '(' . app_format_number($invoice->discount_percent, true) . '%)';
    }
    $tbltotal .= '</strong>';
    $tbltotal .= '</td>';
    $tbltotal .= '<td align="right" width="15%">-' . app_format_money($invoice->discount_total, $invoice->currency_name) . '</td>
    </tr>';
}

foreach ($items->taxes() as $tax) {
    $tbltotal .= '<tr>
    <td align="right" width="85%"><strong>' . $tax['taxname'] . ' (' . app_format_number($tax['taxrate']) . '%)' . '</strong></td>
    <td align="right" width="15%">' . app_format_money($tax['total_tax'], $invoice->currency_name) . '</td>
</tr>';
}

if ((int) $invoice->adjustment != 0) {
    $tbltotal .= '<tr>
    <td align="right" width="85%"><strong>' . _l('invoice_adjustment') . '</strong></td>
    <td align="right" width="15%">' . app_format_money($invoice->adjustment, $invoice->currency_name) . '</td>
</tr>';
}

$tbltotal .= '
<tr style="background-color:#f0f0f0;">
    <td align="right" width="85%"><strong>' . _l('invoice_total') . '</strong></td>
    <td align="right" width="15%">' . app_format_money($invoice->total, $invoice->currency_name) . '</td>
</tr>';

if (count($invoice->payments) > 0 && get_option('show_total_paid_on_invoice') == 1) {
    $tbltotal .= '
    <tr>
        <td align="right" width="85%"><strong>' . _l('invoice_total_paid') . '</strong></td>
        <td align="right" width="15%">-' . app_format_money(sum_from_table(db_prefix().'invoicepaymentrecords', [
        'field' => 'amount',
        'where' => [
            'invoiceid' => $invoice->id,
        ],
    ]), $invoice->currency_name) . '</td>
    </tr>';
}

if (get_option('show_credits_applied_on_invoice') == 1 && $credits_applied = total_credits_applied_to_invoice($invoice->id)) {
    $tbltotal .= '
    <tr>
        <td align="right" width="85%"><strong>' . _l('applied_credits') . '</strong></td>
        <td align="right" width="15%">-' . app_format_money($credits_applied, $invoice->currency_name) . '</td>
    </tr>';
}

if (get_option('show_amount_due_on_invoice') == 1 && $invoice->status != Invoices_model::STATUS_CANCELLED) {
    $tbltotal .= '<tr style="background-color:#f0f0f0;">
       <td align="right" width="85%"><strong>' . _l('invoice_amount_due') . '</strong></td>
       <td align="right" width="15%">' . app_format_money($invoice->total_left_to_pay, $invoice->currency_name) . '</td>
   </tr>';
}

$tbltotal .= '</table>';
//$pdf->writeHTML($tbltotal, true, false, false, false, '');

if (get_option('total_to_words_enabled') == 1) {
    // Set the font bold
    $pdf->SetFont($font_name, 'B', $font_size);
    $pdf->writeHTMLCell('', '', '', '', _l('num_word') . ': ' . $CI->numberword->convert($invoice->total, $invoice->currency_name), 0, 1, false, true, 'C', true);
    // Set the font again to normal like the rest of the pdf
    $pdf->SetFont($font_name, '', $font_size);
    $pdf->Ln(4);
}

if (count($invoice->payments) > 0 && get_option('show_transactions_on_invoice_pdf') == 1) {
    $pdf->Ln(4);
    $border = 'border-bottom-color:#000000;border-bottom-width:1px;border-bottom-style:solid; 1px solid black;';
    $pdf->SetFont($font_name, 'B', $font_size);
    $pdf->Cell(0, 0, _l('invoice_received_payments'), 0, 1, 'L', 0, '', 0);
    $pdf->SetFont($font_name, '', $font_size);
    $pdf->Ln(4);
    $tblhtml = '<table width="100%" bgcolor="#fff" cellspacing="0" cellpadding="5" border="0">
        <tr height="20"  style="color:#000;border:1px solid #000;">
        <th width="25%;" style="' . $border . '">' . _l('invoice_payments_table_number_heading') . '</th>
        <th width="25%;" style="' . $border . '">' . _l('invoice_payments_table_mode_heading') . '</th>
        <th width="25%;" style="' . $border . '">' . _l('invoice_payments_table_date_heading') . '</th>
        <th width="25%;" style="' . $border . '">' . _l('invoice_payments_table_amount_heading') . '</th>
    </tr>';
    $tblhtml .= '<tbody>';
    foreach ($invoice->payments as $payment) {
        $payment_name = $payment['name'];
        if (!empty($payment['paymentmethod'])) {
            $payment_name .= ' - ' . $payment['paymentmethod'];
        }
        $tblhtml .= '
            <tr>
            <td>' . $payment['paymentid'] . '</td>
            <td>' . $payment_name . '</td>
            <td>' . _d($payment['date']) . '</td>
            <td>' . app_format_money($payment['amount'], $invoice->currency_name) . '</td>
            </tr>
        ';
    }
    $tblhtml .= '</tbody>';
    $tblhtml .= '</table>';
    //$pdf->writeHTML($tblhtml, true, false, false, false, '');
}

if (found_invoice_mode($payment_modes, $invoice->id, true, true)) {
    $pdf->Ln(4);
    $pdf->SetFont($font_name, 'B', $font_size);
    $pdf->Cell(0, 0, _l('invoice_html_offline_payment'), 0, 1, 'L', 0, '', 0);
    $pdf->SetFont($font_name, '', $font_size);

    foreach ($payment_modes as $mode) {
        if (is_numeric($mode['id'])) {
            if (!is_payment_mode_allowed_for_invoice($mode['id'], $invoice->id)) {
                continue;
            }
        }
        if (isset($mode['show_on_pdf']) && $mode['show_on_pdf'] == 1) {
            $pdf->Ln(1);
            $pdf->Cell(0, 0, $mode['name'], 0, 1, 'L', 0, '', 0);
            $pdf->Ln(2);
            //$pdf->writeHTMLCell('', '', '', '', $mode['description'], 0, 1, false, true, 'L', true);
        }
    }
}

if (!empty($invoice->clientnote)) {
    $pdf->Ln(4);
    $pdf->SetFont($font_name, 'B', $font_size);
    $pdf->Cell(0, 0, _l('invoice_note'), 0, 1, 'L', 0, '', 0);
    $pdf->SetFont($font_name, '', $font_size);
    $pdf->Ln(2);
    //$pdf->writeHTMLCell('', '', '', '', $invoice->clientnote, 0, 1, false, true, 'L', true);
}

if (!empty($invoice->terms)) {
    $pdf->Ln(4);
    $pdf->SetFont($font_name, 'B', $font_size);
    $pdf->Cell(0, 0, _l('terms_and_conditions'), 0, 1, 'L', 0, '', 0);
    $pdf->SetFont($font_name, '', $font_size);
    $pdf->Ln(2);
    //$pdf->writeHTMLCell('', '', '', '', $invoice->terms, 0, 1, false, true, 'L', true);
}
