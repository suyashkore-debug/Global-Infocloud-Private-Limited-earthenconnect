<?php

defined('BASEPATH') or exit('No direct script access allowed');


$dimensions = $pdf->getPageDimensions();

$pdf->SetMargins(5, 15, 5, 0);
$pdf->Ln(0);
$get_order_list = get_order_list($invoice->ChallanID);
$count = 0;
$count_order = count($get_order_list);

foreach ($get_order_list as $key => $order_detail) {
    
     $client_detail = get_client_detail($order_detail["AccountID"]);
    $company_detail = get_company_name_by_id($order_detail["PlantID"]);
    $sales_detail = get_sales_details($invoice->ChallanID,$order_detail["OrderID"]);
    $state_detail = get_state_detail($client_detail->state);
    $billing_state_detail = get_state_detail($client_detail->billing_state);
    $shipping_state_detail = get_state_detail($client_detail->shipping_state);
    $user_detail = get_staff_detail($invoice->DriverID);
    $route_detail = get_route_detail($invoice->RouteID);
    
    /*$invoice_detail = get_invoice_detail($value["invoice_id"]);
        $order_detail = get_order_detail($invoice_detail->order_id);
        $challan_detail = get_challan_detail($invoice_detail->challan_id);
        $vehicle_detail = get_vehicle_detail($challan_detail->vehicle);
        $city_name = get_city_name_id($client_detail->city);*/
        
    $inv_item = get_item_by_order_id($order_detail["OrderID"]);
    $html = '
       <table style="width: 100%; font-size:12px;font-weight:700;" cellspacing="1" cellpadding="4" border="1">
       <tr>
       <td align="center;" colspan="10">
       <span style="text-align:center;font-size:14px;padding:0px;margin:0px;"><b><u>Route Dispatch</u></b></span> <br>
       <span style="font-size:14px;font-weight:700;"> <b>'.$company_detail->company_name.' (GSTIN '.$company_detail->gst.') </b></span><br>
       <span><b>'.$company_detail->address.'</b></span><br>
       <span><b>Contact No. : '.$company_detail->mobile1." , ".$company_detail->mobile2.' , '.$company_detail->mobile3.' Food Lic '.$company_detail->food_lic.'</b></span>
       
       </td>
       </tr>
       <tr>
        <td style="border-left: 0px solid #333;font-size:16px;" colspan="2"><b>ChallanID</b></td>
        <td style="border-right: 1px solid #333;font-size:16px;" colspan="3"> <b> '. $invoice->ChallanID .'</b></td>
        <td style="border-left: 0px solid #333;font-size:16px;" colspan="2"><b>Vehicle No. </b></td>
        <td style="border-right: 1px solid #333;font-size:16px;" colspan="3"> <b> '.$invoice->VehicleID.'</b></td>
       </tr>
       <tr>
        <td style="border-left: 0px solid #333;font-size:16px;" colspan="2"><b>Date</b></td>
        <td style="border-right: 1px solid #333;font-size:16px;" colspan="3"> <b> '. _d(substr($invoice->Transdate,0,10)).' '.substr($invoice->Transdate,11,8) .'</b></td>
        <td style="border-left: 0px solid #333;font-size:16px;" colspan="2"><b>Route Name. </b></td>
        <td style="border-right: 1px solid #333;font-size:16px;" colspan="3"> <b> '.$route_detail->name.'</b></td>
       </tr>
       <tr>
        <td style="border-left: 0px solid #333;font-size:16px;" colspan="2"><b>Driver Name</b></td>
        <td style="border-right: 1px solid #333;font-size:16px;" colspan="3"> <b> '. $user_detail->firstname .' '.$user_detail->lastname.'</b></td>
        <td style="border-left: 0px solid #333;border-bottom: 1px solid #333;" colspan="5"> </td>
        
       </tr>
       
       <tr>
       <td colspan="4" rowspan="2"></td>
       <td align="center"><b>'.$client_detail->company.'</b></td>
       <td></td>
       </tr>
       
       <tr>
       <td align="center"><b>'.$client_detail->StationName.'</b></td>
       <td align="center"><b>Total</b></td>
       </tr>
       
       <tr>
       <td colspan="4" style="font-size:13px;"><b>Bill Amt</b></td>
       <td align="center"> <b>'.$sales_detail->BillAmt.'</b></td>
       <td align="center"><b>'.$sales_detail->BillAmt.'</b></td>
       </tr>
       
       <tr>
       <td colspan="4" style="font-size:13px;"><b>Cash</b></td>
       <td></td>
       <td></td>
       </tr>
       
       <tr>
       <td colspan="4" style="font-size:13px;"><b>Credit</b></td>
       <td></td>
       <td></td>
       </tr>
       
       <tr>
       <td colspan="4" style="font-size:13px;"><b>Fresh Return</b></td>
       <td></td>
       <td></td>
       </tr>
       
       
       
       <tr>
       
       <td colspan="2" width="25%"><b>Item Name</b></td>
       <td width="5%" align="center"><b>In</b></td>
       <td align="center"><b>Pack</b></td>
       <td align="center"><b>Billed Qty.</b></td>
       <td align="center"><b>CS/CR</b></td>
       
       </tr>';
       $i = 1;
       $colspan = 3;
       $empty_height= 480;
       if($client_detail->state == "UP"){
    $colspan = 'colspan="2"';
   
}
$tax_amt = 0;
$igst_amt = 0;
$cgst_amt = 0;
$sgst_amt = 0;
       foreach ($inv_item as $item) {
           if($i>1){
                $empty_height = $empty_height - 35;
            }
            $tax_amt = $tax_amt + $item['ChallanAmt'];
            if($client_detail->state == "UP"){
                
                $cgst_amt = $cgst_amt + $item['cgstamt'];
                $sgst_amt = $sgst_amt + $item['sgstamt'];
            }else{
                $igst_amt = $igst_amt + $item['igstamt'];
            }
            if($item['OrderAmt'] == "0.00"){
            
        }else{
            
            $html .= '<tr>'; 
           //$html .= '<td style="text-align:center;">'.$i.'</td>'; 
           $html .= '<td class="description" align="left;" colspan="2"><b>'.$item['description'].'</b></td>';
           /*if($item['SuppliedIn']=="CS"){
               $unit = "Cases";
           }else {
               $unit = "Crate";
           }*/
           $html .= '<td class="description" align="center;"><b>'.$item['SuppliedIn'].'</b></td>';
           $html .= '<td class="description" align="center;"><b>'. (int) $item['CaseQty'].'</b></td>';
           
           if(is_null($item["eOrderQty"])){
                            $newqty = $item["OrderQty"] / $item["CaseQty"];
                            
                        }else{
                            
                            $newqty = $item["eOrderQty"] / $item["CaseQty"];
                            
                        }
                        
           $html .= '<td class="description" align="center;"><b>'. (int) $newqty.'</b></td>';
           $html .= '<td class="description" align="center;"><b>'. (int) $newqty.'</b></td>';
           $i++;
           $html .= '</tr>';
        }
            
           
       }
       $qty = $order_detail["Cases"] + $order_detail["Crates"];
       $html .= '<tr>
       <td colspan="2" align="left;"><b>Total Qty</b></td>
       <td></td>
       <td></td>
       <td align="center"><b>'.$qty.'</b></td>
       <td align="center"><b>'.$qty.'</b></td>
       </tr>';
       
       $html .= '<tr>
       <td colspan="2" align="left"><b>Total Cases</b></td>
       <td align="center"><b>CS</b></td>
       <td></td>
       <td align="center"><b>'.$order_detail["Cases"].'</b></td>
       <td align="center"><b>'.$order_detail["Cases"].'</b></td>
       </tr>';
       
       $html .= '<tr>
       <td colspan="2" align="left"><b>Total Crates</b></td>
       <td align="center"><b>CR</b></td>
       <td></td>
       <td align="center"><b>'.$order_detail["Crates"].'</b></td>
       <td align="center"><b>'.$order_detail["Crates"].'</b></td>
       </tr>';
       
       /*$html .= '<tr>';
       $html .= '<td rowspan="4" colspan="12" width="100%"></td>';
       $html .= '</tr>';*/
       
       $html .= '<tr>
       <td align="left" width="10%"><b>Sales ID</b></td>
       <td align="left" width="15%"><b>GSTIN</b></td>
       <td align="left" colspan="2" width="29%"><b>AccountName</b></td>
       <td align="center" width="8%"><b>hsncode</b></td>
       <td align="center" width="10%"><b>TaxableAmt</b></td>
       <td align="center" width="7%"><b>Qty</b></td>
       <td align="center" width="7%"><b>CGST%</b></td>
       <td align="center" width="7%"><b>SGST%</b></td>
       <td align="center" width="7%"><b>IGST%</b></td>
       </tr>';
    $hsn_list = get_hsn_list($order_detail["OrderID"]);
       
    $sum_taxable_amt = 0.00;   
       
       foreach ($hsn_list as $hsn) {
           if($client_detail->state == "UP"){
       $gst_detail_new = get_gst_details_new($order_detail["OrderID"],$hsn["hsn_code"]);
       
       }else{
           $gst_detail_new = get_igst_details_new($order_detail["OrderID"],$hsn["hsn_code"]);
       }
         foreach ($gst_detail_new as $gvalue) {
            
             if($client_detail->state == "UP"){
                $taxable_amt = get_gst_taxable_amt_new($order_detail["OrderID"],$gvalue["cgst"],$hsn["hsn_code"]);
                    $gst_per = $gvalue["cgst"];
                    $igst_per = "0.00";
                    $item_qty_sum_for_igst_new = get_gst_item_qty_sum_new($order_detail["OrderID"],$gvalue["cgst"],$hsn["hsn_code"]);
             }else{
                $taxable_amt = get_igst_taxable_amt_new($order_detail["OrderID"],$gvalue["igst"],$hsn["hsn_code"]);
                    $igst_per = $gvalue["igst"];
                    $gst_per = "0.00"; 
                    $item_qty_sum_for_igst_new = get_igst_item_qty_sum_new($order_detail["OrderID"],$gvalue["igst"],$hsn["hsn_code"]);
                    
             }
            
            $sum_taxable_amt = $sum_taxable_amt + $taxable_amt;
            if($taxable_amt == "0.00"){
                
            }else{
                $html .='<tr>';
                $html .='<td><b>'.$order_detail["SalesID"].'</b></td>';
                $html .='<td><b>'.$client_detail->vat.'</b></td>';
                $html .='<td colspan="2"><b>'.$client_detail->company.'</b></td>';
                $html .='<td><b>'.$hsn["hsn_code"].'</b></td>';
                $html .='<td align="right"><b>'.$taxable_amt.'</b></td>';
                $html .='<td align="right"><b>'.number_format($item_qty_sum_for_igst_new,2).'</b></td>';
                $html .='<td align="right"><b>'.$gst_per.'</b></td>';
                $html .='<td align="right"><b>'.$gst_per.'</b></td>';
                $html .='<td align="right"><b>'.$igst_per.'</b></td>';
                $html .='</tr>'; 
            }
            
         }
           
       }
            
        $html .= '<tr>
        <td><b>GSTType</b></td>
        <td align="right"><b>Amount</b></td>
        </tr>';
        $html .= '<tr>
        <td><b>TaxableAmt</b></td>
        <td align="right"><b>'.$sum_taxable_amt.'</b></td>
        </tr>';
        
        $html .= '<tr>
        <td align="center" width="5%"><b>Sr</b></td>
        <td width="39.5%"><b>AccountName</b></td>
        <td width="12%"><b>Order ID</b></td>
        <td width="16%"><b>Order Date</b></td>
        <td width="12%"><b>Sales ID</b></td>
        <td width="16%"><b>Sales Date</b></td>
        </tr>';
        
        $html .= '<tr>
        <td align="center"><b>1</b></td>
        <td><b>'.$client_detail->company.'</b></td>
        <td><b>'.$order_detail["OrderID"].'</b></td>
        <td><b>'.substr($order_detail["Transdate"],0,19).'</b></td>
        <td><b>'.$sales_detail->SalesID.'</b></td>
        <td><b>'.substr($sales_detail->Transdate,0,19).'</b></td>
        </tr>';
        
        
       
       $html .= '<tr><td colspan="10" width="100%" style="height:'.$empty_height.'px;"></td></tr>';
       $html .= '</table>
       </div>';
       $pdf->writeHTML($html, true, false, false, false, '');
    
    $count++;
//$pdf->Ln(0);
if($count == $count_order){
    
}else{
    $pdf->AddPage();
}


}
/*$html2 ="Madhav SHinde";
$pdf->writeHTML($html2, true, false, false, false, '');
$pdf->Ln(0);*/
?>