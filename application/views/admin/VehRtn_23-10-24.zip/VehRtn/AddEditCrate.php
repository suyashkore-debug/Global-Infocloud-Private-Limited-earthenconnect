<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="panel_s">
            <div class="row">
                <div class="col-md-8">
                    <div class="panel-body">
                        <div class="row">
                            <?php
                                $fy = $this->session->userdata('finacial_year');
                                $prefix = "VRT".$fy;
                                $next_Vehicle_rtn_number = get_option('next_vrt_number');
                                $vehicle_rtn_number = str_pad($next_Vehicle_rtn_number, get_option('number_padding_prefixes'), '0', STR_PAD_LEFT);
                                $date = date('Y-m-d');
                                $vchlDate = _d($date);
                                $date_attrs = array();
                                $date_attrs['disabled'] = true;
							?>
							<input type="hidden" name="row_count" value="0" id="row_count">
                            <div class="col-md-3">
								<div class="form-group">
                                    <label for="number">ReturnID</label>
                                    <div class="input-group"><span class="input-group-addon"><?php echo $prefix;?></span>
                                        <input type="text" readonly id="vehicle_return_id" name="vehicle_return_id" class="form-control" value="<?php echo $next_Vehicle_rtn_number; ?>" >
                                        <input type="hidden" id="NextVRtnID" name="NextVRtnID" class="form-control" value="<?php echo $next_Vehicle_rtn_number; ?>" >
                                        <input type="hidden" id="vehicle_return_id_hidden" name="vehicle_return_id_hidden" class="form-control"  >
									</div>
								</div>
							</div>
                            <div class="col-md-3">
                                <label class="control-label">Vhl Return Date</label>
            				    <?php echo render_date_input('from_date','',$vchlDate); ?>
							</div>
                            
                            <div class="col-md-3">
								<div class="form-group">
                                    <label for="challan_n">ChallanID</label>
                                    <input type="text" id="challan_n" name="challan_n" class="form-control" value="" readonly>
								</div>
							</div>
                            <div class="col-md-3">
                                <label class="control-label">Challan Date</label>
            				    <?php echo render_date_input('to_date','','',$date_attrs); ?>
							</div>
                            <div class="clearfix"></div>
                            <div class="col-md-3">
								<div class="form-group">
                                    <label for="vehicle_number">Vehicle No.</label>
                                    <input type="text" id="vehicle_number" name="vehicle_number" class="form-control" value="" readonly>
								</div>
							</div>
                            <div class="col-md-3">
								<div class="form-group">
                                    <label for="vehicle_capc">Vehicle Capacity</label>
                                    <input type="text" id="vehicle_capc" name="vehicle_capc" class="form-control" value="" readonly>
								</div>
							</div>
                            
                            <div class="col-md-3">
								<div class="form-group">
                                    <label for="challan_crates">Challan Crates</label>
                                    <input type="text" id="challan_crates" name="challan_crates" class="form-control" value="" readonly>
								</div>
							</div>
                            <div class="col-md-3">
								<div class="form-group">
                                    <label for="refund_crates">Returned Crates</label>
                                    <input type="text" id="refund_crates" name="refund_crates" class="form-control" value="" readonly>
								</div>
							</div>
                            <div class="clearfix"></div>
                            
                            <div class="col-md-3">
								<div class="form-group">
                                    <label for="driver_name">Challan Driver</label>
                                    <input type="text" id="driver_name" name="driver_name" class="form-control" value="" readonly>
									<input type="hidden" readonly="" class="form-control" name="driver_id" id="driver_id"  aria-invalid="false">
								</div>
							</div>
                            
                            <div class="col-md-3">
								<div class="form-group">
                                    <label for="loder_name">Challan Loader</label>
                                    <input type="text" id="loder_name" name="loder_name" class="form-control" value="" readonly>
									<input type="hidden" readonly="" class="form-control" name="loder_id" id="loder_id"  aria-invalid="false">
								</div>
							</div>
                            
                            <div class="col-md-3">
								<div class="form-group">
                                    <label for="salesman_name">Challan Sales Man</label>
                                    <input type="text" id="salesman_name" name="salesman_name" class="form-control" value="" readonly>
									<input type="hidden" readonly="" class="form-control" name="salesman_id" id="salesman_id"  aria-invalid="false">
									<input type="hidden"  class="form-control" name="UserIDName" id="UserIDName"  aria-invalid="false">
								</div>
							</div>
							<div class="col-md-3">
								
								<?php $value =  date('d/m/Y H:m');
								echo render_datetime_input('Act_datetime','Actual Entry DateTime',$value); ?>
							</div>
                            <div class="clearfix"></div>
                            <div class="col-md-12" style="margin-top:2%;">
                                <a href="#" class="btn btn-info VrtList" id="VrtList" style="margin-right: 25px;">Show Return List</a>
                                <a href="#" class="btn btn-warning chlList" id="chlList" style="margin-right: 25px;">Show Challan List</a>
							</div>
                            
                            
						</div>
						
						
						<div class="row col-md-12">
							<!-- crates Details -->
							<div class="" id="crate_details" >
								<div class="row">
									<div class="col-md-12">
										<table class="table table-striped table-bordered crate_details_tbl" id="crate_details_tbl" width="100%">
											<thead>
												<tr>
													<th>AccountID</th>
													<th>AccoutName</th>
													<th>Address</th>
													<th>OpeningCrates</th>
													<th>ChallanCrates</th>
													<th>RtnCrates</th>
													<th>BalanceCrates</th>
												</tr>
											</thead>
											<tbody id="tbody">
												<tr class="accounts" id="row">
													<td id="AccountIDTD" style="width: 125px;"><input type="text" name="AccountID" style="width: 125px;" id="AccountID"></td>
													<td style="padding:1px 5px !important;"><span id="party_name"></span><input type="hidden" name="party_name_val" id="party_name_val"></td>
													<td style="padding:1px 5px !important;"><span id="address"></span><input type="hidden" name="address_val" id="address_val" value="" ></td>
													<td style="padding:1px 5px !important;text-align: right;"><span id="opnCrates"></span><input type="hidden" name="opnCrates_val" id="opnCrates_val"></td>
													<td style="padding:1px 5px !important;text-align: right;"><span id="chlCrates"></span><input type="hidden" name="chlCrates_val" id="chlCrates_val"></td>
													<td class="rtnqty" style="width: 80px;">
														<input type="text" name="rtncrates" id="rtncrates" class="rtncrates" onblur="calculate_balcrates();" style="width: 80px;text-align: right;" >
														<input type="hidden" name="balcrates" id="balcrates" value="0">
														<input type="hidden" name="colno" id="colno" value="">
													</td>
													<td tyle="padding:1px 5px !important;text-align: right;"><span id="balCrates_new" style="text-align: right;"></span><input type="hidden" name="balCrates_new_val" id="balCrates_new_val" class="form-control"></td>
												</tr>
												
											</tbody>
										</table>
									</div>
								</div>
							</div> 
						</div>
						
						
						<div class="row">
							<div class="col-md-12 mtop15">
								<div class="btn-bottom-toolbar text-right" style="width: 100%;">
									<?php if (has_permission_new('Vehicle_Crate', '', 'create')) {
									?>
									<button type="button" class="btn btn-info saveBtn" style="margin-right: 25px;">Save</button>
									<?php
										}else{
									?>
									<button type="button" class="btn btn-info saveBtn2 disabled" style="margin-right: 25px;">Save</button>
									<?php
									}?>
									
									<?php if (has_permission_new('Vehicle_Crate', '', 'edit')) {
									?>
									<button type="button" class="btn btn-info updateBtn" style="margin-right: 25px;">Update</button>
									<?php
										}else{
									?>
									<button type="button" class="btn btn-info updateBtn2 disabled" style="margin-right: 25px;">Update</button>
									<?php
									}?>
									<button type="button" class="btn btn-default cancel" id="cancel">Cancel</button>
								</div>
							</div>
							<div class="btn-bottom-pusher"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="transfer-modal_return_list">
	<div class="modal-dialog modal-xl" style=" max-width: 1230px;">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Vehicle Return List</h4>
			</div>
			<div class="modal-body" style="padding:5px;">
				
				<div class="row">
					<?php
						$fy = $this->session->userdata('finacial_year');
						$fy_new  = $fy + 1;
						$lastdate_date = '20'.$fy_new.'-03-31';
						$firstdate_date = '20'.$fy_new.'-04-01';
						$curr_date = date('Y-m-d');
						$curr_date_new    = new DateTime($curr_date);
						$last_date_yr = new DateTime($lastdate_date);
						if($last_date_yr < $curr_date_new){
							$to_date = '31/03/20'.$fy_new;
							$from_date = '01/03/20'.$fy_new;
							}else{
							$from_date = "01/".date('m')."/".date('Y');
							$to_date = date('d/m/Y');
						}
					?>    
					<div class="col-md-2">
						<?php
							echo render_date_input('from_date2','From',$from_date);
						?>
					</div>
					<div class="col-md-2">
						<?php
							echo render_date_input('to_date2','To',$to_date);
						?>
					</div>
					<div class="col-md-3">
						<br>
						<button class="btn btn-info pull-left mleft5 search_data" id="search_data_vehicle_return"><?php echo _l('rate_filter'); ?></button>
					</div>
					<div class="col-md-3">
						<!--<br>
						<input type="text" id="myInput2" onkeyup="myFunction3()" placeholder="Search for names.." title="Type in a name" style="float: right;">-->
					</div>
					<div class="col-md-12">
						<span id="searchh11" style="display:none;">Please wait fetching data...</span>
						<div class="table_vehicle_return">
							
							<table class="tree table table-striped table-bordered table_vehicle_return" id="table_vehicle_return" width="100%">
								
								<thead>
									<tr style="display:none;">
										<td colspan="8" ><h5 style="text-align:center;"><span style="font-size:15px;font-weight:700;"><?php echo $company_detail->company_name; ?></span><br><span style="font-size:10px;font-weight:600;"><?php echo $company_detail->address; ?></span><br><span class="report_for" style="font-size:10px;"></span></h5></td>
									</tr>
									<tr >
										<th style="padding:0px 3px !important;">ReturnNo.</th>
										<th style="padding:0px 3px !important;">ReturnDate</th>
										<th style="padding:0px 3px !important;">ChallanID.</th>
										<th style="padding:0px 3px !important;">ChallanDate</th>
										<th style=" text-align:center;">DriverName</th>
										<th style=" text-align:center;">Route</th>
										<th style=" text-align:center;">Crates</th>
										<th style=" text-align:center;">Cases</th>
										<th style=" text-align:center;">ChallanAmt</th>
										<th style=" text-align:center;">Is Crate Rec.</th>
										<th style=" text-align:center;">Is Return Rec.</th>
										<th style=" text-align:center;">Is Payment Rec.</th>
										<th style=" text-align:center;">Is Expense Rec.</th>
									</tr>
								</thead>
								<tbody>
									
								</tbody>
							</table>   
						</div>
						<span id="searchh3" style="display:none;">Loading.....</span>
						
					</div>
				</div>
			</div>
			<div class="modal-footer" style="padding:0px;">
				<input type="text" id="myInput2"  autofocus="1" name='myInput2' onkeyup="myFunction3()" placeholder="Search for names.."  style="float: left;width: 100%;">
			</div>
			
		</div>
	</div>
</div>

<div class="modal fade" id="transfer-modal">
	<div class="modal-dialog modal-xl" style=" max-width: 1230px;">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title"> Challan List</h4>
			</div>
			<div class="modal-body" style="padding:5px;">
				
				<div class="row">
					<div class="col-md-2">
						<div class="form-group" app-field-wrapper="from_date">
							<label for="from_date" class="control-label">From</label>
							
							<div class="input-group date">
								<input type="text" id="from_date1" name="from_date1" class="form-control datepicker" value="<?php echo $from_date;?>" >
								<div class="input-group-addon"><i class="fa fa-calendar calendar-icon"></i>
								</div>
							</div>
						</div>
					</div>
					
					<div class="col-md-2">
						<div class="form-group" app-field-wrapper="to_date">
							<label for="to_date" class="control-label">To</label>
							
							<div class="input-group date">
								<input type="text" id="to_date1" name="to_date1" class="form-control datepicker" value="<?php echo $to_date;?>">
								<div class="input-group-addon"><i class="fa fa-calendar calendar-icon"></i>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-2">
						<div class="form-group">
							<label for="challan_route" class="control-label" ><small class="req text-danger"> </small> Route</label>
							<select class="selectpicker" name="challan_route" id="challan_route" data-width="100%"  data-action-box="true"   data-hide-disabled="true" data-live-search="true" data-none-selected-text="<?php echo _l('dropdown_non_selected_tex'); ?>">
								<option value=""></option>
								<?php
									foreach($routes as $key => $value) {
									?>
									<option value="<?php echo $value["RouteID"]?>" ><?php echo $value["name"]?></option>
									<?php
									}
								?>
								
							</select>
						</div> 
					</div>
					
					<div class="col-md-2">
						<br>
						<button class="btn btn-info pull-left mleft5 search_data" id="search_data">Search</button>
					</div>
					
					<div class="col-md-3">
						<!--<br>
						<input type="text" id="myInput1" onkeyup="myFunction2()" placeholder="Search for names.." title="Type in a name" style="float: right;">-->
					</div>
					
					<div class="col-md-12">
						
						<div class="table_adj_report">
							
							<table class="tree table table-striped table-bordered table_adj_report" id="table_adj_report" width="100%">
								
								<thead>
									
									<tr>
										<th style="padding:0px 3px !important;">Challan No.</th>
										<th style="padding:0px 3px !important;">Challan Date</th>
										<th style=" text-align:center;">Route</th>
										<th style=" text-align:center;">Vehicle No</th>
										<th style=" text-align:center;">Driver Name</th>
										<th style=" text-align:center;">Crates</th>
										<th style=" text-align:center;">Cases</th>
										<th style=" text-align:center;">Challan Amt</th>
										
									</tr>
								</thead>
								<tbody>
									
								</tbody>
							</table>   
						</div>
						<span id="searchh2" style="display:none;">
							Loading.....
						</span>
						
					</div>
				</div>
			</div>
			
			<div class="modal-footer" style="padding:0px;">
				<input type="text" id="myInput1"  autofocus="1" name='myInput1' onkeyup="myFunction2()" placeholder="Search for names.."  style="float: left;width: 100%;">
			</div>
			
			
		</div>
	</div>
</div>

<style>
	.table_adj_report { overflow: auto;max-height: 60vh;width:100%;position:relative;top: 0px; }
	.table_adj_report thead th { position: sticky; top: 0; z-index: 1; }
	.table_adj_report tbody th { position: sticky; left: 0; }
	
	.No-left {
    padding-left:0px;
	}
	.No-right {
    padding-right:0px;
	}
	#table_adj_report tr:hover {
    background-color: #ccc;
	}
	
	#table_adj_report td:hover {
    cursor: pointer;
	}
	
	.table_vehicle_return { overflow: auto;max-height: 60vh;width:100%;position:relative;top: 0px; }
	.table_vehicle_return thead th { position: sticky; top: 0; z-index: 1; }
	.table_vehicle_return tbody th { position: sticky; left: 0; }
	
	/* Just common table stuff. Really. */
	table  { border-collapse: collapse; width: 100%; }
	th, td { padding: 3px 3px !important; white-space: nowrap;font-size:11px; line-height:1.42857143;vertical-align: middle;}
	th     { background: #50607b;color: #fff !important; }
	
	.fixed_header1 { overflow: auto;max-height: 50vh;width:100%;position:relative;top: 0px; }
	.fixed_header1 thead th { position: sticky; top: 0; z-index: 1; }
	.fixed_header1 tbody th { position: sticky; left: 0; }
	
	/* Just common table stuff. Really. */
	.fixed_header1 table  { border-collapse: collapse; width: 100%; }
	th, td { padding: 0px 0px !important; white-space: nowrap; border:1px solid !important;font-size:11px; line-height:1.42857143!important;vertical-align: middle !important;}
	.fixed_header1 th     { background: #50607b;color: #fff !important; }
	
	
	#table_vehicle_return tr:hover {
    background-color: #ccc;
	}
	
	#table_vehicle_return td:hover {
    cursor: pointer;
	}
</style>
<style>
    table.dataTable tbody td {
    padding: 4px 4px !important;
    font-size: 11px;
	}
</style>
<?php init_tail(); ?>
<script>
	$("#search_data_vehicle_return").click(function(){ 
        var from_date = $('#from_date2').val();
        var to_date = $('#to_date2').val();
		
        $.ajax({
			url:"<?php echo admin_url(); ?>VehRtn/vehicle_return_model_new",
			dataType:"html",
			method:"POST",
			data:{from_date:from_date,to_date:to_date},
			beforeSend: function () {
				
				$('#searchh3').css('display','block');
				$('.table_vehicle_return tbody').css('display','none');
				
			},
			complete: function () {
				
				$('.table_vehicle_return tbody').css('display','');
				$('#searchh3').css('display','none');
			},
			success:function(data){
				$('#table_vehicle_return tbody').html(data);
                $('.get_VehicleRtnID').on('click',function(){ 
                    VRtnID = $(this).attr("data-id");
                    $('#transfer-modal_return_list').modal('hide');
                    $.ajax({
						url:"<?php echo admin_url(); ?>VehRtn/GetDetail",
						dataType:"JSON",
						method:"POST",
						data:{VRtnID:VRtnID},
						beforeSend: function () {
							$('#searchh11').css('display','block');
							$('#searchh11').css('color','blue');
						},
						complete: function () {
							$('#searchh11').css('display','none');
						},
						success:function(response){
							
							let VRtnDetails = response.ChallanDetails;
							let CratesDetails = response.CratesDetails;
							//alert(response.ReturnID);
							$('#vehicle_return_id').val(VRtnDetails.ReturnID.slice(-6));
							$('#vehicle_return_id_hidden').val(VRtnDetails.ReturnID);
							$('#challan_n').val(VRtnDetails.ChallanID);
							$('#route_code').val(VRtnDetails.RouteID);
							$('#route_name').val(VRtnDetails.name);
							$('#routekm').val(VRtnDetails.KM);
							$('#vehicle_number').val(VRtnDetails.VehicleID);
							$('#driver_id').val(VRtnDetails.DriverID);
							if(VRtnDetails.driver_fn !== null){
								var DName = VRtnDetails.driver_fn +' '+VRtnDetails.driver_ln;
								}else{
								var DName = '';
							}
							$('#driver_name').val(DName);
							if(VRtnDetails.loader_fn !== null){
								var LName = VRtnDetails.loader_fn +' '+VRtnDetails.loader_ln;
								}else{
								var LName = '';
							}
							$('#loder_id').val(VRtnDetails.LoaderID);
							$('#loder_name').val(LName);
							$('#salesman_id').val(VRtnDetails.SalesmanID);
							if(VRtnDetails.Salesman_fn !== null){
								var SName = VRtnDetails.Salesman_fn +' '+VRtnDetails.Salesman_ln;
								}else{
								var SName = '';
							}
							$('#salesman_name').val(SName);
							$('#vehicle_capc').val(VRtnDetails.VehicleCapacity);
							$('#challan_crates').val(VRtnDetails.Crates);
							$('#refund_crates').val(VRtnDetails.return_crates);
							var ChlDate = VRtnDetails.Transdate.substring(0, 10);
							var ChldateNew = ChlDate.split("-").reverse().join("/");
							$('#to_date').val(ChldateNew);
							
							var VRtnDate = VRtnDetails.returnTransdate.substring(0, 10);
							var VRtndateNew = VRtnDate.split("-").reverse().join("/");
							$('#from_date').val(VRtndateNew);
							$('#challan_n').attr('readonly', true);
							
							var Act_entry_date = VRtnDetails.Act_entry_datetime.substring(0, 10);
							var Act_entry_time = VRtnDetails.Act_entry_datetime.substring(10, 16);
							var Act_date = Act_entry_date.split("-").reverse().join("/");
							$('#Act_datetime').val(Act_date+Act_entry_time);
							
							var count_row = $("#row_count").val();
							var i = 1;
							for(var count = 1; count <= count_row; count++)
							{
								$("#row"+count).remove();
							}
							
							var html = '';
							var col = 0;
							for (var index = 0; index < CratesDetails.length; index++) {
								col = index + 1;
								html += '<tr class="accounts" id="row'+col+'">';
								html += '<td style="width: 125px;"><input type="text" readonly name="AccountID'+col+'" style="width: 125px;" id="AccountID'+col+'" value="'+ CratesDetails[index].act_id+'"></td>';
								html += '<td style="padding:1px 5px !important;">'+CratesDetails[index].company+'</td>';
								html += '<td style="padding:1px 5px !important;">'+CratesDetails[index].address+'</td>';
								if(CratesDetails[index].Qty == null || CratesDetails[index].Qty == 'undefined'){
									var OQty = 0;
									}else{
									var OQty = CratesDetails[index].Qty;
								}
								if(CratesDetails[index].VRtnCrates){
									var VRtnCrates = CratesDetails[index].VRtnCrates;
									}else{
									var VRtnCrates = 0;
								}
								html += '<td style="padding:1px 5px !important;">'+OQty+'</td>';
								html += '<td style="padding:1px 5px !important;">'+CratesDetails[index].CHLCrates+'</td>';
								var befor_crate_bal = parseInt(CratesDetails[index].balance_crates) + parseInt(VRtnCrates);
								html += '<td class="rtnqty" style="width: 80px;"><input type="text" name="rtncrates'+col+'" id="rtncrates'+col+'" onblur="calculate_balcrates();" value="'+VRtnCrates+'" style="width: 80px;text-align:right;" class="rtncrates"><input type="hidden" name="balcrates'+col+'" id="balcrates'+col+'" value="'+befor_crate_bal+'"><input type="hidden" name="colno" id="colno" value="'+col+'"></td>';
								html += '<td id="balCrates" style="padding:1px 5px !important;text-align:right;"><span>'+CratesDetails[index].balance_crates+'</span></td>';
								html += '</tr>';
							}
							
							$("#row_count").val(col);
							$('#crate_details_tbl tbody').append(html);
							
							
                            $('.saveBtn').hide();
                            $('.updateBtn').show();
                            $('.saveBtn2').hide();
                            $('.updateBtn2').show();
                            $('.printBtn').show();
						}
					});
				});
			}
		});
	});
	
    $('.get_challan_id').on('click',function(){ 
		
        $('#transfer-modal').modal('hide');
		$('#cancel').click();
        challan_id = $(this).attr("data-id");
        myFunction_table_details(challan_id);
        myFunction(challan_id);
	});
    
    function myFunction_table_details(challan_id) {
        $.ajax({
			url:"<?php echo admin_url(); ?>VehRtn/all_challan_details",
			dataType:"JSON",
			method:"POST",
			data:{challan_id:challan_id},
			beforeSend: function () {
				$('#searchh11').css('display','block');
				$('#searchh11').css('color','blue');
			},
			complete: function () {
				$('#searchh11').css('display','none');
			},
			success:function(response){
				var total_ItemID =(response.itemhead.length);
				var $itemModal = $('#crate_details_tbl');
				var count_row = $("#row_count").val();
				var i = 1;
				for(var count = 1; count <= count_row; count++)
				{
					$("#row"+count).remove();
				}
				
				// Crate table body and  payment table
				
                $.each(response.cratesandpayments, function (column1, value1) {
					var html = '';
					var html3 = '';
					var col = column1 + 1;
					$("#row_count").val(col);
					$("#row_count_pay").val(col);
					html += '<tr class="accounts" id="row'+col+'">';
					html += '<td style="width: 125px;"><input type="text" name="AccountID'+col+'" style="width: 125px;" id="AccountID'+col+'" value="'+value1.AccountID2+'"></td>';
					html += '<td style="padding:1px 5px !important;">'+value1.ShipTocompany+'</td>';
					html += '<td style="padding:1px 5px !important;">'+value1.ShipToaddress+'</td>';
					if(value1.Qty == null){
						var qty = 0;
                        }else{
						var qty =value1.Qty;
					}
					html += '<td style="padding:1px 5px !important;text-align: right;">'+qty+'</td>';
					html += '<td style="padding:1px 5px !important;text-align: right;">'+value1.crates_data+'</td>';
					html += '<td class="rtnqty" style="width: 80px;"><input type="text" name="rtncrates'+col+'" id="rtncrates'+col+'" onblur="calculate_balcrates();" value="0" style="width: 80px;text-align: right;" class="rtncrates"><input type="hidden" name="balcrates'+col+'" id="balcrates'+col+'" value="'+value1.balance_crates_org+'"><input type="hidden" name="colno" id="colno" value="'+col+'"></td>';
					html += '<td id="balCrates" style="padding:1px 5px !important;text-align: right;"><span>'+value1.balance_crates+'</span></td>';
					html += '</tr>';
					$('#crate_details_tbl tbody').append(html);
					
				})
                
			}
		});
	}
	
	function myFunction(challan_id) { 
        $.ajax({
			url:"<?php echo admin_url(); ?>VehRtn/unique_challan_details",
			dataType:"JSON",
			method:"POST",
			data:{challan_id:challan_id},
			
			success:function(data){
				$('#challan_n').val(data.ChallanID);
				$('#route_code').val(data.RouteID);
				$('#route_name').val(data.name);
				$('#routekm').val(data.KM);
				$('#vehicle_number').val(data.VehicleID);
				$('#driver_id').val(data.DriverID);
				$('#driver_name').val(data.driver_fn);
				$('#loder_id').val(data.LoaderID);
				$('#loder_name').val(data.loader_fn);
				$('#salesman_id').val(data.SalesmanID);
				$('#salesman_name').val(data.Salesman_fn);
				$('#challan_crates').val(data.Crates);
				$('#vehicle_capc').val(data.VehicleCapacity);
				var ChallanDate = data.Transdate.substring(0, 10);
                var ChallanDateNew = ChallanDate.split("-").reverse().join("/");
                $('#to_date').val(ChallanDateNew);
				$('#case_depo').val(0.00);
				$('#case_depo1').val(0.00);
				$('#check_depo').val(0.00);
				$('#total_expense').val(0.00);
				$('#total_expense1').val(0.00);
				$('#fresh_ret_amt').val(0.00);
				$('#fresh_ret_amt1').val(0.00);
				$('#NERT_trans').val(0.00);
				
			}
		});
	}
	
	$(document).ready(function(){
		$('.updateBtn').hide();
        $('.updateBtn2').hide();
		
		$("#VrtList").click(function(){
            $('#transfer-modal_return_list').find('button[type="submit"]').prop('disabled', false);
			$('#transfer-modal_return_list').modal('show');
			$('#transfer-modal_return_list').on('shown.bs.modal', function () {
				$('#myInput2').focus();
			})
		});
		
		$("#chlList").click(function(){
			$('#transfer-modal').modal('show');
			$('#transfer-modal').on('shown.bs.modal', function () {
				$('#myInput1').focus();
			})
		})
		
		$("#search_data").click(function(){ 
			var from_date = $('#from_date1').val();
			var to_date = $('#to_date1').val();
			var challan_route = $('#challan_route').val();
			$.ajax({
				url:"<?php echo admin_url(); ?>VehRtn/challan_details_model_new",
				dataType:"html",
				method:"POST",
				data:{from_date:from_date,to_date:to_date,challan_route:challan_route},
				beforeSend: function () {
					$('#searchh2').css('display','block');
					$('.table_adj_report tbody').css('display','none');
				},
				complete: function () {
					$('.table_adj_report tbody').css('display','');
					$('#searchh2').css('display','none');
				},
				success:function(data){
					$('#table_adj_report tbody').html(data);
					$('.get_challan_id').on('click',function(){ 
						$('#transfer-modal').modal('hide');
						$('#cancel').click();
						challan_id = $(this).attr("data-id");
						myFunction_table_details(challan_id);
						myFunction(challan_id);
					});
				}
			});
		});
	});
	
	// balance crate calculation
    function calculate_balcrates(){
        var p = $(".table.crate_details_tbl tbody tr.accounts");
        var totalRfCrates = 0;
        $.each(p, function() {
            var row_no = $(this).find("td.rtnqty input[name='colno']").val();
            var AccountID = $(this).find("td#AccountIDTD input[type='text']").val();
            var actualbal = $(this).find("td.rtnqty input[type='hidden']").val();
            var returnCrates = $(this).find("td.rtnqty input[type='text']").val();
            if(returnCrates !== "" && AccountID !== ""){
                totalRfCrates = parseInt(totalRfCrates) + parseInt(returnCrates);
			}
            var newBal = parseInt(actualbal) - parseInt(returnCrates);
            if(row_no == ""){
				
                $(this).find("td#balCrates_new span").html(newBal);
				
				}else{
                $(this).find("td#balCrates span").html(newBal);
			}
		})
        $("#refund_crates").val(totalRfCrates);
	}
	
	$("#AccountID").autocomplete({
        
        source: function( request, response ) {
			
			$.ajax({
				url: "<?=base_url()?>admin/VehRtn/GetAccountlistForCrates",
				type: 'post',
				dataType: "json",
				data: {
					search: request.term
				},
				success: function( data ) {
					response( data );
				}
			});
		},
        select: function (event, ui) {
			
			//alert(Conform);
			var ChallanID = $('#challan_n').val();
			if(empty(ChallanID)){
				alert('please select challanID');
				$("#AccountID").focus();
				return false;
				}else{
                $('#AccountID').val(ui.item.value);
                $('#party_name').html(ui.item.label);
                $('#party_name_val').val(ui.item.label);
                $('#address').html(ui.item.address);
                $('#address_val').val(ui.item.address);
                
                $("#rtncrates").focus();
                return false;
			}
		}
	});
	$('#AccountID').on('blur', function () {
		var AccountID = $(this).val();
		var ChallanID = $('#challan_n').val();
		if(empty(AccountID)){
			
            }else{
			$.ajax({
				url: "<?=base_url()?>admin/VehRtn/getAccountDetails",
				type: 'post',
				dataType: "json",
				data: {
					AccountID: AccountID,ChallanID:ChallanID
				},
				success: function( data ) {
					if(empty(data)){
						alert('AccountID not found.');
						$("#AccountID").val('');
						$("#AccountID").focus();
                        }else{
						$('#AccountID').val(data.AccountID); // display the selected text
						$('#address_val').val(data.Address); // display the selected text
						$('#address').html(data.Address); // display the selected text
						$('#party_name_val').val(data.company); // display the selected text
						$('#party_name').html(data.company); // display the selected text
						$('#chlCrates').html(data.CHLCrates); // display the selected text
						$('#chlCrates_val').val(data.CHLCrates); // display the selected text
						$('#opnCrates_val').val(data.OQty); // display the selected text
						$('#opnCrates').html(data.OQty); // display the selected text
						$('#balCrates_new_val').val(data.BQty); // display the selected text
						$('#balcrates').val(data.BQty); // display the selected text
						$('#balCrates_new').html(data.BQty); // display the selected text
						
						$("#rtncrates").focus();
					}
				}
			});
		}
	});
	
	// For Crates Details
    $('#rtncrates').on('blur', function () {
        
        var rtncrates =document.getElementById("rtncrates").value;
        if(rtncrates == "" || rtncrates == null){
            alert('please enter return crates...');
			}else{
            //alert('hello');
			var AccountID =document.getElementById("AccountID").value;
			var party_name_val =document.getElementById("party_name_val").value;
			var address_val =document.getElementById("address_val").value;
			var opnCrates_val =document.getElementById("opnCrates_val").value;
			var chlCrates_val =document.getElementById("chlCrates_val").value;
			var balcrates =document.getElementById("balcrates").value;
			
			var balCrates_new = balcrates - rtncrates;
			
			var table=document.getElementById("crate_details_tbl");
			var table_len=(table.rows.length) - 1;
			var html = '';
			
			if(AccountID == "" || AccountID == null){
				alert('please add AccountID');
				$('#AccountID').val('');
				$('#AccountID').focus();
				}else{
				var count = $("#row_count").val();
				var new_count = parseInt(count) + 1;
				$("#row_count").val(new_count);
				
				
				html += '<tr class="accounts" id="row'+table_len+'">';
				html += '<td><input type="text" name="AccountID'+table_len+'" style="width: 125px;" id="AccountID'+table_len+'" value="'+AccountID+'"></td>';
				html += '<td style="padding:1px 5px !important;">'+party_name_val+'</td>';
				html += '<td style="padding:1px 5px !important;">'+address_val+'</td>';
				if(opnCrates_val == null){
					var qty = 0;
					}else{
					var qty =opnCrates_val;
				}
				html += '<td style="padding:1px 5px !important;text-align: right;">'+qty+'</td>';
				html += '<td style="padding:1px 5px !important;text-align: right;"><span id="chlCrates'+table_len+'">'+chlCrates_val+'</span><input type="hidden" name="chlCrates_val'+table_len+'" id="chlCrates_val'+table_len+'" value="'+chlCrates_val+'"></td>';
				html += '<td class="rtnqty"><input type="text" name="rtncrates'+table_len+'" id="rtncrates'+table_len+'"  onblur="calculate_balcrates();" value="'+rtncrates+'" style="width: 80px;text-align: right;" class="rtncrates"><input type="hidden" name="balcrates'+table_len+'" id="balcrates'+table_len+'" value="'+balcrates+'"><input type="hidden" name="colno" id="colno" value="'+table_len+'"></td>';
				html += '<td id="balCrates" style="padding:1px 5px !important;text-align: right;"><span>'+balCrates_new+'</span></td>';
				html += '</tr>';
				var row = table.insertRow(table_len).outerHTML=html;
				
				document.getElementById("AccountID").value="";
				document.getElementById("party_name_val").value="";
				document.getElementById("address_val").value="";
				document.getElementById("opnCrates_val").value="";
				document.getElementById("balCrates_new_val").value="";
				document.getElementById("balcrates").value ="";
				document.getElementById("rtncrates").value="";
				document.getElementById("chlCrates_val").value="";
				
				
				document.getElementById("party_name").innerHTML="";
				document.getElementById("address").innerHTML ="";
				document.getElementById("opnCrates").innerHTML="";
				document.getElementById("balCrates_new").innerHTML="";
				document.getElementById("chlCrates").innerHTML="";
			}
		}
        
	});
	
	// Focus On AccountID For Crates
	$('#AccountID').on('focus',function(){
		$('#AccountID').val(''); // display the selected text
		$('#address_val').val(''); // display the selected text
		$('#address').html(''); // display the selected text
		$('#party_name_val').val(''); // display the selected text
		$('#party_name').html(''); // display the selected text
		$('#opnCrates_val').val(''); // display the selected text
		$('#opnCrates').html(''); // display the selected text
		$('#chlCrates_val').val(''); // display the selected text
		$('#chlCrates').html(''); // display the selected text
		$('#rtncrates').val(''); // display the selected text
		$('#balCrates_new_val').val(''); // display the selected text
		$('#balcrates').val(''); // display the selected text
		$('#balCrates_new').html(''); // display the selected text
	})
	
	// Focus On VehicleRtnID
	$('#cancel').on('click',function(){
		//alert('hello');
		var NextVRtnID = $("#NextVRtnID").val();
		$("#vehicle_return_id").val(NextVRtnID);
		$("#vehicle_return_id_hidden").val('');
		$("#challan_n").val('');
		$("#route_code").val('');
		$("#route_name").val('');
		$("#routekm").val('0.00');
		$("#vehicle_number").val('');
		$("#vehicle_capc").val('0.00');
		$("#driver_id").val('');
		$("#driver_name").val('');
		$("#loder_id").val('');
		$("#loder_name").val('');
		$("#salesman_id").val('');
		$("#salesman_name").val('');
		$("#challan_crates").val('0.00');
		$("#refund_crates").val('0.00');
		$("#fresh_ret_amt1").val('0.00');
		$("#case_depo1").val('0.00');
		$("#check_depo").val('0.00');
		$("#NERT_trans").val('0.00');
		$("#total_expense").val('0.00');
		$("#total_expense1").val('0.00');
		// $('#challan_n').attr('readonly', false);
		
		var html = '';
		html += '<tr class="accounts" id="row">';
		html += '<td id="AccountIDTD" style="width: 125px;"><input type="text" name="AccountID" style="width: 125px;" id="AccountID" class="ui-autocomplete-input" autocomplete="off" ></td>';
		html += '<td style="padding:1px 5px !important;"><span id="party_name"></span><input type="hidden" name="party_name_val" id="party_name_val"></td>';
		html += '<td style="padding:1px 5px !important;"><span id="address"></span><input type="hidden" name="address_val" id="address_val" value="" ></td>';
		html += '<td style="padding:1px 5px !important;text-align: right;"><span id="opnCrates"></span><input type="hidden" name="opnCrates_val" id="opnCrates_val"></td>';
		html += '<td style="padding:1px 5px !important;text-align: right;"><span id="chlCrates"><input type="hidden" name="chlCrates_val" id="chlCrates_val"></td>';
		html += '<td class="rtnqty" style="width: 80px;">';
		html += '<input type="text" name="rtncrates" id="rtncrates" class="rtncrates" onblur="calculate_balcrates();" style="width: 80px;text-align: right;"  >';
		html += '<input type="hidden" name="balcrates" id="balcrates" value="0">';
		html += '<input type="hidden" name="colno" id="colno" value="">';
		html += '</td>';
		html += '<td tyle="padding:1px 5px !important;text-align: right;"><span id="balCrates_new" style="text-align: right;"></span><input type="hidden" name="balCrates_new_val" id="balCrates_new_val" class="form-control"></td>';
		html += '</tr>';
		// $('#crate_details_tbl tbody').html(html);
		var TotalRow = $("#row_count").val();
		var crRow = parseInt(TotalRow);
		
		for (var A = 1; A <= crRow; A++) {
			var id = 'row'+A;
			document.getElementById(id).remove();
		}
		
		$("#row_count").val('0');
		
		$('.saveBtn').show();
		$('.saveBtn2').show();
		$('.updateBtn').hide();
		$('.updateBtn2').hide();
		$('.printBtn').hide();
	});
	
	
	// Save New Item
	$('.saveBtn').on('click',function(){ 
		
		// Ganeral Data
        var refund_crates = $("#refund_crates").val();
        var from_date = $("#from_date").val();
        var challan_n = $("#challan_n").val();
        var vehicle_number = $("#vehicle_number").val();
		
        var Act_datetime = $("#Act_datetime").val();
        if(challan_n !== ''){
            // Crate Details
            var CrateCount = $("#row_count").val();
            var CrateArray = new Array();
            for (i=1;i<=CrateCount;i++) {
                var id= 'AccountID'+i;
                var AccountID = document.getElementById(id).value;
                var id2= 'rtncrates'+i;
                var RtnCrates = document.getElementById(id2).value;
                var ii = i - 1;
				CrateArray[ii]=new Array();
				CrateArray[ii][0]=AccountID;
				CrateArray[ii][1]=RtnCrates;
			}
            var CratesSerializedArr = JSON.stringify(CrateArray);
			
            $.ajax({
                url:"<?php echo admin_url(); ?>VehRtn/SaveVehRtnCrates",
                dataType:"JSON",
                method:"POST",
                data:{refund_crates:refund_crates,from_date:from_date,challan_n:challan_n,CratesSerializedArr:CratesSerializedArr,vehicle_number:vehicle_number,
					CrateCount:CrateCount,Act_datetime:Act_datetime
				},
                beforeSend: function () {
					$('.searchh3').css('display','block');
					$('.searchh3').css('color','blue');
				},
                complete: function () {
					$('.searchh3').css('display','none');
				},
                success:function(data){
                    if(data == false){
                        
						}else if(data == 'Created'){
                        alert_float('warning', 'VehRtn Already created for this challan...');
						$('#vehicle_return_id').val(data);
						$("#NextVRtnID").val(data);
						$("#vehicle_return_id_hidden").val('');
						$("#challan_n").val('');
						$("#route_code").val('');
						$("#route_name").val('');
						$("#routekm").val('0.00');
						$("#vehicle_number").val('');
						$("#vehicle_capc").val('0.00');
						$("#driver_id").val('');
						$("#driver_name").val('');
						$("#loder_id").val('');
						$("#loder_name").val('');
						$("#salesman_id").val('');
						$("#salesman_name").val('');
						$("#challan_crates").val('0.00');
						$("#refund_crates").val('0.00');
						$("#fresh_ret_amt1").val('0.00');
						$("#case_depo1").val('0.00');
						$("#check_depo").val('0.00');
						$("#NERT_trans").val('0.00');
						$("#total_expense").val('0.00');
						$("#total_expense1").val('0.00');
						// Create 
						var TotalRow = $("#row_count").val();
						var crRow = parseInt(TotalRow);
						for (var A = 1; A <= crRow; A++) {
							var id = 'row'+A;
							document.getElementById(id).remove();
						}
						$("#row_count").val('0');
						
						$("#search_data_vehicle_return").click();
						$("#search_data").click();
						
						$('.saveBtn').show();
						$('.saveBtn2').show();
						$('.updateBtn').hide();
						$('.updateBtn2').hide();
						}else{
						alert_float('success', 'Record created successfully...');
						$('#vehicle_return_id').val(data);
						$("#NextVRtnID").val(data);
						$("#vehicle_return_id_hidden").val('');
						$("#challan_n").val('');
						$("#route_code").val('');
						$("#route_name").val('');
						$("#routekm").val('0.00');
						$("#vehicle_number").val('');
						$("#vehicle_capc").val('0.00');
						$("#driver_id").val('');
						$("#driver_name").val('');
						$("#loder_id").val('');
						$("#loder_name").val('');
						$("#salesman_id").val('');
						$("#salesman_name").val('');
						$("#challan_crates").val('0.00');
						$("#refund_crates").val('0.00');
						$("#fresh_ret_amt1").val('0.00');
						$("#case_depo1").val('0.00');
						$("#check_depo").val('0.00');
						$("#NERT_trans").val('0.00');
						$("#total_expense").val('0.00');
						$("#total_expense1").val('0.00');
						// Create 
						var TotalRow = $("#row_count").val();
						var crRow = parseInt(TotalRow);
						for (var A = 1; A <= crRow; A++) {
							var id = 'row'+A;
							document.getElementById(id).remove();
						}
						$("#row_count").val('0');
						
						$("#search_data_vehicle_return").click();
						$("#search_data").click();
						
						$('.saveBtn').show();
						$('.saveBtn2').show();
						$('.updateBtn').hide();
						$('.updateBtn2').hide();
					}
					
				}
			});
			}else{
            alert('please select Challan...');
            $('#challan_n').focus();
		}
		
	});
	
	// Update Exiting VRtnID
	$('.updateBtn').on('click',function(){ 
		
		// Ganeral Data
        var refund_crates = $("#refund_crates").val();
        var VRtnID = $("#vehicle_return_id_hidden").val();
        var from_date = $("#from_date").val();
        var challan_n = $("#challan_n").val();
        var vehicle_number = $("#vehicle_number").val();
        var Act_datetime = $("#Act_datetime").val();
        if(challan_n !== ''){
			// Crate Details
            var CrateCount = $("#row_count").val();
            var CrateArray = new Array();
            for (i=1;i<=CrateCount;i++) {
                var id= 'AccountID'+i;
                var AccountID = document.getElementById(id).value;
                var id2= 'rtncrates'+i;
                var RtnCrates = document.getElementById(id2).value;
                var ii = i - 1;
				CrateArray[ii]=new Array();
				CrateArray[ii][0]=AccountID;
				CrateArray[ii][1]=RtnCrates;
			}
            var CratesSerializedArr = JSON.stringify(CrateArray);
            
			
            $.ajax({
                url:"<?php echo admin_url(); ?>VehRtn/UpdateVehRtnCrates",
                dataType:"JSON",
                method:"POST",
                data:{refund_crates:refund_crates,from_date:from_date,challan_n:challan_n,CratesSerializedArr:CratesSerializedArr,vehicle_number:vehicle_number,
					CrateCount:CrateCount,VRtnID:VRtnID,Act_datetime:Act_datetime
				},
                beforeSend: function () {
					$('.searchh4').css('display','block');
					$('.searchh4').css('color','blue');
				},
                complete: function () {
					$('.searchh4').css('display','none');
				},
                success:function(data){
                    if(data == false){
                        
						}else{
						alert_float('success', 'Record updated successfully...');
						$('#vehicle_return_id').val(data);
						$("#NextVRtnID").val(data);
						$("#challan_n").val('');
						$("#route_code").val('');
						$("#route_name").val('');
						$("#routekm").val('0.00');
						$("#vehicle_number").val('');
						$("#vehicle_capc").val('0.00');
						$("#driver_id").val('');
						$("#driver_name").val('');
						$("#loder_id").val('');
						$("#loder_name").val('');
						$("#salesman_id").val('');
						$("#salesman_name").val('');
						$("#challan_crates").val('0.00');
						$("#refund_crates").val('0.00');
						$("#fresh_ret_amt1").val('0.00');
						$("#case_depo1").val('0.00');
						$("#check_depo").val('0.00');
						$("#NERT_trans").val('0.00');
						$("#total_expense").val('0.00');
						$("#total_expense1").val('0.00');
						// Create 
						var TotalRow = $("#row_count").val();
						var crRow = parseInt(TotalRow);
						for (var A = 1; A <= crRow; A++) {
							var id = 'row'+A;
							document.getElementById(id).remove();
						}
						
						$("#row_count").val('0');
						
						$("#search_data_vehicle_return").click();
						$("#search_data").click();
						
						$('.saveBtn').show();
						$('.saveBtn2').show();
						$('.updateBtn').hide();
						$('.updateBtn2').hide();
					}
					
				}
			});
		}
        
	});
	
	function myFunction3() {
		var input, filter, table, tr, td, i, txtValue;
		input = document.getElementById("myInput2");
		filter = input.value.toUpperCase();
		table = document.getElementById("table_vehicle_return");
		tbody = table.getElementsByTagName("tbody")[0]; // Get the first tbody element
		tr = tbody.getElementsByTagName("tr"); 
		for (i = 0; i < tr.length; i++) 
        {
            tr[i].style.display = "none"; 
            td = tr[i].getElementsByTagName("td"); 
			
            for (j = 0; j < td.length; j++) {
                if (td[j]) {
                    txtValue = td[j].textContent || td[j].innerText;                
                    if (txtValue.toUpperCase().indexOf(filter.toUpperCase()) > -1) {
                        tr[i].style.display = "";  
                        break; 
					}
				}
			}
		}
	}
	
	
	function myFunction2() {
		var input, filter, table, tr, td, i, txtValue;
		input = document.getElementById("myInput1");
		filter = input.value.toUpperCase();
		table = document.getElementById("table_adj_report");
		tr = table.getElementsByTagName("tr");
		for (i = 1; i < tr.length; i++) 
        {
            tr[i].style.display = "none"; 
            td = tr[i].getElementsByTagName("td"); 
			
            for (j = 0; j < td.length; j++) {
                if (td[j]) {
                    txtValue = td[j].textContent || td[j].innerText;                
                    if (txtValue.toUpperCase().indexOf(filter.toUpperCase()) > -1) {
                        tr[i].style.display = "";  
                        break; 
					}
				}
			}
		}
	}
	
</script>