<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<h4 class="customer-profile-group-heading"><?php echo _l('client_add_edit_profile'); ?></h4>
<div class="row">
    <?php if(isset($client)){ ?>
   <?php echo form_open($this->uri->uri_string(),array('class'=>'client-form','autocomplete'=>'off')); ?>
   <?php } else { ?>
   <?php echo form_open(admin_url('clients/client_add'),array('class'=>'client-form','autocomplete'=>'off')); ?>
   <?php } ?>
   <div class="additional"></div>
   <div class="col-md-12">
      <div class="horizontal-scrollable-tabs">
         <div class="scroller arrow-left"><i class="fa fa-angle-left"></i></div>
         <div class="scroller arrow-right"><i class="fa fa-angle-right"></i></div>
         <div class="horizontal-tabs">
            <ul class="nav nav-tabs profile-tabs row customer-profile-tabs nav-tabs-horizontal" role="tablist">
               <li role="presentation" class="<?php if(!$this->input->get('tab')){echo 'active';}; ?>">
                  <a href="#contact_info" aria-controls="contact_info" role="tab" data-toggle="tab">
                  <?php echo _l( 'customer_profile_details'); ?>
                  </a>
               </li>
               <?php
                  $customer_custom_fields = false;
                  if(total_rows(db_prefix().'customfields',array('fieldto'=>'customers','active'=>1)) > 0 ){
                       $customer_custom_fields = true;
                   ?>
               <li role="presentation" class="<?php if($this->input->get('tab') == 'custom_fields'){echo 'active';}; ?>">
                  <a href="#custom_fields" aria-controls="custom_fields" role="tab" data-toggle="tab">
                  <?php echo hooks()->apply_filters('customer_profile_tab_custom_fields_text', _l( 'custom_fields')); ?>
                  </a>
               </li>
               <?php } ?>
               
               <?php if(isset($client)){?>
               <li role="presentation">
                  <a href="#billing_and_shipping" aria-controls="billing_and_shipping" role="tab" data-toggle="tab">
                  <?php echo _l( 'billing_shipping'); ?>
                  </a>
               </li>
               <?php hooks()->do_action('after_customer_billing_and_shipping_tab', isset($client) ? $client : false); ?>
               <?php } ?>
               
               
               
               <?php if(isset($client)){ ?>
               <li role="presentation">
                  <a href="#customer_admins" aria-controls="customer_admins" role="tab" data-toggle="tab">
                  <?php echo _l( 'customer_admins' ); ?>
                  </a>
               </li>
               <?php hooks()->do_action('after_customer_admins_tab',$client); ?>
               <?php } ?>
            </ul>
         </div>
      </div>
      <div class="tab-content mtop15">
         <?php hooks()->do_action('after_custom_profile_tab_content',isset($client) ? $client : false); ?>
         <?php if($customer_custom_fields) { ?>
         <div role="tabpanel" class="tab-pane <?php if($this->input->get('tab') == 'custom_fields'){echo ' active';}; ?>" id="custom_fields">
            <?php $rel_id=( isset($client) ? $client->userid : false); ?>
            <?php echo render_custom_fields( 'customers',$rel_id); ?>
            
            <div class="row">
                <?php 
                $item_division = $client->itemdivision; 
                $item_division_new = unserialize($item_division);
                
                $itemdivision_comp = $client->itemdivision_comp; 
                $itemdivision_comp_new = unserialize($itemdivision_comp);
                
                //print_r($item_division);
                
                ?>
                    <div class="col-md-4">
                         <table class="table scroll-responsive">
                             <thead style="background-color: #0286c2;">
                                 <tr>
                                     <th style="color:#fff;">#</th>
                                 <th style="color:#fff;">Item Division</th>
                                 
                                 <th style="color:#fff;">Company</th>
                                 </tr>
                                 
                             </thead>
                             <tbody>
                                 <?php foreach($itemdivision as $item_division){ ?>
                                 <tr>
                                     <td><div class="checkbox">
                                         <?php $item_division_new ?>
                                         <input type="checkbox" name="itemdiv<?php echo $item_division["id"];?>" value="<?php echo $item_division["id"];?>" <?php if (in_array($item_division["id"], $item_division_new)) { echo "checked"; }?>><label></label></div></td>
                                     <td><?php echo $item_division["itemdivision_name"]; ?></td>
                                     <td>
                                         
                                         <select name="itemdivisioncomp<?php echo $item_division["id"];?>" id="itemdivisioncomp<?php echo $item_division["id"];?>" class="form-control selectpicker">
                                             <option value="">Select</option>
                                             <?php foreach($rootcompany as $r_company){ ?>
                                             <option value="<?php echo $r_company["id"]; ?>" <?php foreach($itemdivision_comp_new as $key => $value) { if($key==$item_division["id"] && $value==$r_company["id"]) { echo "selected"; }}?>><?php echo $r_company["comp_short"];?></option>
                                             
                                             <?php } ?>
                                             </select>
                                         
                                     </td>
                                 </tr>
                                 <?php } ?>
                                 
                             </tbody>
                         </table>
                         
                        </div>
                      <div class="col-md-8">
                          
                          <?php 
                            $company_assigned = $client->company_assigned; 
                            $company_assigned_new = unserialize($company_assigned);
                            
                            $company_assigned_staff = $client->company_assigned_staff; 
                            $company_assigned_staff_new = unserialize($company_assigned_staff);
                            
                            $opening_bal = $client->opening_bal; 
                            $opening_bal_new = unserialize($opening_bal);
                            
                            $drcr = $client->drcr; 
                            $drcr_new = unserialize($drcr);
                           /* echo "<pre>";
                            print_r($rootcompany);
                            echo "<br>";*/
                            //print_r($company_assigned_staff_new);
                            
                          ?>
                         <table class="table scroll-responsive">
                             <thead style="background-color: #0286c2;">
                                 <tr>
                                     <th style="color:#fff;">#</th>
                                 <th style="color:#fff;">Company</th>
                                 <th style="color:#fff;">Sales Person Name</th>
                                 <th style="color:#fff;width: 100px;">Opening</th>
                                 <th style="color:#fff;">DR/CR</th>
                                 </tr>
                                 
                             </thead>
                             <tbody>
                                 <?php foreach($rootcompany as $r_company){ ?>
                                 <tr>
                                     <td><div class="checkbox"><input type="checkbox" name="company_assigned<?php echo $r_company["id"];?>" value="<?php echo $r_company["id"];?>" <?php if (in_array($r_company["id"], $company_assigned_new)) { echo "checked"; }?>><label></label></div></td>
                                     <td><?php echo $r_company["company_name"];?></td>
                                     <td> 
                                        
                                         <!--<select name="company_assigned_staff<?php echo $r_company["id"];?>" id="company_assign_staff<?php echo $r_company["id"];?>" class="form-control selectpicker">
                                             <option value="">Select</option>
                                            <?php foreach($staffs as $stf){ ?>
                                             <option value="<?php echo $stf['staffid'];?>" <?php foreach($company_assigned_new as $key => $value) { if($key == $r_company["id"] && $value == $stf['staffid']) { echo "selected "; }}?>><?php echo $stf["firstname"]." ".$stf["lastname"];?></option>
                                             <?Php } ?>
                                             </select>-->
                                        <?php
                                         $selected = array();
                                        
                               foreach($customer_admins as $c_admin){
                                   if($c_admin['company_id']==$r_company["id"]){
                                       array_push($selected,$c_admin['staff_id']);
                                   }
                                  
                               }
               
                                        echo render_select('company_assigned_staff'.$r_company["id"].'[]',$staff,array('staffid',array('firstname','lastname')),'',$selected,array('multiple'=>true),array(),'','',false); ?> 
                                     
                                     </td>
                                     <td>
                                        <input type="text" name="opening_bal<?php echo $r_company["id"];?>" id="opening_bal<?php echo $r_company["id"];?>" value="<?php foreach($opening_bal_new as $key => $value) { if($key==$r_company["id"]) { echo $value; }}?>" class="form-control">
                                    </td>
                                     <td>
                                         
                                         <select name="drcr<?php echo $r_company["id"];?>" id="drcr<?php echo $r_company["id"];?>" class="form-control selectpicker">
                                             <option value="DR" <?php foreach($drcr_new as $key => $value) { if($key==$r_company["id"] && $value=="DR") { echo "selected"; }}?>>DR</option>
                                             <option value="CR" <?php foreach($drcr_new as $key => $value) { if($key==$r_company["id"] && $value=="CR") { echo "selected"; }}?>>CR</option>
                                             </select>
                                         
                                     </td>
                                 </tr>
                                 <?php } ?>
                             </tbody>
                         </table>
                       
                        </div>
                        
                        
                        
                    
                  </div>
         </div>
         <?php } ?>
         
         
         <div role="tabpanel" class="tab-pane<?php if(!$this->input->get('tab')){echo ' active';}; ?>" id="contact_info">
            
            <div class="row">
            <div class="col-md-6">
                <div id="contact-profile-image" class="form-group<?php if(isset($contact) && !empty($contact->profile_image)){echo ' hide';} ?>">
                            <label for="profile_image" class="profile-image"><?php echo _l('client_profile_image'); ?></label>
                            <input type="file" name="profile_image" class="form-control" id="profile_image">
                </div>
            </div>
            
            </div>
            
            <div class="row">
            <div class="col-md-4">
                    <?php $value=( isset($client) ? $client->company : ''); ?>
                  <?php $attrs = (isset($client) ? array() : array('autofocus'=>true)); ?>
                  <?php echo render_input( 'company', 'client_company',$value,'text',$attrs); ?>
                  <div id="company_exists_info" class="hide"></div>
                </div>
            <div class="col-md-4">
                 <!--<?php echo render_input( 'title', 'contact_position',""); ?>-->
                 <div class="form-group" app-field-wrapper="contact_position">
                     <label class="control-label" for><?php echo _l( 'contact_position' ); ?></label>
                 <select name="title" class="form-control">
                     <option value="Owner" <?php if($client_contacts[0]['title']=="Owner"){echo 'selected';}?>>Owner</option>
                    <option value="Employee" <?php if($client_contacts[0]['title']=="Employee"){echo 'selected';}?>>Employee</option>
                    
                 </select>
                 </div>
                 
             
                 
                </div>
            <div class="col-md-4">
                <?php
                //print_r($client_contacts);
                //echo $client_contacts[0]['firstname'];
                ?>
                <?php $value=( isset($client_contacts) ? $client_contacts[0]['firstname'] : ''); ?>
                <?php //$attrs = (isset($client_contacts) ? array() : array('autofocus'=>true)); ?>
                <?php echo render_input( 'firstname', 'client_firstname',$value,'text',$attrs); ?>
                
               
                </div>
            <div class="col-md-4">
                <?php $value=( isset($client_contacts) ? $client_contacts[0]['lastname'] : ''); ?>
                <?php $attrs = (isset($client_contacts) ? array() : array('autofocus'=>true)); ?>
                <?php echo render_input( 'lastname', 'client_lastname',$value,'text',$attrs); ?>
                </div>
            <div class="col-md-4">
                 <!--<?php echo render_input( 'phonenumber_contact', 'client_mobile',"",'text',array('autocomplete'=>'off')); ?>-->
                 <?php $value=( isset($client) ? $client->phonenumber : ''); ?>
                  <?php echo render_input( 'phonenumber', 'client_mobile',$value); ?>
                  <div id="company_exists_info" class="hide"></div>
                </div>
            <div class="col-md-4">
                <?php $value=( isset($client) ? $client->altphonenumber : ''); ?>
                <?php $attrs = (isset($client_contacts) ? array() : array('autofocus'=>true)); ?>
                  <?php echo render_input( 'altphonenumber', 'client_phonenumber',$value); ?>
                </div>
            <div class="col-md-4">
                <?php $value=( isset($client_contacts) ? $client_contacts[0]['email'] : ''); ?>
                <?php $attrs = (isset($client_contacts) ? array() : array('autofocus'=>true)); ?>
                 <?php echo render_input( 'email', 'client_email',$value, 'email'); ?>
                </div>
            <div class="col-md-4">
                 <?php if(get_option('company_requires_vat_number_field') == 1){
                     $value=( isset($client) ? $client->vat : '');
                     echo render_input( 'vat', 'client_vat_number',$value);
                     } ?>
                </div>
            <div class="col-md-4">
                
                <?php if((isset($client) && empty($client->website)) || !isset($client)){
                     $value=( isset($client) ? $client->website : '');
                     echo render_input( 'website', 'client_website',$value);
                     } else { ?>
                  <div class="form-group">
                     <label for="website"><?php echo _l('client_website'); ?></label>
                     <div class="input-group">
                        <input type="text" name="website" id="website" value="<?php echo $client->website; ?>" class="form-control">
                        <div class="input-group-addon">
                           <span><a href="<?php echo maybe_add_http($client->website); ?>" target="_blank" tabindex="-1"><i class="fa fa-globe"></i></a></span>
                        </div>
                     </div>
                  </div>
                  <?php } ?>
                </div>
            <div class="col-md-4">
                    <?php
                     $selected = array();
                     if(isset($customer_groups)){
                       foreach($customer_groups as $group){
                          array_push($selected,$group['groupid']);
                       }
                     }
                     if(is_admin() || get_option('staff_members_create_inline_customer_groups') == '1'){
                      echo render_select_with_input_group('groups_in[]',$groups,array('id','name'),'customer_groups',$selected,'<a href="#" data-toggle="modal" data-target="#customer_group_modal"><i class="fa fa-plus"></i></a>',array('data-actions-box'=>false),array(),'','',false);
                      } else {
                        echo render_select('groups_in[]',$groups,array('id','name'),'customer_groups',$selected,array('multiple'=>false,'data-actions-box'=>false),array(),'','',false);
                      }
                     ?>
                </div>
            <div class="col-md-4">
                    <?php $value=( isset($client) ? $client->address : ''); ?>
                  <!--<?php echo render_textarea( 'address', 'client_address',$value); ?>-->
                  <?php echo render_input( 'address', 'client_address',$value); ?>
                </div>
            <div class="col-md-4">
                    <?php $value=( isset($client) ? $client->city : ''); ?>
                  <?php echo render_input( 'city', 'client_city',$value); ?>
            </div>
                
            <div class="col-md-4">
               <!-- <?php $value=( isset($client) ? $client->state : ''); ?>
                  <?php echo render_input( 'state', 'client_state',$value); ?>-->
                  <?php //print_r($state);
                     $selected =( isset($client) ? $client->state : '');
                    
                     echo render_select( 'state',$state,array( 'id',array( 'name')), 'client_state',$selected,array('data-none-selected-text'=>_l('dropdown_non_selected_tex')));
                     
                     ?>
            </div>
            
            <div class="col-md-4">
                <?php $value=( isset($client) ? $client->zip : ''); ?>
                  <?php echo render_input( 'zip', 'client_postal_code',$value); ?>
                
            </div> 
            
            <div class="col-md-4">
                <?php $countries= get_all_countries();
                     $customer_default_country = get_option('customer_default_country');
                     $selected =( isset($client) ? $client->country : $customer_default_country);
                     echo render_select( 'country',$countries,array( 'country_id',array( 'short_name')), 'clients_country',$selected,array('data-none-selected-text'=>_l('dropdown_non_selected_tex')));
                     ?>
            </div> 
            
            <div class="col-md-4">
                
                  <?php if(!isset($client)){ ?>
                  <i class="fa fa-question-circle pull-left" data-toggle="tooltip" data-title="<?php echo _l('customer_currency_change_notice'); ?>"></i>
                  <?php }
                     $s_attrs = array('data-none-selected-text'=>_l('system_default_string'));
                     $selected = '';
                     if(isset($client) && client_have_transactions($client->userid)){
                        $s_attrs['disabled'] = true;
                     }
                     foreach($currencies as $currency){
                        if(isset($client)){
                          if($currency['id'] == $client->default_currency){
                            $selected = $currency['id'];
                         }
                      } 
                      
                      if(!isset($client)){
                          
                          $def = $currency['isdefault'];
                          if($def=="1") {
                               $selected = $currency['id'];
                          }
                          
                      }
                     }
                    // print_r($currencies);
                     
                            // Do not remove the currency field from the customer profile!
                     echo render_select('default_currency',$currencies,array('id','name','symbol'),'invoice_add_edit_currency',$selected,$s_attrs); ?>
                
            </div> 
            
            
                
                <?php if(!is_language_disabled()){ ?>
                <div class="col-md-4">
                  <div class="form-group select-placeholder">
                     <label for="default_language" class="control-label"><?php echo _l('localization_default_language'); ?>
                     </label>
                     <select name="default_language" id="default_language" class="form-control selectpicker" data-none-selected-text="<?php echo _l('dropdown_non_selected_tex'); ?>">
                        <option value=""><?php echo _l('system_default_string'); ?></option>
                        <?php foreach($this->app->get_available_languages() as $availableLanguage){
                           $selected = '';
                           if(isset($client)){
                              if($client->default_language == $availableLanguage){
                                 $selected = 'selected';
                              }
                           }
                           ?>
                        <option value="<?php echo $availableLanguage; ?>" <?php echo $selected; ?>><?php echo ucfirst($availableLanguage); ?></option>
                        <?php } ?>
                     </select>
                  </div>
                </div> 
                  <?php } ?>
                
            
            
            <div class="col-md-12">
                
                <?php if(!isset($client)){ ?>
            <div class="row">
                <div class="col-md-6">
                <div class="checkbox checkbox-primary">
                    <input type="checkbox" name="is_primary" id="contact_primary" <?php if((!isset($contact) && total_rows(db_prefix().'contacts',array('is_primary'=>1,'userid'=>$customer_id)) == 0) || (isset($contact) && $contact->is_primary == 1)){echo 'checked';}; ?> <?php if((isset($contact) && total_rows(db_prefix().'contacts',array('is_primary'=>1,'userid'=>$customer_id)) == 1 && $contact->is_primary == 1)){echo 'disabled';} ?>>
                    <label for="contact_primary">
                        <?php echo _l( 'contact_primary'); ?>
                    </label>
                </div>
                
                <?php if(!isset($contact) && is_email_template_active('new-client-created')){ ?>
                <div class="checkbox checkbox-primary">
                    <input type="checkbox" name="donotsendwelcomeemail" id="donotsendwelcomeemail">
                    <label for="donotsendwelcomeemail">
                        <?php echo _l( 'client_do_not_send_welcome_email'); ?>
                    </label>
                </div>
                <?php } ?>
                
                <!--<?php if(is_email_template_active('contact-set-password')){ ?>
                <div class="checkbox checkbox-primary">
                    <input type="checkbox" name="send_set_password_email" id="send_set_password_email">
                    <label for="send_set_password_email">
                        <?php echo _l( 'client_send_set_password_email'); ?>
                    </label>
                </div>
                <?php } ?> -->
                </div>
            </div>
            <?php } ?>
            
             
            </div> 
        <div class="col-md-12">
                
                <div class="mtop15 <?php if(isset($client) && (!is_empty_customer_company($client->userid) && total_rows(db_prefix().'contacts',array('userid'=>$client->userid,'is_primary'=>1)) > 0)) { echo ''; } else {echo ' hide';} ?>" id="client-show-primary-contact-wrapper">
                  <div class="checkbox checkbox-info mbot20 no-mtop">
                     <input type="checkbox" name="show_primary_contact"<?php if(isset($client) && $client->show_primary_contact == 1){echo ' checked';}?> value="1" id="show_primary_contact">
                     <label for="show_primary_contact"><?php echo _l('show_primary_contact',_l('invoices').', '._l('estimates').', '._l('payments').', '._l('credit_notes')); ?></label>
                  </div>
               </div>
               <h5 class="no-mtop"><?php echo _l('billing_address'); ?>&nbsp;&nbsp;<input type="checkbox" class="billing-same-as-customer1"><small class="font-medium-xs">&nbsp;<?php echo _l('customer_billing_same_as_profile'); ?></small> </h5>
                    <h5 class="no-mtop"> 
                           <?php echo _l('shipping_address'); ?>&nbsp;&nbsp;<input type="checkbox" class="customer-copy-billing-address1"><small class="font-medium-xs">&nbsp;<?php echo _l('customer_billing_same_as_profile'); ?></small> </h5>
                    
                
            </div> 
            
            
            
        </div>
            <?php if(!isset($client)){ ?>
            
            <div class="row">
               
                
                <div class="col-md-6">
                   
            
             
             <?php $rel_id=( isset($contact) ? $contact->id : false); ?>
                    <?php echo render_custom_fields( 'contacts',$rel_id); ?>
              
              <!--<div class="client_password_set_wrapper">
                        <label for="password" class="control-label">
                            <?php echo _l( 'client_password'); ?>
                        </label>
                        <div class="input-group">

                            <input type="password" class="form-control password" name="password" autocomplete="false">
                            <span class="input-group-addon">
                                <a href="#password" class="show_password" onclick="showPassword('password'); return false;"><i class="fa fa-eye"></i></a>
                            </span>
                            <span class="input-group-addon">
                                <a href="#" class="generate_password" onclick="generatePassword(this);return false;"><i class="fa fa-refresh"></i></a>
                            </span>
                        </div>
                        <?php if(isset($contact)){ ?>
                        <p class="text-muted">
                            <?php echo _l( 'client_password_change_populate_note'); ?>
                        </p>
                        <?php if($contact->last_password_change != NULL){
                            echo _l( 'client_password_last_changed');
                            echo '<span class="text-has-action" data-toggle="tooltip" data-title="'._dt($contact->last_password_change).'"> ' . time_ago($contact->last_password_change) . '</span>';
                        }
                    } ?>
                </div> -->
                </div>
                </div>
                
            
            <?php } ?>
           
         </div>
         <?php if(isset($client)){ ?>
         <div role="tabpanel" class="tab-pane" id="customer_admins">
            <?php if (has_permission('customers', '', 'create') || has_permission('customers', '', 'edit')) { ?>
            <a href="#" data-toggle="modal" data-target="#customer_admins_assign" class="btn btn-info mbot30"><?php echo _l('assign_admin'); ?></a>
            <?php } ?>
            <table class="table dt-table">
               <thead>
                  <tr>
                     <th><?php echo _l('staff_member'); ?></th>
                     <th><?php echo _l('customer_admin_date_assigned'); ?></th>
                     <?php if(has_permission('customers','','create') || has_permission('customers','','edit')){ ?>
                     <th><?php echo _l('options'); ?></th>
                     <?php } ?>
                  </tr>
               </thead>
               <tbody>
                  <?php foreach($customer_admins as $c_admin){ ?>
                  <tr>
                     <td><a href="<?php echo admin_url('profile/'.$c_admin['staff_id']); ?>">
                        <?php echo staff_profile_image($c_admin['staff_id'], array(
                           'staff-profile-image-small',
                           'mright5'
                           ));
                           echo get_staff_full_name($c_admin['staff_id']); ?></a>
                     </td>
                     <td data-order="<?php echo $c_admin['date_assigned']; ?>"><?php echo _dt($c_admin['date_assigned']); ?></td>
                     <?php if(has_permission('customers','','create') || has_permission('customers','','edit')){ ?>
                     <td>
                        <a href="<?php echo admin_url('clients/delete_customer_admin/'.$client->userid.'/'.$c_admin['staff_id']); ?>" class="btn btn-danger _delete btn-icon"><i class="fa fa-remove"></i></a>
                     </td>
                     <?php } ?>
                  </tr>
                  <?php } ?>
               </tbody>
            </table>
         </div>
         <?php } ?>
         <div role="tabpanel" class="tab-pane" id="billing_and_shipping">
            <div class="row">
               <div class="col-md-12">
                  <div class="row">
                     <div class="col-md-6">
                        <h4 class="no-mtop"><?php echo _l('billing_address'); ?> <a href="#" class="pull-right billing-same-as-customer"><small class="font-medium-xs"><?php echo _l('customer_billing_same_as_profile'); ?></small></a></h4>
                        <hr />
                        <?php $value=( isset($client) ? $client->billing_street : ''); ?>
                        <?php echo render_textarea( 'billing_street', 'billing_street',$value); ?>
                        <?php $value=( isset($client) ? $client->billing_city : ''); ?>
                        <?php echo render_input( 'billing_city', 'billing_city',$value); ?>
                        <?php $value=( isset($client) ? $client->billing_state : ''); ?>
                        <?php echo render_input( 'billing_state', 'billing_state',$value); ?>
                        <?php $value=( isset($client) ? $client->billing_zip : ''); ?>
                        <?php echo render_input( 'billing_zip', 'billing_zip',$value); ?>
                        <?php $selected=( isset($client) ? $client->billing_country : '' ); ?>
                        <?php echo render_select( 'billing_country',$countries,array( 'country_id',array( 'short_name')), 'billing_country',$selected,array('data-none-selected-text'=>_l('dropdown_non_selected_tex'))); ?>
                     </div>
                     <div class="col-md-6">
                        <h4 class="no-mtop">
                           <i class="fa fa-question-circle" data-toggle="tooltip" data-title="<?php echo _l('customer_shipping_address_notice'); ?>"></i>
                           <?php echo _l('shipping_address'); ?> <a href="#" class="pull-right customer-copy-billing-address"><small class="font-medium-xs"><?php echo _l('customer_billing_copy'); ?></small></a>
                        </h4>
                        <hr />
                        <?php $value=( isset($client) ? $client->shipping_street : ''); ?>
                        <?php echo render_textarea( 'shipping_street', 'shipping_street',$value); ?>
                        <?php $value=( isset($client) ? $client->shipping_city : ''); ?>
                        <?php echo render_input( 'shipping_city', 'shipping_city',$value); ?>
                        <?php $value=( isset($client) ? $client->shipping_state : ''); ?>
                        <?php echo render_input( 'shipping_state', 'shipping_state',$value); ?>
                        <?php $value=( isset($client) ? $client->shipping_zip : ''); ?>
                        <?php echo render_input( 'shipping_zip', 'shipping_zip',$value); ?>
                        <?php $selected=( isset($client) ? $client->shipping_country : '' ); ?>
                        <?php echo render_select( 'shipping_country',$countries,array( 'country_id',array( 'short_name')), 'shipping_country',$selected,array('data-none-selected-text'=>_l('dropdown_non_selected_tex'))); ?>
                     </div>
                     <?php if(isset($client) &&
                        (total_rows(db_prefix().'invoices',array('clientid'=>$client->userid)) > 0 || total_rows(db_prefix().'estimates',array('clientid'=>$client->userid)) > 0 || total_rows(db_prefix().'creditnotes',array('clientid'=>$client->userid)) > 0)){ ?>
                     <div class="col-md-12">
                        <div class="alert alert-warning">
                           <div class="checkbox checkbox-default">
                              <input type="checkbox" name="update_all_other_transactions" id="update_all_other_transactions">
                              <label for="update_all_other_transactions">
                              <?php echo _l('customer_update_address_info_on_invoices'); ?><br />
                              </label>
                           </div>
                           <b><?php echo _l('customer_update_address_info_on_invoices_help'); ?></b>
                           <div class="checkbox checkbox-default">
                              <input type="checkbox" name="update_credit_notes" id="update_credit_notes">
                              <label for="update_credit_notes">
                              <?php echo _l('customer_profile_update_credit_notes'); ?><br />
                              </label>
                           </div>
                        </div>
                     </div>
                     <?php } ?>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <?php echo form_close(); ?>
</div>
<?php if(isset($client)){ ?>
<?php if (has_permission('customers', '', 'create') || has_permission('customers', '', 'edit')) { ?>
<div class="modal fade" id="customer_admins_assign" tabindex="-1" role="dialog">
   <div class="modal-dialog">
      <?php echo form_open(admin_url('clients/assign_admins/'.$client->userid)); ?>
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><?php echo _l('assign_admin'); ?></h4>
         </div>
         <div class="modal-body">
            <?php
               $selected = array();
               foreach($customer_admins as $c_admin){
                  array_push($selected,$c_admin['staff_id']);
               }
               echo render_select('customer_admins[]',$staff,array('staffid',array('firstname','lastname')),'',$selected,array('multiple'=>true),array(),'','',false); ?>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _l('close'); ?></button>
            <button type="submit" class="btn btn-info"><?php echo _l('submit'); ?></button>
         </div>
      </div>
      <!-- /.modal-content -->
      <?php echo form_close(); ?>
   </div>
   <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php } ?>
<?php } ?>
<?php $this->load->view('admin/clients/client_group'); ?>
