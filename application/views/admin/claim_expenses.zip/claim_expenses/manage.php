<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<?php init_head(); ?>
<style>
    .table-daily_report          { overflow: auto;max-height: 55vh;width:100%;position:relative;top: 0px; }
.table-daily_report thead th { position: sticky; top: 0; z-index: 1; }
.table-daily_report tbody th { position: sticky; left: 0; }


table  { border-collapse: collapse; width: 100%; }
th, td { padding: 1px 5px !important; white-space: nowrap; border:1px solid !important;font-size:11px; line-height:1.42857143!important;vertical-align: middle !important;}
th     { background: #50607b;
    color: #fff !important; }
</style>
<div id="wrapper">
   <div class="content">
      <div class="row">
         <div class="col-md-12">
            
            <div class="panel_s">
               <div class="panel-body">
                  
                    
      <!--</div>-->
         <div class="row">
                       <div class="col-md-2">
                            <?php $cur_date = date('d/m/Y'); 
                            $first_date = "01/".date('m')."/".date('Y');
                            ?>
                          <?php echo render_date_input('from_date','from_date',$first_date); ?>
                        </div>
                        <div class="col-md-2">
                          <?php echo render_date_input('to_date','to_date',$cur_date); ?>
                        </div>
                        <div class="col-md-3">
                            <lebal class="control-label">Staff</lebal>
                           <select name="staff_id" id="staff_id" class="selectpicker form-control" data-none-selected-text="Non Selected" data-live-search="true">
                                <option></option>
                            <?php foreach($staff_details as $value){?>
                              <option value="<?= $value['staffid']; ?>" ><?= $value['firstname'].' '.$value['lastname']; ?></option>  
                           <?php  } ?>
                              
                              
                          </select>
                        </div>
                        <button class="btn btn-info pull-left mleft5 search_data" style="margin-top: 19px;" id="search_data">Show</button>
     
            &nbsp;<a class="btn btn-default buttons-excel buttons-html5"  style="margin-top: 19px;"  tabindex="0" aria-controls="table-daily_report" href="#" id="caexcel"><span>Export to excel</span></a>
            <a class="btn btn-default" href="javascript:void(0);"  style="margin-top: 19px;"  onclick="printPage();">Print</a>
           
                  </div>
                  <div class="clearfix mtop20"></div>
                   <input type="text" id="myInput1" onkeyup="myFunction2()" placeholder="Search for names.." title="Type in a name" style="float: right;">
            <div class="table-daily_report tableFixHead2">
             
              
            </div>
             <span id="searchh2" style="display:none;">
                                Loading.....
                            </span>
                </div>
    </div>
    <?php
    /*$table_data = [];

    $table_data = array_merge($table_data, array(
        'HSN Code',
        "Description",
      "Date",
      
      ));

    render_datatable($table_data,'hsn-table');*/
    ?>
  </div>
</div>
</div>
</div>

<?php init_tail(); ?>
<script>
window.onload = function() {
//   yourFunction(param1, param2);
$.ajax({
      url:"<?php echo admin_url(); ?>Claim_expenses/onload_data",
      dataType:"json",
      method:"POST",
    //   data:{from_date:from_date, to_date:to_date, staff_id:staff_id},
      beforeSend: function () {
               
        $('#searchh2').css('display','block');
        $('.table-daily_report tbody').css('display','none');
        
     },
      complete: function () {
                            
        $('.table-daily_report tbody').css('display','');
        $('#searchh2').css('display','none');
       
     },
      success:function(data){
        //   console.log(data);
        //  data1 = JSON.parse(data);
        //   var msg = "Rate Master State: "+data.state.state_name +" Distributor " +data.distributor.name;
	   // $(".report_for").text(msg);
        //   condole.log(data1.html);return false; 
          $('.tableFixHead2').append(data.html);
        // $('tbody').html(data);
        $('.passed_amount_per_day').on('keydown',  function(e) {
               
                if (e.key === "Tab") {
                    var id = $(this).attr("data-id"); 
                    var value = $(this).val(); 
                    // console.log(id+"   test  "+value);
                     $.ajax({
                  url:"<?php echo admin_url(); ?>Claim_expenses/passed_amount_per_day",
                  dataType:"json",
                  method:"POST",
                  data:{id:id, value:value},
               
                  success:function(data){
                   
                  }
                }); 
                }
            });
            $('.approve_km_by_hr').on('keydown',  function(e) {
                   
                    if (e.key === "Tab") {
                        var id = $(this).attr("data-id"); 
                        var value = $(this).val(); 
                        // console.log(id+"   test  "+value);
                         $.ajax({
                      url:"<?php echo admin_url(); ?>Claim_expenses/approve_km_by_hr",
                      dataType:"json",
                      method:"POST",
                      data:{id:id, value:value},
                   
                      success:function(data){
                       
                      }
                    });
                    }
                });
                        $('.remark').on('keydown',  function(e) {
                            if (e.key === "Tab") {
                                var id = $(this).attr("data-id"); 
                                var value = $(this).val(); 
                                // console.log(id+"   test  "+value);
                                 $.ajax({
                              url:"<?php echo admin_url(); ?>Claim_expenses/update_remark",
                              dataType:"json",
                              method:"POST",
                              data:{id:id, value:value},
                           
                              success:function(data){
                               
                              }
                            });
                            }
                        
                        });
      }
    });


};
    $(document).ready(function(){
    var maxEndDate = new Date('Y/m/d');
    var fin_y = "<?php echo $this->session->userdata('finacial_year')?>";
    
    var year = "20"+fin_y;
    
    
    var cur_y = new Date().getFullYear().toString().substr(-2);
    if(cur_y > fin_y){
        var year2 = parseInt(fin_y) + parseInt(1);
        var year2_new = "20"+year2;
        
        var e_dat = new Date(year2_new+'/03/31');
        var maxEndDate_new = e_dat;
    }else{
         var maxEndDate_new = maxEndDate;
    }
    
    var minStartDate = new Date(year, 03);
   /* console.log(minStartDate);
    console.log(maxEndDate_new);*/
    
    $('#from_date').datetimepicker({
        format: 'd/m/Y',
        minDate: minStartDate,
        maxDate: maxEndDate_new,
        timepicker: false
    });
    $('#to_date').datetimepicker({
        format: 'd/m/Y',
        minDate: minStartDate,
        maxDate: maxEndDate_new,
        timepicker: false
    });
    
    
    });
    
</script>
<script>
function load_data(from_date,to_date,staff_id)
  {
    $.ajax({
      url:"<?php echo admin_url(); ?>Claim_expenses/load_data",
      dataType:"json",
      method:"POST",
      data:{from_date:from_date, to_date:to_date, staff_id:staff_id},
      beforeSend: function () {
           $('.tableFixHead2 table').remove();
               $('#searchh22').css('display','none');
        $('#searchh2').css('display','block');
        $('.table-daily_report tbody').css('display','none');
        
     },
      complete: function () {
         
                            
        $('.table-daily_report tbody').css('display','');
        $('#searchh2').css('display','none');
         
     },
      success:function(data){
        //   console.log(data);
        //  data1 = JSON.parse(data);
        //   var msg = "Rate Master State: "+data.state.state_name +" Distributor " +data.distributor.name;
	   // $(".report_for").text(msg);
        //   condole.log(data1.html);return false; 
          $('.tableFixHead2').append(data.html);
            $('.passed_amount_per_day').on('keydown',  function(e) {
               
                if (e.key === "Tab") {
                    var id = $(this).attr("data-id"); 
                    var value = $(this).val(); 
                    // console.log(id+"   test  "+value);
                     $.ajax({
                  url:"<?php echo admin_url(); ?>Claim_expenses/passed_amount_per_day",
                  dataType:"json",
                  method:"POST",
                  data:{id:id, value:value},
               
                  success:function(data){
                   
                  }
                }); 
                }
            });
            $('.approve_km_by_hr').on('keydown',  function(e) {
                   
                    if (e.key === "Tab") {
                        var id = $(this).attr("data-id"); 
                        var value = $(this).val(); 
                        // console.log(id+"   test  "+value);
                         $.ajax({
                      url:"<?php echo admin_url(); ?>Claim_expenses/approve_km_by_hr",
                      dataType:"json",
                      method:"POST",
                      data:{id:id, value:value},
                   
                      success:function(data){
                       
                      }
                    });
                    }
                });
                        $('.remark').on('keydown',  function(e) {
                            if (e.key === "Tab") {
                                var id = $(this).attr("data-id"); 
                                var value = $(this).val(); 
                                // console.log(id+"   test  "+value);
                                 $.ajax({
                              url:"<?php echo admin_url(); ?>Claim_expenses/update_remark",
                              dataType:"json",
                              method:"POST",
                              data:{id:id, value:value},
                           
                              success:function(data){
                               
                              }
                            });
                            }
                        
                        });
        // $('tbody').html(data);
      }
    });
  }
 $('#search_data').on('click',function(){
        var from_date = $("#from_date").val();
	    var to_date = $("#to_date").val();
	    var staff_id = $("#staff_id").val();
	  
	   
	   
        load_data(from_date,to_date,staff_id);
     
        
 });
$('.approve_km_by_hr').on('keydown',  function(e) {
   
    if (e.key === "Tab") {
        var id = $(this).attr("data-id"); 
        var value = $(this).val(); 
        // console.log(id+"   test  "+value);
         $.ajax({
      url:"<?php echo admin_url(); ?>Claim_expenses/approve_km_by_hr",
      dataType:"json",
      method:"POST",
      data:{id:id, value:value},
   
      success:function(data){
       
      }
    });
    }
});
$('.passed_amount_per_day').on('keydown',  function(e) {
   
    if (e.key === "Tab") {
        var id = $(this).attr("data-id"); 
        var value = $(this).val(); 
        // console.log(id+"   test  "+value);
         $.ajax({
      url:"<?php echo admin_url(); ?>Claim_expenses/passed_amount_per_day",
      dataType:"json",
      method:"POST",
      data:{id:id, value:value},
   
      success:function(data){
       
      }
    }); 
    }
});

        $('.remark').on('keydown',  function(e) {
    if (e.key === "Tab") {
        var id = $(this).attr("data-id"); 
        var value = $(this).val(); 
        // console.log(id+"   test  "+value);
         $.ajax({
      url:"<?php echo admin_url(); ?>Claim_expenses/update_remark",
      dataType:"json",
      method:"POST",
      data:{id:id, value:value},
   
      success:function(data){
       
      }
    });
    }

});

</script>
 <script src="<?= base_url() ?>public/plugins/jquery.table2excel.js"></script>
 <script>
     function myFunction2() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput1");
  filter = input.value.toUpperCase();
  table = document.getElementById("table-daily_report");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
 </script>
<script>
$("#caexcel").click(function(){
     
  $(".tableFixHead2").table2excel({
    // exclude CSS class
    exclude: ".noExl",
    action: newexportaction,
    name: "Worksheet Name",
    filename: "Cliam Expenses", //do not include extension
    fileext: ".xls" // file extension
  }); 
 
});

function newexportaction(e, dt, button, config) {
         var self = this;
         var oldStart = dt.settings()[0]._iDisplayStart;
         dt.one('preXhr', function (e, s, data) {
             // Just this once, load all data from the server...
             data.start = 0;
             data.length = 2147483647;
             dt.one('preDraw', function (e, settings) {
                 // Call the original action function
                 if (button[0].className.indexOf('buttons-copy') >= 0) {
                     $.fn.dataTable.ext.buttons.copyHtml5.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-excel') >= 0) {
                     $.fn.dataTable.ext.buttons.excelHtml5.available(dt, config) ?
                         $.fn.dataTable.ext.buttons.excelHtml5.action.call(self, e, dt, button, config) :
                         $.fn.dataTable.ext.buttons.excelFlash.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-csv') >= 0) {
                     $.fn.dataTable.ext.buttons.csvHtml5.available(dt, config) ?
                         $.fn.dataTable.ext.buttons.csvHtml5.action.call(self, e, dt, button, config) :
                         $.fn.dataTable.ext.buttons.csvFlash.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-pdf') >= 0) {
                     $.fn.dataTable.ext.buttons.pdfHtml5.available(dt, config) ?
                         $.fn.dataTable.ext.buttons.pdfHtml5.action.call(self, e, dt, button, config) :
                         $.fn.dataTable.ext.buttons.pdfFlash.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-print') >= 0) {
                     $.fn.dataTable.ext.buttons.print.action(e, dt, button, config);
                 }
                 dt.one('preXhr', function (e, s, data) {
                     // DataTables thinks the first item displayed is index 0, but we're not drawing that.
                     // Set the property to what it was before exporting.
                     settings._iDisplayStart = oldStart;
                     data.start = oldStart;
                  
                 });
                 // Reload the grid with the original page. Otherwise, API functions like table.cell(this) don't work properly.
                 setTimeout(dt.ajax.reload, 0);
                 // Prevent rendering of the full data to the DOM
                 return false;
             });
         });
         // Requery the server with the new one-time export settings
         dt.ajax.reload();
     }
</script>
<script type="text/javascript">
 function printPage(){
        
       
	    var stylesheet = '<style type = "text/css"> th, td { padding: 5px 5px;} </style>';
    var tableData = '<table  border="1" cellpadding="0" cellspacing="0" width="100%" class="tree table table-striped table-bordered" style="font-size:12px;">'+document.getElementsByTagName('table')[0].innerHTML+'</table>';
        var heading_data = '<table  border="1" cellpadding="0" cellspacing="0" width="100%" class="tree table table-striped table-bordered" style="font-size:12px;"><tbody><tr><td style="text-align:center;" colspan="3"><?php echo $company_detail->company_name; ?></td></tr><tr><td style="text-align:center;" colspan="3"><?php echo $company_detail->address; ?></td></tr>';
         heading_data += '<tr>';
         heading_data += '<td style="text-align:center;"colspan="3">Claim Expenses </td>';
         heading_data += '</tr>';
         heading_data += '</tbody></table>';
        var print_data = stylesheet+heading_data+tableData
   newWin= window.open("");
   newWin.document.write(print_data);
   newWin.print();
   newWin.close();
    };
 </script>
   <script>
    
      function sortTable(f,n){
	var rows = $('#table-daily_report tbody  tr').get();

	rows.sort(function(a, b) {

		var A = getVal(a);
		var B = getVal(b);

		if(A < B) {
			return -1*f;
		}
		if(A > B) {
			return 1*f;
		}
		return 0;
	});

	function getVal(elm){
		var v = $(elm).children('td').eq(n).text().toUpperCase();
		if($.isNumeric(v)){
			v = parseInt(v,10);
		}
		return v;
	}

	$.each(rows, function(index, row) {
		$('#table-daily_report').children('tbody').append(row);
	});
    }
    var f_sl = 1;
    var f_nm = 1;
    
    function dercment_increment(){
    // $("#sl").click(function(){
        // alert('test')
      if ( $('.up').css('display') == 'none')
    {
         $(".up_starting").hide()
      $(".up").show()
      $(".down").hide()
    }else{
         $(".up_starting").hide()
        $(".up").hide()
      $(".down").show()
    }
        f_sl *= -1;
        var n = $(this).prevAll().length;
        sortTable(f_sl,n);
    };
    $("#nm").click(function(){
        f_nm *= -1;
        var n = $(this).prevAll().length;
        sortTable(f_nm,n);
    });
 </script>
 <style type="text/css">
   body{
    overflow: hidden;
   }
 </style>
</body>
</html>
