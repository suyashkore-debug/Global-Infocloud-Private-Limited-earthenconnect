<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<style>
	@import url("https://code.highcharts.com/css/highcharts.css");
	
	.highcharts-pie-series .highcharts-point {
    stroke: #ede;
    stroke-width: 2px;
	}
	
	.highcharts-pie-series .highcharts-data-label-connector {
    stroke: silver;
    stroke-dasharray: 2, 2;
    stroke-width: 2px;
	}
	
	.highcharts-figure,
	.highcharts-data-table table {
    min-width: 320px;
    max-width: 600px;
    margin: 1em auto;
	}
	
	.highcharts-data-table table {
    font-family: Verdana, sans-serif;
    border-collapse: collapse;
    border: 1px solid #ebebeb;
    margin: 10px auto;
    text-align: center;
    width: 100%;
    max-width: 500px;
	}
	
	.highcharts-data-table caption {
    padding: 1em 0;
    font-size: 1.2em;
    color: #555;
	}
	
	.highcharts-data-table th {
    font-weight: 600;
    padding: 0.5em;
	}
	
	.highcharts-data-table td,
	.highcharts-data-table th,
	.highcharts-data-table caption {
    padding: 0.5em;
	}
	
	.highcharts-data-table thead tr,
	.highcharts-data-table tr:nth-child(even) {
    background: #f8f8f8;
	}
	
	.highcharts-data-table tr:hover {
    background: #f1f7ff;
	}
	
	.highcharts-description {
    margin: 0.3rem 10px;
	}
	.highcharts-credits {
    display: none;
	}
	
	.table-table_staff tbody{
	display: block;
	max-height: 450px;
	overflow-y: scroll;
	width: calc(100% - -8.9em);
	}
	.table-table_staff thead, .table-table_staff tbody tr{
	display: table;
	table-layout: fixed;
	width: 100%;
	
	}
	.table-table_staff thead{
	width: calc(100% - -5.9em);
	}
	.table-table_staff thead{
	position: relative;
	}
	.table-table_staff thead th:last-child:after{
	content: ' ';
	position: absolute;
	background-color: #337ab7;
	width: 1.3em;
	height: 38px;
	right: -1.3em;
	top: 0;
	border-bottom: 2px solid #ddd;
	}
	
	/*.staff_name{*/
	/*width:21%;*/
	/*}*/
	.table-table_staff th td{padding: 32px -20px 12px 14px;
	}
	
	.fontsize{
	font-size:13px;
	}
	.fontsize2{
	font-size:15px;
	}
	
    thead tr:nth-child(2) th {
	top: 20px; /* Offset for the second row to appear below the first */
    }
	
	
	
	
</style>

<style>
    .table-daily_report          { overflow: auto;max-height: 55vh;width:100%;position:relative;top: 0px; }
	.table-daily_report thead th { position: sticky; top: 0; z-index: 1; }
	.table-daily_report tbody th { position: sticky; left: 0; }
	
	
	table  { border-collapse: collapse; width: 100%; }
	th, td { padding: 0px 5px !important; white-space: nowrap; border:1px solid !important;font-size:11px; line-height:1.42857143!important;vertical-align: middle !important;}
	th     { background: #50607b;
    color: #fff !important; }
</style>
<div id="wrapper">
	<div class="content" >
		<div class="widget relative" id="widget-<?php echo create_widget_id(); ?>" data-name="<?php echo _l('quick_stats'); ?>">
			
			<div class="row" >  
				<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
					<div class="top_stats_wrapper">
						<?php
							
							$ItemPercentage = ($ItemCount->TotalItem > 0 ? number_format(($ItemCount->ActiveItem * 100) / $ItemCount->TotalItem,2) : 0);
							
							
						?>
						<p class="text-uppercase mtop5"><i class="hidden-sm fa fa-balance-scale"></i> <?php echo _l('Total SKU (Active / All)'); ?>
							<span class="pull-right"><?php echo $ItemCount->ActiveItem; ?> / <?php echo $ItemCount->TotalItem; ?></span>
						</p>
						<div class="clearfix"></div>
						<div class="progress no-margin progress-bar-mini">
							<div class="progress-bar progress-bar-danger no-percent-text not-dynamic" role="progressbar" aria-valuenow="<?php echo $ItemPercentage; ?>" aria-valuemin="0" aria-valuemax="100" style="width: 0%" data-percent="<?php echo $ItemPercentage; ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 <?php echo $initial_column; ?>">
					<div class="top_stats_wrapper">
						<?php
							$percent_total_customer = ($CustomerCount->TotalCustomer > 0 ? number_format(($CustomerCount->ActiveCustomer * 100) / $CustomerCount->TotalCustomer,2) : 0);
						?>
						<p class="text-uppercase mtop5"><i class="hidden-sm fa fa-tty"></i> <?php echo _l('Total Party (Active / All'); ?>
							<span class="pull-right"><?php echo $CustomerCount->ActiveCustomer; ?> / <?php echo $CustomerCount->TotalCustomer; ?></span>
						</p>
						<div class="clearfix"></div>
						<div class="progress no-margin progress-bar-mini">
							<div class="progress-bar progress-bar-success no-percent-text not-dynamic" role="progressbar" aria-valuenow="<?php echo $percent_total_customer; ?>" aria-valuemin="0" aria-valuemax="100" style="width: 0%" data-percent="<?php echo $percent_total_customer; ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 <?php echo $initial_column; ?>">
					<div class="top_stats_wrapper">
						<?php
							
							$TopSaleReturn = ($TopItem->TotalSale > 0 ? number_format(($TopItem->TotalReturn * 100) / $TopItem->TotalSale,2) : 0);
							
							
						?>
						<p class="text-uppercase mtop5"><i class="hidden-sm fa fa-cubes"></i> <?php echo _l('Bestseller of month (Sale return/Sale)'); ?>
							<span class="pull-right"><?php echo $TopItem->TotalReturn; ?> / <?php echo $TopItem->TotalSale; ?></span>
						</p>
						<div class="clearfix"></div>
						<div class="progress no-margin progress-bar-mini">
							<div class="progress-bar progress-bar-warning no-percent-text not-dynamic" role="progressbar" aria-valuenow="<?php echo $TopSaleReturn; ?>" aria-valuemin="0" aria-valuemax="100" style="width: 0%" data-percent="<?php echo $TopSaleReturn; ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 <?php echo $initial_column; ?>">
					<div class="top_stats_wrapper">
						<?php
							
							$AllSaleReturn = ($AllItemSaleReturn->TotalSale > 0 ? number_format(($AllItemSaleReturn->TotalReturn * 100) / $AllItemSaleReturn->TotalSale,2) : 0);
						?>
						<p class="text-uppercase mtop5"><i class="hidden-sm fa fa-tasks"></i> <?php echo _l('Monthly Sale (Sale return/Sale)'); ?>
							<span class="pull-right"><?php echo $AllItemSaleReturn->TotalReturn; ?> / <?php echo $AllItemSaleReturn->TotalSale; ?></span>
						</p>
						<div class="clearfix"></div>
						<div class="progress no-margin progress-bar-mini">
							<div class="progress-bar progress-bar-dark no-percent-text not-dynamic" role="progressbar" aria-valuenow="<?php echo $AllSaleReturn; ?>" aria-valuemin="0" aria-valuemax="100" style="width: 0%" data-percent="<?php echo $AllSaleReturn; ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
					<div class="top_stats_wrapper">
						
						<p class="text-uppercase mtop5"><i class="hidden-sm fa fa-tasks"></i> <?php echo _l('Total Monthly GST'); ?>
							<span class="pull-right"> <?php echo $AllItemGST->TotalGST; ?></span>
						</p>
						<div class="clearfix"></div>
						<div class="progress no-margin progress-bar-mini">
							<div class="progress-bar progress-bar-dark no-percent-text not-dynamic" role="progressbar" aria-valuenow="<?php echo 100; ?>" aria-valuemin="0" aria-valuemax="100" style="width: 0%" data-percent="<?php echo 100; ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
					<div class="top_stats_wrapper">
						<p class="text-uppercase mtop5"><i class="hidden-sm fa fa-tasks"></i> <?php echo _l('Average Order Amount'); ?>
							<span class="pull-right"> <?php echo number_format($AvgOrderAmt->AvgAmt,2); ?></span>
						</p>
						<div class="clearfix"></div>
						<div class="progress no-margin progress-bar-mini">
							<div class="progress-bar progress-bar-dark no-percent-text not-dynamic" role="progressbar" aria-valuenow="<?php echo 100; ?>" aria-valuemin="0" aria-valuemax="100" style="width: 0%" data-percent="<?php echo 100; ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
					<div class="top_stats_wrapper">
						
						<p class="text-uppercase mtop5"><i class="hidden-sm fa fa-tasks"></i> <?php echo _l('New Parties'); ?>
							<span class="pull-right"> <?php echo $NewParties->NewParty; ?></span>
						</p>
						<div class="clearfix"></div>
						<div class="progress no-margin progress-bar-mini">
							<div class="progress-bar progress-bar-dark no-percent-text not-dynamic" role="progressbar" aria-valuenow="<?php echo 100; ?>" aria-valuemin="0" aria-valuemax="100" style="width: 0%" data-percent="<?php echo 100; ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
					<div class="top_stats_wrapper">
						
						<p class="text-uppercase mtop5"><i class="hidden-sm fa fa-tasks"></i> <?php echo _l('Todays Sale'); ?>
							<span class="pull-right"> <?php echo $TodaysSale->TotalSale; ?></span>
						</p>
						<div class="clearfix"></div>
						<div class="progress no-margin progress-bar-mini">
							<div class="progress-bar progress-bar-dark no-percent-text not-dynamic" role="progressbar" aria-valuenow="<?php echo 100; ?>" aria-valuemin="0" aria-valuemax="100" style="width: 0%" data-percent="<?php echo 100; ?>">
							</div>
						</div>
					</div>
				</div>
			</div>
			
		</div>
		
		<!--First Section-->
		<div class="row">
			<div class="col-md-12">
				<div class="panel_s">
					<div class="panel-body">
						<div class="_buttons">
							<div class="row">  
								<div class="col-md-4">
									
									<div class="row">  
										<div class="col-md-6">
											<?php
												$fy = $this->session->userdata('finacial_year');
												$fy_new  = $fy + 1;
												$lastdate_date = '20'.$fy_new.'-03-31';
												$firstdate_date = '20'.$fy_new.'-04-01';
												$curr_date = date('Y-m-d');
												$curr_date_new    = new DateTime($curr_date);
												$last_date_yr = new DateTime($lastdate_date);
												if($last_date_yr < $curr_date_new){
													$to_date = '31/03/20'.$fy_new;
													$from_date = '01/03/20'.$fy_new;
													}else{
													$from_date = date('01/m/Y');
													$to_date = date('d/m/Y');
												}
											?>
											<?php 
												$current_date = date('d/m/Y');
												echo render_date_input('from_date','From Date',$from_date);          
											?>
										</div>
										<div class="col-md-6">
											<?php 
												echo render_date_input('to_date','To Date',$to_date);          
											?>
										</div>
										<div class="clearfix"></div>
										<div class="col-md-4">
											<div class="form-group" app-field-wrapper="ReportType">
												<label for="ReportType" class="form-label">Report Type</label>
												<select name="ReportType" id="ReportType" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
													<option value="Itemwise">Item Wise</option>
													<option value="Groupwise">Group Wise</option>
												</select>
											</div>
										</div>
										<div class="col-md-8" id="ItemDiv">
											<div class="form-group" app-field-wrapper="Items">
												<small class="req text-danger"></small>
												<label for="Items" class="form-label">Item</label>
												<select name="Items[]" multiple id="Items" class="selectpicker form-control" data-width="100%" data-none-selected-text="None selected" data-live-search="true">
													<?php
														foreach ($ItemList as $key => $value) {
														?>
														<option value="<?php echo $value['item_code'];?>"><?php echo $value['description'];?></option>
														<?php
														}
													?>
												</select>
											</div>
										</div>
										<div class="col-md-8" id="SubgroupDiv" style="display:none;">
											<div class="form-group" app-field-wrapper="SubGroup">
												<small class="req text-danger"></small>
												<label for="SubGroup" class="form-label">SubGroup</label>
												<select name="SubGroup[]" multiple id="SubGroup" class="selectpicker form-control" data-width="100%" data-none-selected-text="None selected" data-live-search="true">
													<?php
														foreach ($SubGroup as $key => $value) {
														?>
														<option value="<?php echo $value['id'];?>"><?php echo $value['name'];?></option>
														<?php
														}
													?>
												</select>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group" app-field-wrapper="ItemCount">
												<label for="ItemCount" class="control-label">Max Count</label>
												<input type="text" id="ItemCount" onkeypress="return isNumber(event)" name="ItemCount" class="form-control" value="5">
											</div>
										</div>
										<div class="col-md-8">
											<div class="form-group" app-field-wrapper="state">
												<small class="req text-danger"></small>
												<label for="state" class="form-label">State</label>
												<select name="state" id="state" class="selectpicker form-control" data-width="100%" data-none-selected-text="None selected" data-live-search="true">
													<option value="">None selected</option>
													<?php
														foreach ($state as $key => $value) {
														?>
														<option value="<?php echo $value['short_name'];?>"><?php echo $value['state_name'];?></option>
														<?php
														}
													?>
												</select>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group" app-field-wrapper="SubGroup">
												<label for="ChartType" class="form-label">Chart Type</label>
												<select name="ChartType" id="ChartType" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
													<option value="Bar">Bar Chart</option>
													<option value="Pie">Pie Chart</option>
												</select>
											</div>
										</div>
										<div class="col-md-8" style="margin-top:10px;">
											<br>
											
											<button class="btn btn-info pull-left mleft5 search_data" id="search_data"><?php echo _l('rate_filter'); ?></button> 
											&nbsp
											<a class="btn btn-default buttons-excel buttons-html5" href="#" id="caexcel"><span>Export</span></a>
										</div>
									</div>
									
								</div>
								
								<div class="col-md-8">
									
									<div class="row">  
										
										<figure class="highcharts-figure">
											<div id="container"></div>
										</figure>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
						
						<span id="searchh" style="display:none;">Loading.....</span>
						<span id="searchhExport" style="display:none;">please wait Exporting data...</span>
						
						
						<div class="row">
							<div class="col-md-12">
								<div class="table-daily_report tableFixHead2">
									<table class="tree table table-striped table-bordered table-daily_report tableFixHead2" id="table-daily_report" width="100%">
									</table>   
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!--Second Table Start-->
		
		<div class="row">
			<div class="col-md-12">
				<div class="panel_s">
					<div class="panel-body">
						<div class="_buttons">
							<div class="row">  
								<div class="col-md-2">
									
									<?php 
										echo render_date_input('from_date2','From Date',$from_date);          
									?>
								</div>
								<div class="col-md-2">
									<?php 
										echo render_date_input('to_date2','To Date',$to_date);          
									?>
								</div>
								<div class="col-md-2">
									<div class="form-group" app-field-wrapper="CustomerCount2">
										<label for="CustomerCount2" class="control-label">Customer Count</label>
										<input type="text" id="CustomerCount2" onkeypress="return isNumber(event)" name="CustomerCount2" class="form-control" value="5">
									</div>
								</div>
								<div class="col-md-2">
									
									<div class="form-group" app-field-wrapper="state2">
										<small class="req text-danger"></small>
										<label for="state2" class="form-label">State</label>
										<select name="state2" id="state2" class="selectpicker form-control" data-width="100%" data-none-selected-text="None selected" data-live-search="true">
											<option value="">None selected</option>
											<?php
												foreach ($state as $key => $value) {
												?>
												<option value="<?php echo $value['short_name'];?>"><?php echo $value['state_name'];?></option>
												<?php
												}
											?>
										</select>
									</div>
								</div>
								<div class="col-md-2">
									<label class="control-label">Chart Type</label>
									<select name="ChartType2" id="ChartType2" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
										<option value="Bar">Bar Chart</option>
										<option value="Pie">Pie Chart</option>
									</select>
								</div>
								
								<div class="col-md-2" style="margin-top:10px;">
									<br>
									
									<button class="btn btn-info pull-left mleft5 search_data2" id="search_data2"><?php echo _l('rate_filter'); ?></button>&nbsp
									<a class="btn btn-default buttons-excel buttons-html5" href="#" id="caexcel2"><span>Export</span></a>
								</div>
							</div>
							
						</div>
						<div class="clearfix"></div>
						
						<span id="searchh2" style="display:none;">Loading.....</span>
						<span id="searchhExport2" style="display:none;">please wait Exporting data...</span>
						
						
						<div class="row">  
							
							<figure class="highcharts-figure">
								<div id="container2"></div>
							</figure>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="table-daily_report tableFixHead2">
									<table class="tree table table-striped table-bordered table-daily_report tableFixHead2" id="table-daily_report2" width="100%">
									</table>   
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Third Table Start -->
		
		<div class="row">
			<div class="col-md-12">
				<div class="panel_s">
					<div class="panel-body">
						<div class="_buttons">
							<div class="row">  
								<div class="col-md-2">
									
									<?php 
										echo render_date_input('from_date3','From Date',$from_date);          
									?>
								</div>
								<div class="col-md-2">
									<?php 
										echo render_date_input('to_date3','To Date',$to_date);          
									?>
								</div>
								
								<div class="col-md-2">
									<div class="form-group" app-field-wrapper="SubGroup3">
										<small class="req text-danger"></small>
										<label for="SubGroup3" class="form-label">SubGroup</label>
										<select name="SubGroup3[]" multiple id="SubGroup3" class="selectpicker form-control" data-width="100%" data-none-selected-text="None selected" data-live-search="true">
											<?php
												foreach ($SubGroup as $key => $value) {
												?>
												<option value="<?php echo $value['id'];?>"><?php echo $value['name'];?></option>
												<?php
												}
											?>
										</select>
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group" app-field-wrapper="MaxCount">
										<label for="MaxCount" class="control-label">Max Count</label>
										<input type="text" id="MaxCount" onkeypress="return isNumber(event)" name="MaxCount" class="form-control" value="5">
									</div>
								</div>
								<div class="col-md-2">
									<label class="control-label">Sort</label>
									<select name="Sort" id="Sort" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
										<option value="Highest">Highest</option>
										<option value="Lowest">Lowest</option>                                               
									</select>
								</div>
								<div class="col-md-2">
									<label class="control-label">Chart Type</label>
									<select name="ChartType3" id="ChartType3" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
										<option value="Bar">Bar Chart</option>
										<option value="Pie">Pie Chart</option>
									</select>
								</div>
								
								<div class="col-md-2" style="margin-top:10px;">
									<br>
									
									<button class="btn btn-info pull-left mleft5 search_data3" id="search_data3"><?php echo _l('rate_filter'); ?></button>&nbsp
									<!--<a class="btn btn-default buttons-excel buttons-html5" href="#" id="caexcel3"><span>Export</span></a>-->
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
						
						<span id="searchh3" style="display:none;">Loading.....</span>
						<span id="searchhExport3" style="display:none;">please wait Exporting data...</span>
						
						
						<div class="row">  
							
							<figure class="highcharts-figure">
								<div id="container3"></div>
							</figure>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="table-daily_report tableFixHead2">
									<table class="tree table table-striped table-bordered table-daily_report tableFixHead2" id="table-daily_report3" width="100%">
									</table>   
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Fourth Table Start -->
		
		<div class="row">
			<div class="col-md-12">
				<div class="panel_s">
					<div class="panel-body">
						<div class="_buttons">
							<div class="row">  
								<div class="col-md-2">
									
									<?php 
										echo render_date_input('from_date4','From Date',$from_date);          
									?>
								</div>
								<div class="col-md-2">
									<?php 
										echo render_date_input('to_date4','To Date',$to_date);          
									?>
								</div>
								
								<div class="col-md-2">
									<div class="form-group" app-field-wrapper="SubGroup4">
										<small class="req text-danger"></small>
										<label for="SubGroup4" class="form-label">SubGroup</label>
										<select name="SubGroup4[]" multiple id="SubGroup4" class="selectpicker form-control" data-width="100%" data-none-selected-text="None selected" data-live-search="true">
											<?php
												foreach ($SubGroup as $key => $value) {
												?>
												<option value="<?php echo $value['id'];?>"><?php echo $value['name'];?></option>
												<?php
												}
											?>
										</select>
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group" app-field-wrapper="MaxCount4">
										<label for="MaxCount4" class="control-label">Max Count</label>
										<input type="text" id="MaxCount4" onkeypress="return isNumber(event)" name="MaxCount4" class="form-control" value="5">
									</div>
								</div>
								<div class="col-md-2">
									<label class="control-label">Report Type</label>
									<select name="ReportType4" id="ReportType4" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
										<option value="fresh">Fresh Return</option>
										<option value="damage">Damage Return</option>
									</select>
								</div>
								<div class="col-md-2">
									<label class="control-label">Report In</label>
									<select name="ReportIn4" id="ReportIn4" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
										<option value="amount">Amount</option>
										<option value="qty">Quantity</option>
									</select>
								</div>
								<div class="clearfix"></div>
								<div class="col-md-2">
									<label class="control-label">Sort</label>
									<select name="Sort4" id="Sort4" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
										<option value="Highest">Highest</option>
										<option value="Lowest">Lowest</option>                                               
									</select>
								</div>
								
								<div class="col-md-2">
									<label class="control-label">Chart Type</label>
									<select name="ChartType4" id="ChartType4" class="selectpicker" data-none-selected-text="Non selected" data-width="100%" data-live-search="true" tabindex="-98">
										<option value="Bar">Bar Chart</option>
										<option value="Pie">Pie Chart</option>
									</select>
								</div>
								<div class="col-md-2" style="margin-top:10px;">
									<br>
									
									<button class="btn btn-info pull-left mleft5 search_data4" id="search_data4"><?php echo _l('rate_filter'); ?></button>&nbsp
									<!--<a class="btn btn-default buttons-excel buttons-html5" href="#" id="caexcel4"><span>Export</span></a>-->
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
						
						<span id="searchh4" style="display:none;">Loading.....</span>
						<span id="searchhExport4" style="display:none;">please wait Exporting data...</span>
						
						
						<div class="row">  
							
							<figure class="highcharts-figure">
								<div id="container4"></div>
							</figure>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="table-daily_report tableFixHead2">
									<table class="tree table table-striped table-bordered table-daily_report tableFixHead2" id="table-daily_report4" width="100%">
									</table>   
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</div>
</div>
<style>
    .table-daily_report { overflow: auto;max-height: 60vh;width:100%;position:relative;top: 0px; }
	.table-daily_report thead th { position: sticky; top: 0; z-index: 1; }
	.table-daily_report tbody th { position: sticky; left: 0; }
	
	/* Just common table stuff. Really. */
	.table-daily_report table  { border-collapse: collapse; width: 100%; }
	th, td { padding: 1px 5px !important; white-space: nowrap; border:1px solid !important;font-size:11px; line-height:1.42857143!important;vertical-align: middle !important;}
	.table-daily_report th     { background: #50607b;color: #fff !important; }
</style>


<?php init_tail(); ?>
<!--new update -->
<script src="https://code.highcharts.com/dashboards/datagrid.js"></script>
<script src="https://code.highcharts.com/dashboards/dashboards.js"></script>
<script src="https://code.highcharts.com/dashboards/modules/layout.js"></script>
<script>
    function myFunction2() 
    {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("myInput1");
        filter = input.value.toUpperCase();
        table = document.getElementById("table-daily_report");
		tr = table.getElementsByTagName("tr");
		for (i = 2; i < tr.length; i++) 
		{
			tr[i].style.display = "none"; 
			td = tr[i].getElementsByTagName("td"); 
			for (j = 0; j < td.length; j++) {
				if (td[j]) {
					txtValue = td[j].textContent || td[j].innerText;                
					if (txtValue.toUpperCase().indexOf(filter.toUpperCase()) > -1) {
						tr[i].style.display = "";  
						break; 
					}
				}
			}
		}
	}
	
	
	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode = 46 && charCode > 31 
		&& (charCode < 48 || charCode > 57)){
			return false;
		}
		return true;
	}
</script>
<script type="text/javascript" language="javascript" >
	
	
	$(document).ready(function(){
		$('#ReportType').on('change',function(){
			var ReportType = $(this).val();
			if(ReportType == "Itemwise"){
				$('#ItemDiv').show();
				$('#SubgroupDiv').hide();
				}else{
				$('#SubgroupDiv').show();
				$('#ItemDiv').hide();
				
			}
			
			$('#SubGroup').val('');
			$('.selectpicker').selectpicker('refresh');
			$('#Items').val('');
			$('.selectpicker').selectpicker('refresh');
			$('#ItemCount').prop('disabled', false);
		});
		
		$('#Items,#SubGroup').on('change',function(){
			var SelectVal = $(this).val();
			// Check if the multiple select is empty
			if (SelectVal === null || SelectVal.length === 0) {
				$('#ItemCount').prop('disabled', false);
				} else {
				$('#ItemCount').prop('disabled', true);
			}
		});
		
		
		
		function load_data(from_date,to_date,ChartType,ItemCount,state,SubGroup,ReportType,Items)
		{
			$.ajax({
				url:"<?php echo admin_url(); ?>sale_reports/GetTopSellingItem",
				dataType:"JSON",
				method:"POST",
				data:{from_date:from_date, to_date:to_date,ChartType:ChartType,ItemCount:ItemCount,state:state,SubGroup:SubGroup,ReportType:ReportType,Items:Items},
				beforeSend: function () {
					
					$('#searchh').css('display','block');
					$('.table-daily_report tbody').css('display','none');
					
				},
				complete: function () {
					
					$('.table-daily_report tbody').css('display','');
					$('#searchh').css('display','none');
				},
				success:function(returndata){
					if(ChartType == "Pie"){
						Highcharts.chart('container', {
							chart: {
								styledMode: true,  
								height: 600, // Increase chart height
								spacing: [10, 100, 10, 10],
							},
							title: {
								text: '<b style="font-size:20px;">Top Selling Items</b>',
							},
							subtitle: {
								text: '<b style="font-size:15px;">From '+from_date+' To '+to_date+'</b>'
							},
							plotOptions: {
								pie: {
									size: '70%', // Force the pie to occupy 90% of the chart area
									dataLabels: {
										enabled: true,
										distance: 10, // Move data labels closer to the pie
										style: {
											fontSize: '14px'
										}
									}
								}
							},
							series: [{
								type: 'pie',
								allowPointSelect: true,
								keys: ['name', 'y', 'selected', 'sliced'],
								data: returndata.ChartData,
								showInLegend: true
							}],
							legend: {
								layout: 'horizontal', // Arrange legend items horizontally
								align: 'center', // Center-align the legend
								verticalAlign: 'bottom', // Place legend at the bottom
								itemWidth: 150, // Control the width of each legend item for better wrapping
								itemStyle: {
									fontSize: '14px'
								}
							},
						});
					}
					
					if(ChartType == "Bar"){
						Highcharts.chart('container', {
							chart: {
								type: 'column'
							},
							title: {
								text: 'Top Selling Items'
							},
							subtitle: {
								text: '<b>From '+from_date+' To '+to_date+'</b>'
							},
							xAxis: {
								type: 'category',
								labels: {
									autoRotation: [-45, -90],
									style: {
										fontSize: '11px',
										fontFamily: 'Verdana, sans-serif'
									}
								}
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Selling Qty (Unit)'
								}
							},
							legend: {
								enabled: false
							},
							tooltip: {
								pointFormat: 'QTY : <b>{point.y:.1f} </b>'
							},
							series: [{
								// colors: [ '#691af3',
								// '#6225ed', '#5b30e7', '#533be1', '#4c46db', '#4551d5', '#3e5ccf',
								// '#3667c9', '#2f72c3', '#277dbd', '#1f88b7', '#1693b1', '#0a9eaa',
								// '#03c69b',  '#00f194'
								// ],
								colorByPoint: true,
								groupPadding: 0,
								data: returndata.ChartData,
								dataLabels: {
									enabled: true,
									rotation: -90,
									color: '#FFFFFF',
									inside: true,
									verticalAlign: 'top',
									format: '{point.y:.1f}', // one decimal
									y: 10, // 10 pixels down from the top
									style: {
										fontSize: '13px',
										fontFamily: 'Verdana, sans-serif'
									}
								}
							}]
						});
					}
					
					$('#table-daily_report').html(returndata.TableData);
				}
			});
			
			
		}
		$('#search_data').on('click',function(){
			var from_date = $("#from_date").val();
			var to_date = $("#to_date").val();
			var ChartType = $("#ChartType").val();
			var ItemCount = $("#ItemCount").val();
			var SubGroup = $("#SubGroup").val();
			var state = $("#state").val();
			var ReportType = $("#ReportType").val();
			var Items = $("#Items").val();
			load_data(from_date,to_date,ChartType,ItemCount,state,SubGroup,ReportType,Items);
			
		});
		
		
		// Second Table Start
		function load_data2(from_date,to_date,ChartType,CustomerCount,state)
		{
			$.ajax({
				url:"<?php echo admin_url(); ?>sale_reports/GetTopSellingCustomer",
				dataType:"JSON",
				method:"POST",
				data:{from_date:from_date, to_date:to_date,ChartType:ChartType,CustomerCount:CustomerCount,state:state},
				beforeSend: function () {
					
					$('#searchh2').css('display','block');
					$('#table-daily_report2 tbody').css('display','none');
					
				},
				complete: function () {
					
					$('#table-daily_report2 tbody').css('display','');
					$('#searchh2').css('display','none');
				},
				success:function(returndata){
					if(ChartType == "Pie"){
						Highcharts.chart('container2', {
							chart: {
								styledMode: true,  
								height: 600, // Increase chart height
								spacing: [10, 100, 10, 10],
							},
							title: {
								text: '<b style="font-size:20px;">Top Customers</b>',
							},
							subtitle: {
								text: '<b style="font-size:15px;">From '+from_date+' To '+to_date+'</b>'
							},
							plotOptions: {
								pie: {
									size: '70%', // Force the pie to occupy 90% of the chart area
									dataLabels: {
										enabled: true,
										distance: 10, // Move data labels closer to the pie
										style: {
											fontSize: '14px'
										}
									}
								}
							},
							series: [{
								type: 'pie',
								allowPointSelect: true,
								keys: ['name', 'y', 'selected', 'sliced'],
								data: returndata.ChartData,
								showInLegend: true
							}],
							legend: {
								layout: 'horizontal', // Arrange legend items horizontally
								align: 'center', // Center-align the legend
								verticalAlign: 'bottom', // Place legend at the bottom
								itemWidth: 150, // Control the width of each legend item for better wrapping
								itemStyle: {
									fontSize: '14px'
								}
							},
						});
					}
					
					if(ChartType == "Bar"){
						Highcharts.chart('container2', {
							chart: {
								type: 'column'
							},
							title: {
								text: 'Top Customers'
							},
							subtitle: {
								text: '<b>From '+from_date+' To '+to_date+'</b>'
							},
							xAxis: {
								type: 'category',
								labels: {
									autoRotation: [-45, -90],
									style: {
										fontSize: '13px',
										fontFamily: 'Verdana, sans-serif'
									}
								}
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Amount'
								}
							},
							legend: {
								enabled: false
							},
							tooltip: {
								pointFormat: 'AMT : <b>{point.y:.1f} </b>'
							},
							series: [{
								name: 'Population',
								colors: [
								'#9b20d9', '#9215ac', '#861ec9', '#7a17e6', '#7010f9', '#691af3',
								'#6225ed', '#5b30e7', '#533be1', '#4c46db', '#4551d5', '#3e5ccf',
								'#3667c9', '#2f72c3', '#277dbd', '#1f88b7', '#1693b1', '#0a9eaa',
								'#03c69b',  '#00f194'
								],
								colorByPoint: true,
								groupPadding: 0,
								data: returndata.ChartData,
								dataLabels: {
									enabled: true,
									rotation: -90,
									color: '#FFFFFF',
									inside: true,
									verticalAlign: 'top',
									format: '{point.y:.1f}', // one decimal
									y: 10, // 10 pixels down from the top
									style: {
										fontSize: '13px',
										fontFamily: 'Verdana, sans-serif'
									}
								}
							}]
						});
					}
					
					$('#table-daily_report2').html(returndata.TableData);
				}
			});
			
			
		}
		$('#search_data2').on('click',function(){
			var from_date2 = $("#from_date2").val();
			var to_date2 = $("#to_date2").val();
			var ChartType2 = $("#ChartType2").val();
			var CustomerCount2 = $("#CustomerCount2").val();
			var state2 = $("#state2").val();
			load_data2(from_date2,to_date2,ChartType2,CustomerCount2,state2);
			
		});
		
		// Third Table Start
		function load_data3(from_date,to_date,SubGroup,MaxCount,Sort,ChartType)
		{
			$.ajax({
				url:"<?php echo admin_url(); ?>sale_reports/GetStockData",
				dataType:"JSON",
				method:"POST",
				data:{from_date:from_date, to_date:to_date,SubGroup:SubGroup,MaxCount:MaxCount,Sort:Sort,ChartType:ChartType},
				beforeSend: function () {
					$('#searchh3').css('display','block');
					$('#table-daily_report3 tbody').css('display','none');
					
				},
				complete: function () {
					
					$('#table-daily_report3 tbody').css('display','');
					$('#searchh3').css('display','none');
				},
				success:function(returndata){
					if(ChartType == "Pie"){
						Highcharts.chart('container3', {
							chart: {
								styledMode: true,  
								height: 600, // Increase chart height
								spacing: [10, 100, 10, 10],
							},
							title: {
								text: '<b style="font-size:20px;">'+Sort+' Stock</b>',
							},
							subtitle: {
								text: '<b style="font-size:15px;">From '+from_date+' To '+to_date+'</b>'
							},
							plotOptions: {
								pie: {
									size: '70%', // Force the pie to occupy 90% of the chart area
									dataLabels: {
										enabled: true,
										distance: 10, // Move data labels closer to the pie
										style: {
											fontSize: '14px'
										}
									}
								}
							},
							series: [{
								type: 'pie',
								allowPointSelect: true,
								keys: ['name', 'y', 'selected', 'sliced'],
								data: returndata.ChartData,
								showInLegend: true
							}],
							legend: {
								layout: 'horizontal', // Arrange legend items horizontally
								align: 'center', // Center-align the legend
								verticalAlign: 'bottom', // Place legend at the bottom
								itemWidth: 150, // Control the width of each legend item for better wrapping
								itemStyle: {
									fontSize: '14px'
								}
							},
						});
					}
					
					if(ChartType == "Bar"){
						Highcharts.chart('container3', {
							chart: {
								type: 'column'
							},
							title: {
								text: ''+Sort+' Stock'
							},
							subtitle: {
								text: '<b>From '+from_date+' To '+to_date+'</b>'
							},
							xAxis: {
								type: 'category',
								labels: {
									autoRotation: [-45, -90],
									style: {
										fontSize: '13px',
										fontFamily: 'Verdana, sans-serif'
									}
								}
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Amount'
								}
							},
							legend: {
								enabled: false
							},
							tooltip: {
								pointFormat: 'AMT : <b>{point.y:.1f} </b>'
							},
							series: [{
								name: 'Population',
								colors: [
								'#9b20d9', '#9215ac', '#861ec9', '#7a17e6', '#7010f9', '#691af3',
								'#6225ed', '#5b30e7', '#533be1', '#4c46db', '#4551d5', '#3e5ccf',
								'#3667c9', '#2f72c3', '#277dbd', '#1f88b7', '#1693b1', '#0a9eaa',
								'#03c69b',  '#00f194'
								],
								colorByPoint: true,
								groupPadding: 0,
								data: returndata.ChartData,
								dataLabels: {
									enabled: true,
									rotation: -90,
									color: '#FFFFFF',
									inside: true,
									verticalAlign: 'top',
									format: '{point.y:.1f}', // one decimal
									y: 10, // 10 pixels down from the top
									style: {
										fontSize: '13px',
										fontFamily: 'Verdana, sans-serif'
									}
								}
							}]
						});
					}
					
					// $('#table-daily_report3').html(returndata.TableData);
				}
			});
			
			
		}
		$('#search_data3').on('click',function(){
			var from_date3 = $("#from_date3").val();
			var to_date3 = $("#to_date3").val();
			var ChartType3 = $("#ChartType3").val();
			var MaxCount = $("#MaxCount").val();
			var Sort = $("#Sort").val();
			var SubGroup3 = $("#SubGroup3").val();
			load_data3(from_date3,to_date3,SubGroup3,MaxCount,Sort,ChartType3);
			
		});
		
		
		// Fourth Table Start
		function load_data4(from_date,to_date,SubGroup,MaxCount,ReportType,ReportIn,Sort,ChartType)
		{
			if(ReportType == "fresh"){
				chart_title = "Fresh Return";
				}else{
				chart_title = "Damage Return";
			}
			$.ajax({
				url:"<?php echo admin_url(); ?>sale_reports/GetSalesReturnReport",
				dataType:"JSON",
				method:"POST",
				data:{from_date:from_date, to_date:to_date,SubGroup:SubGroup,MaxCount:MaxCount,Sort:Sort,ReportType:ReportType,ReportIn:ReportIn},
				beforeSend: function () {
					$('#searchh4').css('display','block');
					$('#table-daily_report4 tbody').css('display','none');
					
				},
				complete: function () {
					
					$('#table-daily_report4 tbody').css('display','');
					$('#searchh4').css('display','none');
				},
				success:function(returndata){
					if(ChartType == "Pie"){
						Highcharts.chart('container4', {
							chart: {
								styledMode: true,  
								height: 600, // Increase chart height
								spacing: [10, 100, 10, 10],
							},
							title: {
								text: '<b>'+chart_title+' From '+from_date+' To '+to_date+'</b>'
							},
							subtitle: {
								text: ''
							},
							plotOptions: {
								pie: {
									size: '70%', // Force the pie to occupy 90% of the chart area
									dataLabels: {
										enabled: true,
										distance: 10, // Move data labels closer to the pie
										style: {
											fontSize: '14px'
										}
									}
								}
							},
							series: [{
								type: 'pie',
								allowPointSelect: true,
								keys: ['name', 'y', 'selected', 'sliced'],
								data: returndata.ChartData,
								showInLegend: true
							}],
							legend: {
								layout: 'horizontal', // Arrange legend items horizontally
								align: 'center', // Center-align the legend
								verticalAlign: 'bottom', // Place legend at the bottom
								itemWidth: 150, // Control the width of each legend item for better wrapping
								itemStyle: {
									fontSize: '14px'
								}
							},
						});
					}
					
					if(ChartType == "Bar"){
						Highcharts.chart('container4', {
							chart: {
								type: 'column'
							},
							title: {
								text: '<b>'+chart_title+' From '+from_date+' To '+to_date+'</b>'
							},
							subtitle: {
								text: ''
							},
							xAxis: {
								type: 'category',
								labels: {
									autoRotation: [-45, -90],
									style: {
										fontSize: '13px',
										fontFamily: 'Verdana, sans-serif'
									}
								}
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Value'
								}
							},
							legend: {
								enabled: false
							},
							tooltip: {
								pointFormat: 'Value : <b>{point.y:.1f} </b>'
							},
							series: [{
								name: 'Population',
								colors: [
								'#9b20d9', '#9215ac', '#861ec9', '#7a17e6', '#7010f9', '#691af3',
								'#6225ed', '#5b30e7', '#533be1', '#4c46db', '#4551d5', '#3e5ccf',
								'#3667c9', '#2f72c3', '#277dbd', '#1f88b7', '#1693b1', '#0a9eaa',
								'#03c69b',  '#00f194'
								],
								colorByPoint: true,
								groupPadding: 0,
								data: returndata.ChartData,
								dataLabels: {
									enabled: true,
									rotation: -90,
									color: '#FFFFFF',
									inside: true,
									verticalAlign: 'top',
									format: '{point.y:.1f}', // one decimal
									y: 10, // 10 pixels down from the top
									style: {
										fontSize: '13px',
										fontFamily: 'Verdana, sans-serif'
									}
								}
							}]
						});
					}
					
					// $('#table-daily_report4').html(returndata.TableData);
				}
			});
			
			
		}
		$('#search_data4').on('click',function(){
			var from_date = $("#from_date4").val();
			var to_date = $("#to_date4").val();
			var SubGroup = $("#SubGroup4").val();
			var MaxCount = $("#MaxCount4").val();
			var ReportType4 = $("#ReportType4").val();
			var ReportIn = $("#ReportIn4").val();
			var Sort = $("#Sort4").val();
			var ChartType = $("#ChartType4").val();
			load_data4(from_date,to_date,SubGroup,MaxCount,ReportType4,ReportIn,Sort,ChartType);
			
		});
		
		$('#search_data').click();
		$('#search_data2').click();
		$('#search_data4').click();
		$('#search_data3').click();
		
		
	});
	
	$("#caexcel").click(function(){
		
		var from_date = $("#from_date").val();
		var to_date = $("#to_date").val();
		var ChartType = $("#ChartType").val();
		var ItemCount = $("#ItemCount").val();
		var SubGroup = $("#SubGroup").val();
		var state = $("#state").val();
		var ReportType = $("#ReportType").val();
		var Items = $("#Items").val();
		
	    $.ajax({
			url:"<?php echo admin_url(); ?>sale_reports/export_GetTopSellingItem",
			method:"POST",
			data:{from_date:from_date, to_date:to_date,ChartType:ChartType,ItemCount:ItemCount,state:state,SubGroup:SubGroup,ReportType:ReportType,Items:Items},
			beforeSend: function () {
				$('#searchhExport').css('display','block');
			},
			complete: function () {
				$('#searchhExport').css('display','none');
			},
			success:function(data){
				response = JSON.parse(data);
				window.location.href = response.site_url+response.filename;
			}
		});
	});
	$("#caexcel2").click(function(){
		
		var from_date = $("#from_date2").val();
		var to_date = $("#to_date2").val();
		var ChartType = $("#ChartType2").val();
		var CustomerCount = $("#CustomerCount2").val();
		var state = $("#state2").val();
		
	    $.ajax({
			url:"<?php echo admin_url(); ?>sale_reports/export_GetTopSellingCustomer",
			method:"POST",
			data:{from_date:from_date, to_date:to_date,ChartType:ChartType,CustomerCount:CustomerCount,state:state},
			beforeSend: function () {
				$('#searchhExport2').css('display','block');
			},
			complete: function () {
				$('#searchhExport2').css('display','none');
			},
			success:function(data){
				response = JSON.parse(data);
				window.location.href = response.site_url+response.filename;
			}
		});
	});
	
	
</script>
<script type="text/javascript">
	function printPage(){
        
		var from_date = $("#from_date").val();
	    var to_date = $("#to_date").val();
	    var stylesheet = '<style type = "text/css"> th, td { padding: 5px 5px;} </style>';
		var tableData = '<table  border="1" cellpadding="0" cellspacing="0" width="100%" class="tree table table-striped table-bordered" style="font-size:12px;">'+document.getElementsByTagName('table')[0].innerHTML+'</table>';
        var heading_data = '<table  border="1" cellpadding="0" cellspacing="0" width="100%" class="tree table table-striped table-bordered" style="font-size:12px;"><tbody><tr><td style="text-align:center;" colspan="9"><?php echo $PlantDetail->FIRMNAME; ?></td></tr><tr><td style="text-align:center;" colspan="9"><?php echo $PlantDetail->ADDRESS1.' '.$PlantDetail->ADDRESS2; ?></td></tr>';
		heading_data += '<tr>';
		heading_data += '<td style="text-align:center;"colspan="9">Sales Report : '+from_date+' To '+to_date+'</td>';
		heading_data += '</tr>';
		heading_data += '</tbody></table>';
        var print_data = stylesheet+heading_data+tableData
		newWin= window.open("");
		newWin.document.write(print_data);
		newWin.print();
		newWin.close();
	};
</script>

<script>
    $(document).ready(function(){
		var maxEndDate = new Date('Y/m/d');
		var fin_y = "<?php echo $this->session->userdata('finacial_year')?>";
		
		var year = "20"+fin_y;
		var cur_y = new Date().getFullYear().toString().substr(-2);
		if(cur_y => fin_y){
			var year2 = parseInt(fin_y) + parseInt(1);
			var year2_new = "20"+year2;
			
			var e_dat = new Date(year2_new+'/03/31');
			
			var maxEndDate_new = e_dat;
			}else{
			var e_dat2 = new Date(year2+'/03/31');
			var maxEndDate_new = e_dat2;
		}
		
		var minStartDate = new Date(year, 03);
		
		
		$('#from_date').datetimepicker({
			format: 'd/m/Y',
			minDate: minStartDate,
			maxDate: maxEndDate_new,
			timepicker: false
		});
		
		$('#to_date').datetimepicker({
			format: 'd/m/Y',
			minDate: minStartDate,
			maxDate: maxEndDate_new,
			timepicker: false,
			showOtherMonths: false,
			pickTime: false,
            orientation: "left",
		});
		
		$(document).on("click", ".sortable", function () {
			var table = $("#table-daily_report tbody");
			var rows = table.find("tr").toArray();
			var index = $(this).index();
			var ascending = !$(this).hasClass("asc");
			
			
			// Remove existing sort classes and reset arrows
			$(".sortable").removeClass("asc desc");
			$(".sortable span").remove();
			
			// Add sort classes and arrows
			$(this).addClass(ascending ? "asc" : "desc");
			$(this).append(ascending ? '<span> &#8593;</span>' : '<span> &#8595;</span>');
			
			rows.sort(function (a, b) {
				var valA = $(a).find("td").eq(index).text().trim();
				var valB = $(b).find("td").eq(index).text().trim();
				
				if ($.isNumeric(valA) && $.isNumeric(valB)) {
					return ascending ? valA - valB : valB - valA;
					} else {
					return ascending
					? valA.localeCompare(valB)
					: valB.localeCompare(valA);
				}
			});
			table.append(rows);
		});
		
		$(document).on("click", ".sortable2", function () {
			var table = $("#table-daily_report2 tbody");
			var rows = table.find("tr").toArray();
			var index = $(this).index();
			var ascending = !$(this).hasClass("asc");
			
			
			// Remove existing sort classes and reset arrows
			$(".sortable2").removeClass("asc desc");
			$(".sortable2 span").remove();
			
			// Add sort classes and arrows
			$(this).addClass(ascending ? "asc" : "desc");
			$(this).append(ascending ? '<span> &#8593;</span>' : '<span> &#8595;</span>');
			
			rows.sort(function (a, b) {
				var valA = $(a).find("td").eq(index).text().trim();
				var valB = $(b).find("td").eq(index).text().trim();
				
				if ($.isNumeric(valA) && $.isNumeric(valB)) {
					return ascending ? valA - valB : valB - valA;
					} else {
					return ascending
					? valA.localeCompare(valB)
					: valB.localeCompare(valA);
				}
			});
			table.append(rows);
		});
	});
</script> 