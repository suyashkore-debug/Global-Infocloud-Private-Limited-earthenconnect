<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>

<div id="wrapper">
	<div class="content" >
	    
        <!-- Filet row-->
        <?php
			$fy = $this->session->userdata('finacial_year');
			$fy_new  = $fy + 1;
			$lastdate_date = '20'.$fy_new.'-03-31';
			$firstdate_date = '20'.$fy_new.'-04-01';
			$curr_date = date('Y-m-d');
			$curr_date_new    = new DateTime($curr_date);
			$last_date_yr = new DateTime($lastdate_date);
			if($last_date_yr < $curr_date_new){
				$to_date = '31/03/20'.$fy_new;
				$from_date = '01/03/20'.$fy_new;
				}else{
				$from_date = date('01/m/Y');
				$to_date = date('d/m/Y');
			}
		?>
		<div class="row">
		    <div class="col-md-12">
		        <div class="panel_s">
					<div class="panel-body">
						<nav aria-label="breadcrumb">
            				<ol class="breadcrumb custombreadcrumb" style="background-color:#fff !important; margin-Bottom:0px !important;">
            					<li class="breadcrumb-item"><a href="<?= admin_url();?>"><b><i class="fa fa-home fa-fw fa-lg"></i></b></a></li>
            					<li class="breadcrumb-item active text-capitalize"><b>Inventory</b></li>
            					<li class="breadcrumb-item active" aria-current="page"><b>Dashboard</b></li>
							</ol>
						</nav>
                        <hr class="hr_style">
					    <div class="row">
							<div class="col-md-6">
							    <div class="row">
							        <div class="col-md-3">
        								<?php
        									echo render_date_input('from_date2','From Date',$from_date);
										?>
									</div>
        							<div class="col-md-3">
        								<?php
        									echo render_date_input('to_date2','To Date',$to_date);
										?>
									</div>
        							<div class="col-md-6">
        								<div class="form-group">
        									<label for="AccountID" class="control-label" ><small class="req text-danger"></small> Party</label>
        									<select class="selectpicker" name="AccountID" id="AccountID" data-width="100%"  data-action-box="true" data-hide-disabled="true" data-live-search="true" data-none-selected-text="<?php echo _l('dropdown_non_selected_tex'); ?>">
        										<option value=""></option>
        										<?php
        											foreach($AllPartyList as $key => $value) {
													?>
        											<option value="<?php echo $value["AccountID"]?>"><?php echo $value["company"]?></option>
        											<?php
													}
												?>
        										
											</select>
										</div> 
									</div>
        							
							        <div class="clearfix"></div>
							        
									<div class="col-md-4">
										<div class="form-group">
											<label class="form-label">Main Item Group</label>
											<select class="selectpicker" name="MainItemGroup" id="MainItemGroup" data-width="100%" data-none-selected-text="None selected" data-live-search="true">
												<option value=""></option>   
												<?php
													foreach ($MainItemGroup as $key => $value) {
													?>
													<option <?php if($value['id'] == '1'){echo "selected";}?> value="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></option>   
													<?php   
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label" for="SubGroup1">Sub-Group 1</label>
											<select class="selectpicker display-block" data-width="100%" id="SubGroup1" name="SubGroup1" data-none-selected-text="None selected" data-live-search="true" >
												<option value="">None selected</option>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label" for="SubGroup2">Sub-Group 2</label>
											<select class="selectpicker display-block" data-width="100%" id="SubGroup2" name="SubGroup2" data-none-selected-text="None selected" data-live-search="true" >
												<option value="">None selected</option>
											</select>
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label" for="ItemID">Item</label>
											<select class="selectpicker display-block" data-width="100%" id="ItemID" name="ItemID" data-none-selected-text="None selected" data-live-search="true" >
												<option value="">None selected</option>
											</select>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label" for="ItemType">Item Type</label>
											<select class="selectpicker display-block" data-width="100%" id="ItemType" name="ItemType" data-none-selected-text="None selected">
												<option value="">All</option>
												<option value="Taxable">Taxable</option>
												<option value="NonTaxable">Non Taxable</option>
											</select>
										</div>
									</div>
        							
									<div class="col-md-3">
										<div class="form-group" app-field-wrapper="GodownID">
											<small class="req text-danger"> </small>
											<label for="GodownID" class="form-label">GodownID</label> 
											<select name="GodownID" id="GodownID" class="selectpicker form-control" data-none-selected-text="Non Selected" data-live-search="true" >
												<option value="">ALL</option>
												<?php
													foreach ($GodownData as $key => $value) {
													?>
													<option value="<?php echo $value['AccountID'];?>" ><?php echo $value['AccountName'];?></option>
													<?php
													}
												?>
											</select>
										</div>
									</div>
        							<div class="col-md-2" style="margin-top:20px;">
        								<button class="btn btn-info pull-left mleft5 search_data" id="search_data"><?php echo _l('rate_filter'); ?></button> 
									</div>
								</div>
							</div>
							<div class="col-md-6">
							    <div class="row">
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 <?php echo $initial_column; ?>">
        								<div class="top_stats_wrapper custdesg bg2">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="TotalStockIssueAmt"></p>
        										<p class="title"><?php echo _l('Total Stock Issue Amount'); ?></p>
											</div>
										</div>
									</div>
        							
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
        								<div class="top_stats_wrapper custdesg bg1">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="TotalStockReceived"></p>
        										<p class="title"><?php echo _l('Total Stock Received Amt'); ?></p>
											</div>
										</div>
									</div>
        							
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 <?php echo $initial_column; ?>">
        								<div class="top_stats_wrapper custdesg bg2">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="TotalSku"></p>
        										<p class="title"><?php echo _l('Total SKU'); ?></p>
											</div>
										</div>
									</div>
        							
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
        								<div class="top_stats_wrapper custdesg bg1">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="StockOutRate"></p>
        										<p class="title"><?php echo _l('Stock Out Rate'); ?></p>
											</div>
										</div>
									</div>
        							
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 <?php echo $initial_column; ?>">
        								<div class="top_stats_wrapper custdesg bg2">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="DeadStockCount"></p>
        										<p class="title"><?php echo _l('Dead Stock Count'); ?></p>
											</div>
										</div>
									</div>
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
        								<div class="top_stats_wrapper custdesg bg1">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="LowStockCount"></p>
        										<p class="title"><?php echo _l('Low Stock Count'); ?></p>
											</div>
										</div>
									</div>
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 <?php echo $initial_column; ?>">
        								<div class="top_stats_wrapper custdesg bg2">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="StockValueRM"></p>
        										<p class="title"><?php echo _l('Stock Value RM'); ?></p>
											</div>
										</div>
									</div>
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
        								<div class="top_stats_wrapper custdesg bg1">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="StockValuePM"></p>
        										<p class="title"><?php echo _l('Stock Value PM'); ?></p>
											</div>
										</div>
									</div>
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 <?php echo $initial_column; ?>">
        								<div class="top_stats_wrapper custdesg bg2">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="StockValueFG"></p>
        										<p class="title"><?php echo _l('Stock Value FG'); ?></p>
											</div>
										</div>
									</div>
							        <div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
        								<div class="top_stats_wrapper custdesg bg1">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="TotalStockIssueQty"></p>
        										<p class="title"><?php echo _l('Total Stock Issued'); ?></p>
											</div>
										</div>
									</div>
									<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
        								<div class="top_stats_wrapper custdesg bg2">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxt" id="TotalStockReceivedQty"></p>
        										<p class="title"><?php echo _l('Total Stock Received Qty'); ?></p>
											</div>
										</div>
									</div>
									<div class="quick-stats-invoices col-xs-12 col-md-3 col-sm-3 ">
        								<div class="top_stats_wrapper custdesg bg1">
        									<div class="col-md-12">
        										<p class="mtop5 labeltxtItem" id="HighestOrderItem"></p>
        										<p class="title"><?php echo _l('Highest Order Item'); ?></p>
											</div>
										</div>
									</div>
        							<div class="clearfix"></div>
        							
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
		
	    <div class="row">
			
	        <!-- First Row -->
	        
	        <div class="col-md-8 DayWiseTransactionChart Padding_right">
	            <div class="panel_s top_stats_wrapper">
					<div class="panel-body">
				        <figure class="highcharts-figure">
							<div id="DayWiseTransactionChart"></div>
						</figure>
					</div>
				</div>
			</div>
			
	        <div class="col-md-4 DailyTransactionChart Padding_right">
	            <div class="panel_s top_stats_wrapper">
					<div class="panel-body">
				        <figure class="highcharts-figure">
							<div id="DailyTransactionChart"></div>
						</figure>
					</div>
				</div>
			</div>
			 <div class="col-md-12 PartyWiseCrateBalace Padding_right">
	            <div class="panel_s top_stats_wrapper">
					<div class="panel-body">
				        <figure class="highcharts-figure">
							<div id="PartyWiseCrateBalace"></div>
						</figure>
					</div>
				</div>
			</div>
	        <div class="col-md-12 TopStockLevel Padding_right">
	            <div class="panel_s top_stats_wrapper">
					<div class="panel-body">
				        <figure class="highcharts-figure">
							<div id="TopStockLevel"></div>
						</figure>
					</div>
				</div>
			</div>
			
			<div class="col-md-12 Padding_right MonthlyStockLevel">
	            <div class="panel_s">
					<div class="panel-body">
						<figure class="highcharts-figure">
							<div id="MonthlyStockLevel"></div>
						</figure>
					</div>
				</div>
			</div>
			<div class="col-md-12 Padding_right DayWiseStockLevel">
	            <div class="panel_s">
					<div class="panel-body">
						<figure class="highcharts-figure">
							<div id="DayWiseStockLevel"></div>
						</figure>
					</div>
				</div>
			</div>
			
			
		</div>
	</div>
</div>

<style>
    .CrateLedger { overflow: auto;max-height: 58vh;position:relative;top: 0px; }
	.CrateLedger thead th { position: sticky; top: 0; z-index: 1; }
	.CrateLedger tbody th { position: sticky; left: 0; }
	
	/* Just common table stuff. Really. */
	.CrateLedger table  { border-collapse: collapse; }
	.CrateLedger th, td { padding: 3px 3px !important; white-space: nowrap;font-size:11px; line-height:1.42857143;vertical-align: middle;}
	.CrateLedger th     { background: #50607b;color: #fff !important; }
	
	
</style>
<style>
	@import url("https://code.highcharts.com/css/highcharts.css");
	
	/*	.highcharts-pie-series .highcharts-point {
	stroke: #ede;
	stroke-width: 2px;
	}
	#wrapper{
	background: #fff;
	}
	.highcharts-pie-series .highcharts-data-label-connector {
    stroke: silver;
    stroke-dasharray: 2, 2;
    stroke-width: 2px;
	}
	
	.highcharts-figure,
	.highcharts-data-table table {
    min-width: 320px;
    max-width: 600px;
    margin: 1em auto;
	}
	
	.highcharts-data-table table {
    font-family: Verdana, sans-serif;
    border-collapse: collapse;
    border: 1px solid #ebebeb;
    margin: 10px auto;
    text-align: center;
    width: 100%;
    max-width: 500px;
	}
	
	.highcharts-data-table caption {
    padding: 1em 0;
    font-size: 1.2em;
    color: #555;
	}
	
	.highcharts-data-table th {
    font-weight: 600;
    padding: 0.5em;
	}
	
	.highcharts-data-table td,
	.highcharts-data-table th,
	.highcharts-data-table caption {
    padding: 0.5em;
	}
	
	.highcharts-data-table thead tr,
	.highcharts-data-table tr:nth-child(even) {
    background: #f8f8f8;
	}
	
	.highcharts-data-table tr:hover {
    background: #f1f7ff;
	}
	
	.highcharts-description {
    margin: 0.3rem 10px;
	}
	
	*/
	.Padding_right{
	padding-right:1px;
	}
	.Padding_left{
	padding-left:1px;
	}
	.Padding_left_right{
	padding-left:1px;
	padding-right:1px;
	}
	.Padding_right .panel_s .panel-body{
	padding:1px;
	min-height:300px;
	max-height:600px;
	}
	.Padding_left .panel_s .panel-body{
	padding:1px;
	min-height:300px;
	max-height:600px;
	}
	.Padding_left_right .panel_s .panel-body{
	padding:1px;
	min-height:300px;
	max-height:600px;
	}
	.highcharts-credits {
    display: none;
	}
	.table-table_staff tbody{
	display: block;
	max-height: 450px;
	overflow-y: scroll;
	width: calc(100% - -8.9em);
	}
	.table-table_staff thead, .table-table_staff tbody tr{
	display: table;
	table-layout: fixed;
	width: 100%;
	
	}
	.table-table_staff thead{
	width: calc(100% - -5.9em);
	}
	.table-table_staff thead{
	position: relative;
	}
	.table-table_staff thead th:last-child:after{
	content: ' ';
	position: absolute;
	background-color: #337ab7;
	width: 1.3em;
	height: 38px;
	right: -1.3em;
	top: 0;
	border-bottom: 2px solid #ddd;
	}
	
	/*.staff_name{*/
	/*width:21%;*/
	/*}*/
	.table-table_staff th td{padding: 32px -20px 12px 14px;
	}
	
	.fontsize{
	font-size:13px;
	}
	.fontsize2{
	font-size:15px;
	}
	
    thead tr:nth-child(2) th {
	top: 20px; /* Offset for the second row to appear below the first */
    }
</style>

<style>
    .table-daily_report          { overflow: auto;max-height: 55vh;width:100%;position:relative;top: 0px; }
	.table-daily_report thead th { position: sticky; top: 0; z-index: 1; }
	.table-daily_report tbody th { position: sticky; left: 0; }
	
	
	table  { border-collapse: collapse; width: 100%; }
	th, td { padding: 0px 5px !important; white-space: nowrap; border:1px solid !important;font-size:11px; line-height:1.42857143!important;vertical-align: middle !important;}
	th     { background: #50607b;
    color: #fff !important; }
    
    .custdesg{
	height:55px;
    }
    .col-md-3.col-sm-3.col-xs-12.quick-stats-invoices {
	padding: 0px 2px 0px 2px;
    }
    .imgsize{
	font-size:40px;
	display: block;
	margin: 0;
	color: #fff;
    }
    .panel_s{
	margin-bottom:5px !important;
    }
    .labeltxt{
	font-size: 23px;
	color: #fff;
	text-align: center;
	/*font-weight: 700;*/
	margin:0px;
    }
    .labeltxtItem{
	font-size: 10px;
	color: #fff;
	text-align: center;
	/*font-weight: 700;*/
	margin:0px;
    }
    .title{
	font-size: 13px;
	color: #fff;
	text-align: center;
	/*font-weight: 700;*/
	margin:0px;
    }
    .numstyl{
	text-align: left;
	display: block;
	font-size: 14px;
    }
    /*.mtop5 {
	margin-top: 4px;
	margin-bottom: 2px;
    }*/
    .mtop5 {
	margin-top: 1px;
	margin-bottom: 1px;
    }
    .bg1{
	background-image: linear-gradient(to right,#008385 0,#008385 100%);
	background-repeat: repeat-x;
    }
    .bg2{
	background-image: linear-gradient(to right,#FF425C 0,#FF425C 100%);
	background-repeat: repeat-x;
    }
    .bg3{
	background-image: linear-gradient(to right,#FF864A 0,#FF864A 100%);
	background-repeat: repeat-x;
    }
    .bg4{
	background-image: linear-gradient(to right,#11A578 0,#11A578 100%);
	background-repeat: repeat-x;
    }
	.top_stats_wrapper{
	margin-top: 0px;
	border-radius: 5px;
	padding:0px !important;
	margin-bottom: 5px !important;
	}
    .top_stats_wrapper:hover{
	box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.4);
    }
</style>

<?php init_tail(); ?>
<!--new update -->
<!--<script src="https://code.highcharts.com/dashboards/datagrid.js"></script>
	<script src="https://code.highcharts.com/dashboards/dashboards.js"></script>
<script src="https://code.highcharts.com/dashboards/modules/layout.js"></script>-->

<script>
	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode = 46 && charCode > 31 
		&& (charCode < 48 || charCode > 57)){
			return false;
		}
		return true;
	}
	
	$('#MainItemGroup').on('change', function() {
		var MainItemGroup = $(this).val();
		//alert(roleid);
		var url = "<?php echo base_url(); ?>admin/invoice_items/GetSubgroup1Data";
		jQuery.ajax({
			type: 'POST',
			url:url,
			data: {MainItemGroup: MainItemGroup},
			dataType:'json',
			success: function(data) {
				$("#SubGroup1").find('option').remove();
				$("#SubGroup1").selectpicker("refresh");
				$("#SubGroup1").append(new Option('None selected', ''));
				for (var i = 0; i < data.length; i++) {
					$("#SubGroup1").append(new Option(data[i].name, data[i].id));
				}
				$('.selectpicker').selectpicker('refresh');
			}
		});
	});
	
	$('#SubGroup1').on('change', function() {
		var SubGroup1 = $(this).val();
		//alert(roleid);
		var url = "<?php echo base_url(); ?>admin/invoice_items/GetSubgroup2Data";
		jQuery.ajax({
			type: 'POST',
			url:url,
			data: {SubGroup1: SubGroup1},
			dataType:'json',
			success: function(data) {
				$("#SubGroup2").find('option').remove();
				$("#SubGroup2").selectpicker("refresh");
				$("#SubGroup2").append(new Option('None selected', ''));
				for (var i = 0; i < data.length; i++) {
					$("#SubGroup2").append(new Option(data[i].name, data[i].id));
				}
				$('.selectpicker').selectpicker('refresh');
			}
		});
	});
	$('#SubGroup2').on('change', function() {
		var SubGroup2 = $(this).val();
		//alert(roleid);
		var url = "<?php echo base_url(); ?>admin/invoice_items/GetItemBySubgroup2Data";
		jQuery.ajax({
			type: 'POST',
			url:url,
			data: {SubGroup2: SubGroup2},
			dataType:'json',
			success: function(data) {
				$("#ItemID").find('option').remove();
				$("#ItemID").selectpicker("refresh");
				$("#ItemID").append(new Option('None selected', ''));
				for (var i = 0; i < data.length; i++) {
					$("#ItemID").append(new Option(data[i].description, data[i].item_code));
				}
				$('.selectpicker').selectpicker('refresh');
			}
		});
	});
</script>
<script type="text/javascript" language="javascript" >
	$(document).ready(function(){
		$('#MainItemGroup').change();
		function GetCountersValue(from_date,to_date,AccountID,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID)
		{
			$.ajax({
				url:"<?php echo admin_url(); ?>invoice_items/GetInventoryDashboardCounters",
				dataType:"JSON",
				method:"POST",
				data:{
					from_date: from_date,
					to_date: to_date,
					AccountID: AccountID,
					MainItemGroup: MainItemGroup,
					SubGroup1: SubGroup1,
					SubGroup2: SubGroup2,
					ItemID: ItemID,
					ItemType: ItemType,
					GodownID: GodownID,
				},
				beforeSend: function () {
				},
				complete: function () {
				},
				success:function(returndata){
					var TotalSku = returndata.TotalSku;
					var LowStockCount = returndata.LowStockCount;
					var DeadStockCount = returndata.DeadStockCount;
					var StockValueRM = returndata.StockValueRM;
					var StockValuePM = returndata.StockValuePM;
					var StockValueFG = returndata.StockValueFG;
					var TotalStockReceived = returndata.TotalStockReceived;
					var TotalStockIssueAmt = returndata.TotalStockIssueAmt;
					var TotalStockIssueQty = returndata.TotalStockIssueQty;
					var TotalStockReceivedQty = returndata.TotalStockReceivedQty;
					var HighestOrderItem = returndata.HighestOrderItem;
					
					$("#TotalSku").html(TotalSku ?? "0");
					$("#LowStockCount").html(LowStockCount ?? "0");
					$("#DeadStockCount").html(DeadStockCount ?? "0");
					$("#StockValueRM").html(StockValueRM ?? "0");
					$("#StockValuePM").html(StockValuePM ?? "0");
					$("#StockValueFG").html(StockValueFG ?? "0");
					$("#TotalStockReceived").html(TotalStockReceived ?? "0");
					$("#TotalStockIssueAmt").html(TotalStockIssueAmt ?? "0");
					$("#TotalStockIssueQty").html(TotalStockIssueQty ?? "0");
					$("#TotalStockReceivedQty").html(TotalStockReceivedQty ?? "0");
					$("#HighestOrderItem").html(HighestOrderItem ?? "");
				}
			});
		}
		$('#search_data').on('click',function(){
			// var month = $("#month").val();
			var from_date = $("#from_date2").val();
			var to_date = $("#to_date2").val();
			var AccountID = $("#AccountID").val();
			var MainItemGroup = $("#MainItemGroup").val();
			var SubGroup1 = $("#SubGroup1").val();
			var SubGroup2 = $("#SubGroup2").val();
			var ItemID = $("#ItemID").val();
			var ItemType = $("#ItemType").val();
			var GodownID = $("#GodownID").val();
			
			
			GetCountersValue(from_date,to_date,AccountID,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID);
			PartyWiseCrateBalace(from_date,to_date,AccountID);
			DailyTransactionChart(from_date,to_date,AccountID,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID);
			DayWiseTransactionChart(from_date,to_date,AccountID,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID);
			TopStockLevel(from_date,to_date,AccountID,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID);
			MonthlyStockLevel(MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID);
			DayWiseStockLevel(from_date,to_date,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID);
		});
		
		function PartyWiseCrateBalace(from_date, to_date,AccountID) {
			$.ajax({
				url: "<?php echo admin_url(); ?>invoice_items/GetPartyWiseCrateBalace",
				dataType: "JSON",
				method: "POST",
				data: {
					from_date: from_date,
					to_date: to_date,
					AccountID: AccountID,
				},
				beforeSend: function () {
					$('#searchh2').css('display', 'block');
					$('.table-daily_report tbody').css('display', 'none');
				},
				complete: function () {
					$('.table-daily_report tbody').css('display', '');
					$('#searchh2').css('display', 'none');
				},
				success: function (returndata) {
					Highcharts.chart('PartyWiseCrateBalace', {
						chart: {
							type: 'column',
							height: 300,
						},
						title: {
							text: ''
						},
						subtitle: {
							text: '<b>Party Wise Crate Balance '+from_date+' To '+to_date+'</b>'
						},
						xAxis: {
							type: 'category',
							labels: {
								autoRotation: [-45, -90],
							}
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Total Qty'
							}
						},
						legend: {
							enabled: false
						},
						tooltip: {
							pointFormat: 'Total Qty: <b>{point.y:.1f} </b>'
						},
						series: [{
							name: 'Population',
							colors: [ '#119EFA','#15f34f','#ef370dc7','#791db2d1', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263','#6AF9C4','#50B432','#0d91efc7','#ED561B'],
							colorByPoint: true,
							groupPadding: 0,
							data: returndata.Crates,
							dataLabels: {
								enabled: true,
								rotation: -90,
								color: '#FFFFFF',
								inside: true,
								verticalAlign: 'top',
								format: '{point.y:.1f}', // one decimal
								y: 10, // 10 pixels down from the top
								
							}
						}]
					});
				}
			});
		}
		function DailyTransactionChart(from_date, to_date,AccountID,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID) {
			$.ajax({
				url: "<?php echo admin_url(); ?>invoice_items/GetAllDailyTransactionChart",
				dataType: "JSON",
				method: "POST",
				data: {
					from_date: from_date,
					to_date: to_date,
					AccountID: AccountID,
					MainItemGroup: MainItemGroup,
					SubGroup1: SubGroup1,
					SubGroup2: SubGroup2,
					ItemID: ItemID,
					ItemType: ItemType,
					GodownID: GodownID,
				},
				beforeSend: function () {
					$('#searchh2').css('display', 'block');
					$('.table-daily_report tbody').css('display', 'none');
				},
				complete: function () {
					$('.table-daily_report tbody').css('display', '');
					$('#searchh2').css('display', 'none');
				},
				success: function (returndata) {
					Highcharts.chart('DailyTransactionChart', {
						chart: {
							type: 'column',
							height: 300,
						},
						title: {
							text: ''
						},
						subtitle: {
							text: '<b>Transactional Data Between '+from_date+' To '+to_date+'</b>'
						},
						xAxis: {
							type: 'category',
							labels: {
								autoRotation: [-45, -90],
							}
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Total Qty'
							}
						},
						legend: {
							enabled: false
						},
						tooltip: {
							pointFormat: 'Total Qty : <b>{point.y:.1f} </b>'
						},
						series: [{
							name: 'Population',
							colors: [ '#119EFA','#15f34f','#ef370dc7','#791db2d1', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263','#6AF9C4','#50B432','#0d91efc7','#ED561B'],
							colorByPoint: true,
							groupPadding: 0,
							data: returndata.TransData,
							dataLabels: {
								enabled: true,
								rotation: -90,
								color: '#FFFFFF',
								inside: true,
								verticalAlign: 'top',
								format: '{point.y:.1f}', // one decimal
								y: 10, // 10 pixels down from the top
								
							}
						}]
					});
				}
			});
		}
		function DayWiseTransactionChart(from_date, to_date,AccountID,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID) {
			$.ajax({
				url: "<?php echo admin_url(); ?>invoice_items/DayWiseTransactionChart",
				dataType: "JSON",
				method: "POST",
				data: {
					from_date: from_date,
					to_date: to_date,
					AccountID: AccountID,
					MainItemGroup: MainItemGroup,
					SubGroup1: SubGroup1,
					SubGroup2: SubGroup2,
					ItemID: ItemID,
					ItemType: ItemType,
					GodownID: GodownID,
				},
				beforeSend: function () {
					$('#searchh2').css('display', 'block');
					$('.table-daily_report tbody').css('display', 'none');
				},
				complete: function () {
					$('.table-daily_report tbody').css('display', '');
					$('#searchh2').css('display', 'none');
				},
				success: function (returndata) {
					Highcharts.chart('DayWiseTransactionChart', {
						chart: {
							type: 'line',
							height: 253,
						},
						title: {
							text: ''
						},
						subtitle: {
							text: '<b>Day Wise Transactional Data Between '+from_date+' To '+to_date+'</b>'
						},
						xAxis: {
							categories: returndata.Days // Set dynamically from server
						},
						yAxis: {
							title: {
								text: 'Total Qty'
							}
						},
						plotOptions: {
							line: {
								dataLabels: {
									enabled: true
								},
								enableMouseTracking: false
							}
						},
						series: returndata.Transaction
					});
				}
			});
		}
		function TopStockLevel(from_date, to_date,AccountID,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID) {
			$.ajax({
				url: "<?php echo admin_url(); ?>invoice_items/GetTopStockLevelChart",
				dataType: "JSON",
				method: "POST",
				data: {
					from_date: from_date,
					to_date: to_date,
					AccountID: AccountID,
					MainItemGroup: MainItemGroup,
					SubGroup1: SubGroup1,
					SubGroup2: SubGroup2,
					ItemID: ItemID,
					ItemType: ItemType,
					GodownID: GodownID,
				},
				beforeSend: function () {
					$('#searchh2').css('display', 'block');
					$('.table-daily_report tbody').css('display', 'none');
				},
				complete: function () {
					$('.table-daily_report tbody').css('display', '');
					$('#searchh2').css('display', 'none');
				},
				success: function (returndata) {
					Highcharts.chart('TopStockLevel', {
						chart: {
							type: 'column',
							height: 300,
						},
						title: {
							text: ''
						},
						subtitle: {
							text: '<b>Highest Stock Level As On '+to_date+'</b>'
						},
						xAxis: {
							type: 'category',
							labels: {
								autoRotation: [-45, -90],
							}
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Total Qty'
							}
						},
						legend: {
							enabled: false
						},
						tooltip: {
							pointFormat: 'Total Qty : <b>{point.y:.1f} </b>'
						},
						series: [{
							name: 'Population',
							colors: [ '#119EFA','#15f34f','#ef370dc7','#791db2d1', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263','#6AF9C4','#50B432','#0d91efc7','#ED561B'],
							colorByPoint: true,
							groupPadding: 0,
							data: returndata.TransData,
							dataLabels: {
								enabled: true,
								rotation: -90,
								color: '#FFFFFF',
								inside: true,
								verticalAlign: 'top',
								format: '{point.y:.1f}', // one decimal
								y: 10, // 10 pixels down from the top
								
							}
						}]
					});
				}
			});
		}
		function MonthlyStockLevel(MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID) {
			$.ajax({
				url: "<?php echo admin_url(); ?>invoice_items/GetTopMonthlyStockLevelChart",
				dataType: "JSON",
				method: "POST",
				data: {
					MainItemGroup: MainItemGroup,
					SubGroup1: SubGroup1,
					SubGroup2: SubGroup2,
					ItemID: ItemID,
					ItemType: ItemType,
					GodownID: GodownID,
				},
				beforeSend: function () {
					$('#searchh2').css('display', 'block');
					$('.table-daily_report tbody').css('display', 'none');
				},
				complete: function () {
					$('.table-daily_report tbody').css('display', '');
					$('#searchh2').css('display', 'none');
				},
				success: function (returndata) {
					Highcharts.chart('MonthlyStockLevel', {
						chart: {
							type: 'line',
							height: 253,
						},
						title: {
							text: 'Monthly Stock Level'
						},
						subtitle: {
							text: ''
						},
						xAxis: {
							categories: returndata.Months // Set dynamically from server
						},
						yAxis: {
							title: {
								text: 'Stock Qty'
							}
						},
						plotOptions: {
							line: {
								dataLabels: {
									enabled: true
								},
								enableMouseTracking: false
							}
						},
						series: returndata.Stock
					});
				}
			});
		}
		function DayWiseStockLevel(from_date,to_date,MainItemGroup,SubGroup1,SubGroup2,ItemID,ItemType,GodownID) {
			$.ajax({
				url: "<?php echo admin_url(); ?>invoice_items/GetTopDayWiseStockLevelChart",
				dataType: "JSON",
				method: "POST",
				data: {
					from_date: from_date,
					to_date: to_date,
					MainItemGroup: MainItemGroup,
					SubGroup1: SubGroup1,
					SubGroup2: SubGroup2,
					ItemID: ItemID,
					ItemType: ItemType,
					GodownID: GodownID,
				},
				beforeSend: function () {
					$('#searchh2').css('display', 'block');
					$('.table-daily_report tbody').css('display', 'none');
				},
				complete: function () {
					$('.table-daily_report tbody').css('display', '');
					$('#searchh2').css('display', 'none');
				},
				success: function (returndata) {
					Highcharts.chart('DayWiseStockLevel', {
						chart: {
							type: 'line',
							height: 253,
						},
						title: {
							text: ''
						},
						subtitle: {
							text: '<b>Day Wise Stock Level Between '+from_date+' To '+to_date+'</b>'
						},
						xAxis: {
							categories: returndata.Days // Set dynamically from server
						},
						yAxis: {
							title: {
								text: 'Stock'
							}
						},
						plotOptions: {
							line: {
								dataLabels: {
									enabled: true
								},
								enableMouseTracking: false
							}
						},
						series: returndata.Stock
					});
				}
			});
		}
		
		$('#search_data').click();
		
	});
	
</script>
<script type="text/javascript">
	function printPage(){
        
		var from_date = $("#from_date").val();
	    var to_date = $("#to_date").val();
	    var stylesheet = '<style type = "text/css"> th, td { padding: 5px 5px;} </style>';
		var tableData = '<table  border="1" cellpadding="0" cellspacing="0" width="100%" class="tree table table-striped table-bordered" style="font-size:12px;">'+document.getElementsByTagName('table')[0].innerHTML+'</table>';
        var heading_data = '<table  border="1" cellpadding="0" cellspacing="0" width="100%" class="tree table table-striped table-bordered" style="font-size:12px;"><tbody><tr><td style="text-align:center;" colspan="9"><?php echo $PlantDetail->FIRMNAME; ?></td></tr><tr><td style="text-align:center;" colspan="9"><?php echo $PlantDetail->ADDRESS1.' '.$PlantDetail->ADDRESS2; ?></td></tr>';
		heading_data += '<tr>';
		heading_data += '<td style="text-align:center;"colspan="9">Sales Report : '+from_date+' To '+to_date+'</td>';
		heading_data += '</tr>';
		heading_data += '</tbody></table>';
        var print_data = stylesheet+heading_data+tableData
		newWin= window.open("");
		newWin.document.write(print_data);
		newWin.print();
		newWin.close();
	};
</script>

<script>
    $(document).ready(function(){
		var maxEndDate = new Date('Y/m/d');
		var fin_y = "<?php echo $this->session->userdata('finacial_year')?>";
		
		var year = "20"+fin_y;
		var cur_y = new Date().getFullYear().toString().substr(-2);
		if(cur_y => fin_y){
			var year2 = parseInt(fin_y) + parseInt(1);
			var year2_new = "20"+year2;
			
			var e_dat = new Date(year2_new+'/03/31');
			
			var maxEndDate_new = e_dat;
			}else{
			var e_dat2 = new Date(year2+'/03/31');
			var maxEndDate_new = e_dat2;
		}
		
		var minStartDate = new Date(year, 03);
		
		
		$('#from_date').datetimepicker({
			format: 'd/m/Y',
			minDate: minStartDate,
			maxDate: maxEndDate_new,
			timepicker: false
		});
		
		$('#to_date').datetimepicker({
			format: 'd/m/Y',
			minDate: minStartDate,
			maxDate: maxEndDate_new,
			timepicker: false,
			showOtherMonths: false,
			pickTime: false,
            orientation: "left",
		});
		
		$(document).on("click", ".sortable", function () {
			var table = $("#table-daily_report tbody");
			var rows = table.find("tr").toArray();
			var index = $(this).index();
			var ascending = !$(this).hasClass("asc");
			
			
			// Remove existing sort classes and reset arrows
			$(".sortable").removeClass("asc desc");
			$(".sortable span").remove();
			
			// Add sort classes and arrows
			$(this).addClass(ascending ? "asc" : "desc");
			$(this).append(ascending ? '<span> &#8593;</span>' : '<span> &#8595;</span>');
			
			rows.sort(function (a, b) {
				var valA = $(a).find("td").eq(index).text().trim();
				var valB = $(b).find("td").eq(index).text().trim();
				
				if ($.isNumeric(valA) && $.isNumeric(valB)) {
					return ascending ? valA - valB : valB - valA;
					} else {
					return ascending
					? valA.localeCompare(valB)
					: valB.localeCompare(valA);
				}
			});
			table.append(rows);
		});
		
		
	});
</script> 