<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
        
            
     <?php hooks()->do_action('before_items_page_content'); ?>
     <?php if(has_permission('hsnmaster','','create')){ ?>
       <!--<div class="_buttons">
        <h4>Add New Sales Receipts</h4>
      </div>-->
      <div class="clearfix"></div>
      <!--<hr class="hr-panel-heading" />-->
      <?php echo form_open('admin/cd_notes/add',array('id'=>'salereceipts_form')); ?>
            <div class="row">
                
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-8">
                            
                            <!--START First row-->
                            <div class="row">
                                
                                <div class="col-md-3" style="padding-right: 0px;">
                                    <?php
                                        $selected_company = $this->session->userdata('root_company');
                                        if($selected_company == 1){
                                        
                                        $new_creditNumber = get_option('next_credit_number_for_cspl');
                                        $new_debitNumber = get_option('next_debit_number_for_cspl');
                                    }elseif($selected_company == 2){
                                        $new_creditNumber = get_option('next_credit_number_for_cff');
                                        $new_debitNumber = get_option('next_debit_number_for_cff');
                                    }elseif($selected_company == 3){
                                        $new_creditNumber = get_option('next_credit_number_for_cbu');
                                        $new_debitNumber = get_option('next_debit_number_for_cbu');
                                    }
                                    
                                       $format = get_option('invoice_number_format');
                
                               
                                $prefix = "CR";
                                $prefix2 = "DB";
                               if ($format == 1) {
                                 $__number = $new_creditNumber;
                                 $__number2 = $new_debitNumber;
                                 $prefix = $prefix.'<span id="prefix_year">'.date('y').'</span>';
                                 $prefix2 = $prefix2.'<span id="prefix_year">'.date('y').'</span>';
                               } else if($format == 2) {
                                 
                                  $__number = $new_creditNumber;
                                  $__number2 = $new_debitNumber;
                                  $prefix = $prefix.'<span id="prefix_year">'.date('Y').'</span>/';
                                  $prefix2 = $prefix2.'<span id="prefix_year">'.date('Y').'</span>/';
                                
                               } else if($format == 3) {
                                  $__number2 = $new_debitNumber;
                                  $__number = $new_creditNumber;
                                
                               } else if($format == 4) {
                                  
                                  $yyyy = date('Y');
                                  $mm = date('m');
                                  $__number2 = $new_debitNumber;
                                  $__number = $new_creditNumber;
                                
                               }
                
                              
                               $_credit_number = str_pad($__number, get_option('number_padding_prefixes'), '0', STR_PAD_LEFT);
                               $_debit_number = str_pad($__number2, get_option('number_padding_prefixes'), '0', STR_PAD_LEFT);
                                ?>
                                <div class="form-group credit_div">
                                           <label for="number">
                                              Credit
                                             <!-- <i class="fa fa-question-circle" data-toggle="tooltip" data-title="<?php echo _l('invoice_number_not_applied_on_draft') ?>" data-placement="top"></i>-->
                                        </label>
                                    <div class="input-group">
                                <span class="input-group-addon">
                                              <?php
                                                echo $prefix;
                                              ?>
                                              </span>
                                              <input type="text" name="credit_noteid" id="credit_noteid" class="form-control credit_noteid" value="<?php echo ($_is_draft) ? 'DRAFT' : $_credit_number; ?>" data-isedit="<?php echo $isedit; ?>" data-original-number="<?php echo $data_original_number; ?>" <?php echo ($_is_draft) ? 'disabled' : '' ?>>
                                    </div>
                                    </div>
                                    
                                    <div class="form-group debit_div" style="display:none;">
                                           <label for="number">
                                              Debit
                                             <!-- <i class="fa fa-question-circle" data-toggle="tooltip" data-title="<?php echo _l('invoice_number_not_applied_on_draft') ?>" data-placement="top"></i>-->
                                        </label>
                                    <div class="input-group">
                                <span class="input-group-addon">
                                              <?php
                                                echo $prefix2;
                                              ?>
                                              </span>
                                              <input type="text" name="debit_noteid" id="debit_noteid" class="form-control debit_noteid" value="<?php echo ($_is_draft) ? 'DRAFT' : $_debit_number; ?>" data-isedit="<?php echo $isedit; ?>" data-original-number="<?php echo $data_original_number; ?>" <?php echo ($_is_draft) ? 'disabled' : '' ?>>
                                    </div>
                                    </div>
                                    <?php //echo render_input('receiptsid','ReceiptID',$_credit_number); ?>
                                    
                                </div>
                                
                                <div class="col-md-4" style="margin-top: 19px;padding: 0px;">
                                    <input type="text" name="account_full_name" id="account_full_name" class="form-control">
                                    
                                </div>
                                
                                <div class="col-md-3" style="margin-top: 19px;padding: 0px;">
                                    <input type="text" name="gst_no" id="gst_no" class="form-control">
                                    
                                </div>
                                <div class="col-md-2" style="margin-top: 19px;padding: 0px;">
                                    <input type="text" name="account_bal" id="account_bal" class="form-control">
                                    
                                </div>
                                
                            </div>
                            <!--END First row-->
                            
                            <!--Start Second row-->
                            <div class="row">
                                <div class="col-md-3" style="padding-right: 0px;">
                                    <?php $value = date('Y-m-d');?>
                                    <?php echo render_date_input('credit_note_date','Date',$value); ?>
                                </div>
                                <div class="col-md-4" style="margin-top: 19px;padding: 0px;">
                                    <input type="text" name="account_address" id="account_address" class="form-control">
                                    
                                </div>
                                
                                <div class="col-md-1" style="margin-top: 19px;padding: 0px;">
                                    <input type="text" name="account_state" id="account_state" class="form-control">
                                    
                                </div>
                                <div class="col-md-4" style="margin-top: 19px;padding: 0px;">
                                    <input type="text" name="account_state_name" id="account_state_name" class="form-control">
                                    
                                </div>
                                
                            </div>
                            
                            <!--END Second row-->
                            
                            <!-- Start third row-->
                            <div class="row" style="padding-right: 0px;">
                               
                               <div class="col-md-3" style="padding-right: 0px;">
                                    <div class="form-group">
                                        <label for="act_name">A/c no</label>
                                        <input type="text" name="act_name" id="act_name" class="form-control">
                                        
                                    </div>
                                </div>
                                <div class="col-md-4" style="margin-top: 19px;padding: 0px;">
                                    <input type="text" name="account_address2" id="account_address2" class="form-control">
                                    
                                </div>
                                <div class="col-md-5" style="margin-top: 19px;padding: 0px;">
                                    <input type="text" name="account_station" id="account_station" class="form-control">
                                    
                                </div>
                                
                            </div>
                           
                            <!-- END third row-->
            
                        </div>
                        <div class="col-md-4">
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="radio" id="credit" name="type_select" value="credit" checked>
                                    <label for="credit">Credit</label>
                                    <input type="radio" id="debit" name="type_select" value="debit">
                                    <label for="debit">Debit</label>
                                </div>
                                
                            </div>
                            <div class="row">
                                <div class="col-md-12" style="margin-top: 4%;height: 97px;">
                                    <textarea class="form-control" name="narration" id="narration"></textarea>
                                    <input type="hidden" value="1" name="countof_record" id="countof_record">
                                    <input type="hidden" value="" name="sale_item" id="sale_item">
                                    <?php $value = (isset($sale_return) ? $sale_return->items[0]["TransID"] : ''); ?>
                                    <input type="hidden" value="<?php echo $value; ?>" name="tax_id" id="tax_id">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            
            
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-striped table-bordered" id="data_table" width="100%">
                        <thead>
                            <tr>
                                
                                <th style="width:10%">ITEMID</th>
                                <th style="width:25%">ITEMNAME</th>
                                <th style="width:5%">HSN/SAC</th>
                                <th style="width:5%">Description</th>
                                <th style="width:15%">SalesID</th>
                                <th style="width:5%">Rate</th>
                                <th style="width:5%">CGST%</th>
                                <th style="width:5%">CGSTAmt</th>
                                <th style="width:5%">SGST%</th>
                                <th style="width:5%">SGSTAmt</th>
                                <th style="width:5%">IGST%</th>
                                <th style="width:5%">IGSTAmt</th>
                                <th style="width:5%">Amount</th>
                                <th style="width:5%">Action</th>
                            </tr>
                        </thead>
                        <tbody id="tbody">
                            <tr id="R1">
                                
                                <td style="width:10%"><input type="text" name="act_code" id="item_code" style="width: 100%;border-radius: 2px;height: 30px;"></td>
                                <td style="width:25%" ><span id="item_name"></span><input type="hidden" name="item_name_val" id="item_name_val" value=""></td>
                                <td class="trans1" style="width:5%" ><span id="hsn"></span><input type="hidden" name="hsn_val" id="hsn_val" value=""></td>
                                <td style="width:5%"><span id="hsndesc"></span><input type="hidden" name="hsndesc_val" id="hsndesc_val" value=""></td>
                                <td style="width:15%" ><input type="text" name="sale_id" id="sale_id" value="" style="height: 30px;width: 100%;" /><input type="hidden" name="order_amt" id="order_amt" value=""></td>
                                <td style="width:5%"><input type="text" name="paidamth" id="paidamth" value="" style="height: 30px;width: 100%;" onkeypress="return isNumber(event)" /></td>
                                <td style="width:5%" align="right"><span id="cgst"></span><input type="hidden" name="cgst_per_val" id="cgst_per_val" value=""></td>
                                <td style="width:5%" align="right"><span id="cgstamt"></span><input type="hidden" name="cgst_amt_val" id="cgst_amt_val" value=""></td>
                                <td style="width:5" align="right"><span id="sgst"></span> <input type="hidden" name="sgst_per_val" id="sgst_per_val" value=""></td>
                                <td style="width:5%" align="right"><span id="sgstamt"></span><input type="hidden" name="sgst_amt_val" id="sgst_amt_val" value=""></td>
                                <td style="width:5%" align="right"><span id="igst"></span><input type="hidden" name="igst_per_val" id="igst_per_val" value=""></td>
                                <td style="width:5%" align="right"><span id="igstamt"></span><input type="hidden" name="igst_amt_val" id="igst_amt_val" value=""></td>
                                <td style="width:5%" align="right"><span id="amount"></span><input type="hidden" name="total_amt_val" id="total_amt_val" value=""></td>
                                
                                <td style="width:5%">
                                <button type="button" name="addBtn" id="add" class="btn btn-xs btn-succes add" value="Add"><i class="fa fa-plus-circle " style="font-size:20px;"></i></button>
                                    <!--<a href="#" class="addBtn"  id="addBtn"><i class="fa fa-plus-circle " style="font-size:20px;"></i></a></td>
                            --></tr>
                        </tbody>
                    </table>
                    
                </div>
                
                <div class="col-md-8">
                    <div class="row" style="margin-top:10%">
                        <div class="col-md-7">
                            </div>
                        <div class="col-md-1">
                        
                        <button type="submit" class="btn btn-info"><?php echo _l('submit'); ?></button>
                        </div>
                        <div class="col-md-2">
                        
                        <button type="text" class="btn btn-denger">Cancel</button>
                        </div>
                        <div class="col-md-1">
                            </div>
                    </div>
                        
                    </div>
                <div class="col-md-4">
                    <table class="table text-right">
                        <tr>
                            <td>Gross Amt</td>
                            <td width="30%"><span id="gross_total">0.00</span><input type="hidden" name="gross_total_val" id="gross_total_val" value="0.00"></td>
                        </tr>
                        <tr>
                            <td>CGST Amt</td>
                            <td  width="30%"><span id="cgst_total">0.00</span><input type="hidden" name="cgst_total_val" id="cgst_total_val" value="0.00"></td>
                        </tr>
                        <tr>
                            <td>SGST Amt</td>
                            <td  width="30%"><span id="sgst_total">0.00</span><input type="hidden" name="sgst_total_val" id="sgst_total_val" value="0.00"></td>
                        </tr>
                        <tr>
                            <td>IGST Amt</td>
                            <td  width="30%"><span id="igst_total">0.00</span><input type="hidden" name="igst_total_val" id="igst_total_val" value="0.00"></td>
                        </tr>
                        <tr>
                            <td>Net Amt</td>
                            <td  width="30%"><span id="net_total">0.00</span><input type="hidden" name="net_total_val" id="net_total_val" value="0.00"></td>
                        </tr>
                    </table>
                </div>
                
            </div>
      <?php echo form_close(); ?>
    <?php } ?>
    
        <div class="modal fade" id="sales_item_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">
                            
                        </h4>
                    </div>
                    
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                             
                                <table class="table table-striped table-bordered" id="bill_data" width="100%">
                                    <thead>
                                        <th>FY</th>
                                        <th>SalesID</th>
                                        <th>TransDate</th>
                                        <th>SaleRate</th>
                                        <th>BasicRate</th>
                                        <th>Disc%</th>
                                        <th>DiscAmt</th>
                                        <th>IGST%</th>
                                        <th>CGST%</th>
                                        <th>SGST%</th>
                                        <th>Cases</th>
                                        <th>BilledQty</th>
                                        <th>RtnQty</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                </table>
                            </div>
                    
                    
                        </div>
                    </div>
                    
                </div>
            </div>
          </div>  
  </div>
</div>
</div>
</div>
</div>
</div>

<?php init_tail(); ?>
<style>
    #errmsg
{
color: red;
}
.table>tbody>tr>td, .table>tfoot>tr>td {
    padding: 3px 0px 3px 3px;
}
.table>thead>tr>th{
    padding:4px;
}
table.dataTable thead th, table.dataTable thead td {
    padding: 2px 2px !important;
    
}
table.dataTable tbody  td {
    padding: 3px 3px !important;
    
}
</style>
<!-- Script -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
    
    <!-- jQuery UI -->
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    
 <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->
<script type='text/javascript'>

$(document).ready(function () {
    $("#act_name").focus();
    var rowIdx = 1;
  


$('#tbody').on('click', '.remove', function () {
  
    // Getting all the rows next to the 
    // row containing the clicked button
    var child = $(this).closest('tr').nextAll();
  
    // Iterating across all the rows 
    // obtained to change the index
    child.each(function () {
          
        // Getting <tr> id.
        var id = $(this).attr('id');
  
        // Getting the <p> inside the .row-index class.
        var idx = $(this).children('.row-index').children('p');
  
        // Gets the row number from <tr> id.
        var dig = parseInt(id.substring(1));
  
        // Modifying row index.
        idx.html(`Row ${dig - 1}`);
  
        // Modifying row id.
        $(this).attr('id', `R${dig - 1}`);
    });
    
    var  no = $(this).parents("tr").find('input[name="rownum"]').val();
  var item_code =$(this).parents("tr").find('input[name="item_code'+no+'"]').val();
    //alert(no);
    var gross_total = $("#gross_total_val").val();
    var cgst_total = $("#cgst_total_val").val();
    var sgst_total = $("#sgst_total_val").val();
    var igst_total = $("#igst_total_val").val();
    alert(igst_total);
    var net_total = $("#net_total_val").val();
    
    var act_state = $("#account_state").val();
    
    
    
    var total_amt =$(this).parents("tr").find('input[name="total_amt_val'+no+'"]').val();
    
    //alert(igst_amt);
    if(act_state =="UP"){
        var sgst_amt =$(this).parents("tr").find('input[name="sgst_amt_val'+no+'"]').val();
        var cgst_amt =$(this).parents("tr").find('input[name="cgst_amt_val'+no+'"]').val();
        var sale_total = parseFloat(total_amt) - parseFloat(sgst_amt) - parseFloat(cgst_amt);
        
        sgst_total = parseFloat(sgst_total) - parseFloat(sgst_amt);
        $('#sgst_total').html(parseFloat(sgst_total).toFixed(2));
        $('#sgst_total_val').val(parseFloat(sgst_total).toFixed(2));
                
        cgst_total = parseFloat(cgst_total) + parseFloat(cgst_amt);
        $('#cgst_total').html(parseFloat(cgst_total).toFixed(2));
        $('#cgst_total_val').val(parseFloat(cgst_total).toFixed(2));
    }else{
        
        var igst_amt =$(this).parents("tr").find('input[name="igst_amt_val'+no+'"]').val();
        var sale_total = parseFloat(total_amt) - parseFloat(igst_amt);
        
        igst_total = parseFloat(igst_total) - parseFloat(igst_amt);
        $('#igst_total').html(parseFloat(igst_total).toFixed(2));
        $('#igst_total_val').val(parseFloat(igst_total).toFixed(2));
    }
    
    
    gross_total = parseFloat(gross_total) - parseFloat(sale_total);
    $('#gross_total').html(parseFloat(gross_total).toFixed(2));
    $('#gross_total_val').val(parseFloat(gross_total).toFixed(2));
          
    net_total = parseFloat(net_total) - parseFloat(total_amt);
    $('#net_total').html(parseFloat(net_total).toFixed(2));
    $('#net_total_val').val(parseFloat(net_total).toFixed(2));
  
    // Removing the current row.
    $(this).closest('tr').remove();
  
    // Decreasing the total number of rows by 1.
    rowIdx--;
});


// new code 

$('#data_table').on('click', '.add', function () {
    add_row();
})

function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
}

function add_row()
{
    
 var item_code =document.getElementById("item_code").value;
 var item_name =document.getElementById("item_name_val").value;
 var hsn =document.getElementById("hsn_val").value;
 var hsndesc =document.getElementById("hsndesc_val").value;
 var sale_id =document.getElementById("sale_id").value;
 var order_amt =document.getElementById("order_amt").value;
 var paidamth =document.getElementById("paidamth").value;
 var cgst =document.getElementById("cgst_per_val").value;
 var cgst_amt =document.getElementById("cgst_amt_val").value;
 var sgst =document.getElementById("sgst_per_val").value;
 var sgst_amt =document.getElementById("sgst_amt_val").value;
 var igst =document.getElementById("igst_per_val").value;
 var igst_amt =document.getElementById("igst_amt_val").value;
 var total_amt =document.getElementById("total_amt_val").value;
 var countof_record = document.getElementById("countof_record").value;
	if(item_name !=="" && item_name !==null){
	    
	    var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var html = '';
 html += "<tr id='row"+table_len+"'>";
 html += "<td id='item_code"+table_len+"'>"+item_code+" <input type='hidden' name='item_code"+table_len+"' value='"+item_code+"'></td>";
 html += "<td id='item_name"+table_len+"'>"+item_name+" <input type='hidden' name='item_name_val"+table_len+"' value='"+item_name+"'></td>";
 html += "<td id='hsn"+table_len+"'>"+hsn+" <input type='hidden' name='hsn_val"+table_len+"' value='"+hsn+"'></td>";
 html += "<td id='hsndesc"+table_len+"'>"+hsndesc+" <input type='hidden' name='hsndesc_val"+table_len+"' value='"+hsndesc+"'></td>";
 html += "<td id='sale_id"+table_len+"'>"+sale_id+" <input type='hidden' name='sale_id"+table_len+"' value='"+sale_id+"'><input type='hidden' name='order_amt"+table_len+"' value='"+order_amt+"'></td>";
 html += "<td id='paidamth"+table_len+"' align='right'>"+paidamth+" <input type='hidden' name='paidamth"+table_len+"' value='"+paidamth+"'></td>";
 html += "<td id='cgst"+table_len+"' align='right'>"+cgst+" <input type='hidden' name='cgst_per_val"+table_len+"' value='"+cgst+"'></td>";
 html += "<td id='cgst_amt"+table_len+"' align='right'>"+cgst_amt+" <input type='hidden' name='cgst_amt_val"+table_len+"' value='"+cgst_amt+"'></td>";
 html += "<td id='sgst"+table_len+"' align='right'>"+sgst+" <input type='hidden' name='sgst_per_val"+table_len+"' value='"+sgst+"'></td>";
 html += "<td id='sgst_amt"+table_len+"' align='right'>"+sgst_amt+" <input type='hidden' name='sgst_amt_val"+table_len+"' value='"+sgst_amt+"'></td>";
 html += "<td id='igst"+table_len+"' align='right'>"+igst+" <input type='hidden' name='igst_per_val"+table_len+"' value='"+igst+"'></td>";
 html += "<td id='igst_amt"+table_len+"' align='right'>"+igst_amt+" <input type='hidden' name='igst_amt_val"+table_len+"' value='"+igst_amt+"'></td>";
 html += "<td id='total_amt"+table_len+"' align='right'>"+total_amt+" <input type='hidden' name='total_amt_val"+table_len+"' value='"+total_amt+"'></td>";
 //html += "<td><input type='button' value='Delete' class='remove' ><input type='hidden' name='rownum' id='rownum'></td>";
 html += '<td><button type="button" name="edit" id="remove" class="btn btn-xs btn-danger remove" value="remove"><i class="fa fa-trash " style="font-size:16px;"></i></button><input type="hidden" name="rownum" id="rownum" value="'+countof_record+'"></td>';
 
 html += '</tr>';
 var row = table.insertRow(table_len).outerHTML=html;

 
 
  var countof_record = document.getElementById("countof_record").value;
  var temp1 = parseFloat(countof_record) + parseFloat(1);
 
 document.getElementById("countof_record").value=temp1;
 
 
 var gross_total = $("#gross_total_val").val();
        var cgst_total = $("#cgst_total_val").val();
        var sgst_total = $("#sgst_total_val").val();
        var igst_total = $("#igst_total_val").val();
        var net_total = $("#net_total_val").val();
        var act_state = $("#account_state").val();
        if(act_state == "UP"){
            
            var sale_total = parseFloat(total_amt) - parseFloat(cgst_amt) - parseFloat(sgst_amt);
            
            sgst_total = parseFloat(sgst_total) + parseFloat(sgst_amt);
            $('#sgst_total').html(parseFloat(sgst_total).toFixed(2));
            $('#sgst_total_val').val(parseFloat(sgst_total).toFixed(2));
            
            cgst_total = parseFloat(cgst_total) + parseFloat(cgst_amt);
            $('#cgst_total').html(parseFloat(cgst_total).toFixed(2));
            $('#cgst_total_val').val(parseFloat(cgst_total).toFixed(2));
                
        }else{
            var sale_total = parseFloat(total_amt) - parseFloat(igst_amt);
            igst_total = parseFloat(igst_total) + parseFloat(igst_amt);
            $('#igst_total').html(parseFloat(igst_total).toFixed(2));
                $('#igst_total_val').val(parseFloat(igst_total).toFixed(2));
        }
  
 gross_total = parseFloat(gross_total) + parseFloat(sale_total);
          $('#gross_total').html(parseFloat(gross_total).toFixed(2));
          $('#gross_total_val').val(parseFloat(gross_total).toFixed(2));
          
          net_total = parseFloat(net_total) + parseFloat(total_amt);
          $('#net_total').html(parseFloat(net_total).toFixed(2));
          $('#net_total_val').val(parseFloat(net_total).toFixed(2));
        if($('#ex_sale_return_id').val() == "" || $('#ex_sale_return_id').val() == null){
            
        }  else{
            var new_rec = $('#new_record').val();
            
                new_rec = new_rec +","+ item_code
            
              $('#new_record').val(new_rec);
        }
 
 
 
 
 
document.getElementById("item_code").value="";
document.getElementById("item_name_val").value="";
document.getElementById("hsn_val").value="";
document.getElementById("hsndesc_val").value="";
document.getElementById("sale_id").value="";
document.getElementById("order_amt").value="";
document.getElementById("paidamth").value="";
document.getElementById("cgst_per_val").value="";
document.getElementById("cgst_amt_val").value="";
document.getElementById("sgst_per_val").value="";
document.getElementById("sgst_amt_val").value="";
document.getElementById("igst_per_val").value="";
document.getElementById("igst_amt_val").value="";
document.getElementById("total_amt_val").value="";
document.getElementById("item_name").innerHTML="";
 document.getElementById("hsn").innerHTML="";
 document.getElementById("hsndesc").innerHTML="";
 document.getElementById("cgst").innerHTML="";
 document.getElementById("cgstamt").innerHTML="";
 document.getElementById("sgst").innerHTML="";
 document.getElementById("sgstamt").innerHTML="";
 document.getElementById("igst").innerHTML="";
 document.getElementById("igstamt").innerHTML="";
 document.getElementById("amount").innerHTML="";
 
 document.getElementById("item_code").focus();
	}else{
	    alert("please add proper item..");
	    document.getElementById("item_code").focus();
	}
 
}


        }); 
$(document).ready(function(){
  
    
      
      
    
    $('#receipts_amt').on('keyup', function () {
        
        var balamt_new = $("#balamth").val();
        var ramt = $(this).val();
        var bamt2 = balamt_new - ramt;
        $('#balamt').html(bamt2.toFixed(2));
        
        //$('#balamth').val(bamt2.toFixed(2));
    });  
    
    $('#disc_amt').on('keyup', function () {
        
        var balamt_new = $("#balamth").val();
        var ramt2 = $("#receipts_amt").val();
        var damt = $(this).val();
       if(damt === ''){
           
       }else{
           
           var damt_include = parseFloat(ramt2) + parseFloat(damt);
            //alert(damt_include);
            var bamt3 = balamt_new - damt_include;
            //alert(bamt3);
            $('#balamt').html(bamt3.toFixed(2));
        
            //$('#balamth').val(bamt2.toFixed(2));
       }
        
    });  
    
    // new code
    
    $('input[type=radio][name=type_select]').change(function() {
        if (this.value == 'credit') {
            //alert("credit Thai Gayo Bhai");
            $(".credit_div").css("display","");
            $(".debit_div").css("display","none");
        }
        else if (this.value == 'debit') {
            //alert("debit Thai Gayo");
            $(".credit_div").css("display","none");
            $(".debit_div").css("display","");
        }
    });
    
    
    // Initialize For Account
     $( "#act_name" ).autocomplete({
        
        source: function( request, response ) {
          // Fetch data
          
          $.ajax({
            url: "<?=base_url()?>admin/Cd_notes/accountlist",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data );
            }
          });
        },
        select: function (event, ui) {
          
          
          $('#act_name').val(ui.item.value); // display the selected text
          $('#account_full_name').val(ui.item.label); // display the selected text
          $('#account_address').val(ui.item.address); // display the selected text
          $('#account_address2').val(ui.item.address2); // display the selected text
          $('#account_state').val(ui.item.state); // display the selected text
          $('#account_station').val(ui.item.station); // display the selected text
          $('#gst_no').val(ui.item.gst); // display the selected text
          $('#account_state_name').val(ui.item.state_name); // display the selected text
          get_sale_item(ui.item.value);
            $("#item_code").focus();
            return false;      
            
        }
      });
      
      // Initialize For Account
     $( "#item_code" ).autocomplete({
         
         
        
        source: function( request, response ) {
          // Fetch data
          var act_code = $("#act_name").val(); 
             if(act_code){
                $.ajax({
                    url: "<?=base_url()?>admin/Cd_notes/itemlist",
                    type: 'post',
                    dataType: "json",
                    data: {
                      search: request.term,
                      act_code:act_code,
                    },
                    success: function( data ) {
                      response( data );
                    }
                  });
             }else{
                 alert("please select account first...");
                 $("#act_name").focus();
             }
          
        },
        select: function (event, ui) {
          var act_code = $("#act_name").val(); 
           var sale_item = $("#sale_item").val();
          let sale_item_array = sale_item.split(",");
        if(sale_item_array.includes(ui.item.value)){
        
          $('#item_code').val(ui.item.value); // display the selected text
          $('#item_name').html(ui.item.label); // display the selected text
          $('#item_name_val').val(ui.item.label);
          $('#hsn').html(ui.item.hsn_code); // display the selected text
          $('#hsn_val').val(ui.item.hsn_code);
          var act_state = $("#account_state").val();
          if(act_state == "UP"){
            var cgst = ui.item.tax / 2;
            $('#cgst').html(cgst);
            $('#sgst').html(cgst);
            $('#igst').html("0.00");
            $('#cgst_per_val').val(cgst.toFixed(2));
            $('#sgst_per_val').val(cgst.toFixed(2));
            $('#igst_per_val').val("0.00");
          }else{
            $('#igst').html(ui.item.tax);
            $('#cgst').html("0.00");
            $('#sgst').html("0.00");
            $('#cgst_per_val').val("0.00");
            $('#sgst_per_val').val("0.00");
            $('#igst_per_val').val(ui.item.tax);
          }
          //$('#cgst').html(ui.item.tax); // display the selected text
          $('#hsndesc').html(ui.item.hsndesc); // display the selected text
          $('#hsndesc_val').val(ui.item.hsndesc);
          //$('#account_station').val(ui.item.station); // display the selected text
            $("#sale_id").focus();
            init_model(ui.item.value,act_code);
            return false;  
        }else{
            alert("item not purchased by this party");
            $("#item_code").focus();
            return false;
        }
            
        }
      });
      
      $('#paidamth').on('blur', function () {
        
        
        var pamt = $('#paidamth').val();
        var order_amt = $('#order_amt').val();
        order_amt = parseFloat(order_amt);
        pamt = parseFloat(pamt);
        if(pamt > order_amt){
            alert("please enter amount should be less than order amount");
            
            //$('#total_amt_val').val('0.00');
            $('#paidamth').val('');
            $('#paidamth').focus();
        }else{
            
            var act_state = $("#account_state").val();
        var gross_total = $("#gross_total_val").val();
        var cgst_total = $("#cgst_total_val").val();
        var sgst_total = $("#sgst_total_val").val();
        var igst_total = $("#igst_total_val").val();
        var net_total = $("#net_total_val").val();
          if(act_state == "UP"){
              var cgst_per = $("#cgst_per_val").val();
              var tax_amt = pamt * (cgst_per / 100);
              $('#cgstamt').html(parseFloat(tax_amt).toFixed(2));
              $('#cgst_amt_val').val(parseFloat(tax_amt).toFixed(2));
              $('#sgstamt').html(parseFloat(tax_amt).toFixed(2));
              $('#sgst_amt_val').val(parseFloat(tax_amt).toFixed(2));
              
                $('#igstamt').html("0.00");
                $('#igst_amt_val').val("0.00");
                
                /*cgst_total = parseFloat(cgst_total) + parseFloat(tax_amt);
                $('#cgst_total').html(parseFloat(cgst_total).toFixed(2));
                $('#cgst_total_val').val(parseFloat(cgst_total).toFixed(2));
                
                sgst_total = parseFloat(sgst_total) + parseFloat(tax_amt);
                $('#sgst_total').html(parseFloat(sgst_total).toFixed(2));
                $('#sgst_total_val').val(parseFloat(sgst_total).toFixed(2));*/
            
          }else{
            var igst_per = $("#igst_per_val").val();  
            var tax_amt = pamt * (igst_per / 100);
            $('#igstamt').html(parseFloat(tax_amt).toFixed(2));
            $('#igst_amt_val').val(parseFloat(tax_amt).toFixed(2));
            
                $('#cgstamt').html("0.00");
              $('#cgst_amt_val').val("0.00");
              $('#sgstamt').html("0.00");
              $('#sgst_amt_val').val("0.00");
              
                /*igst_total = parseFloat(igst_total) + parseFloat(tax_amt);
                $('#igst_total').html(parseFloat(igst_total).toFixed(2));
                $('#igst_total_val').val(parseFloat(igst_total).toFixed(2));*/
          }
          
          var grand_amt = parseFloat(pamt) + parseFloat(tax_amt);
          $('#amount').html(parseFloat(grand_amt).toFixed(2));
          $('#total_amt_val').val(parseFloat(grand_amt).toFixed(2));
          
          //summery calculation
          
          /*gross_total = parseFloat(gross_total) + parseFloat(pamt);
          $('#gross_total').html(parseFloat(gross_total).toFixed(2));
          $('#gross_total_val').val(parseFloat(gross_total).toFixed(2));
          
          net_total = parseFloat(net_total) + parseFloat(grand_amt);
          $('#net_total').html(parseFloat(net_total).toFixed(2));
          $('#net_total_val').val(parseFloat(net_total).toFixed(2));*/
          //$('#paidamth').focus();
        }
        
        
           
    }); 
    
    
      // Initialize For Pending Bill
     /*$( "#sale_id" ).autocomplete({
        
        
        source: function( request, response ) {
          // Fetch data
          var item_code = $("#item_code").val();
          var accountId = $("#act_name").val();
          $.ajax({
            url: "<?=base_url()?>admin/Cd_notes/transaction_list",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term,
              accountId: accountId,
              item_code: item_code,
            },
            success: function( data ) {
              response( data );
            }
          });
        },
        select: function (event, ui) {
          
          if(ui.item.label == "Rocord not fount"){
              alert("this iten is not billed");
              $("#item_name").html("");
              $("#item_name_val").val("");
              $("#hsn").html("");
              $("#hsn_val").val("");
              $("#hsndesc").html("");
              $("#hsndesc_val").val("");
              $("#sale_id").val("");
            $("#item_code").focus();
                return false;
          }else{
              
              $('#sale_id').val(ui.item.label); // display the selected text
                $('#order_amt').val(ui.item.order_amt); // display the selected text
         
                $("#paidamth").focus();
                return false;
          }
              
          
        }
      });*/
    
    function get_sale_item(account_id){
        
    $.ajax({
            url: "<?=base_url()?>admin/sale_return/get_sale_item",
            type: 'post',
            dataType: "json",
            data: {
              
              account_id: account_id,
            },
            success: function( data ) {
              $('#sale_item').val(data);
              //return data.TransID;
              //die();
            }
          });
          //alert(ss);
    }    
    
    function init_model(item_code,act_code){
        //alert(value);
        
        
        // If id found get the text from the datatable
        if (typeof (item_code) !== 'undefined') {
            var $itemModal = $('#sales_item_modal');
            var html = '';
            
            requestGetJSON('cd_notes/get_bill_id/' + item_code +"/"+ act_code).done(function (response) {
                $.each(response, function (column, value) {
                    
                    
                    html +='<tr>';
                    html +='<td align="center">'+value.FY+'</td>';
                    html +='<td align="center"><input type="hidden" name="bill_id">'+value.TransID+'</td>';
                    html +='<td align="center">'+value.TransDate.substring(0, 10)+'</td>';
                    html +='<td align="right">'+value.SaleRate+'</td>';
                    html +='<td align="right">'+value.BasicRate+'</td>';
                    html +='<td align="right">'+value.DiscPerc+'</td>';
                    html +='<td align="right">'+value.DiscAmt+'</td>';
                    html +='<td align="right">'+value.igst+'</td>';
                    html +='<td align="right">'+value.cgst+'</td>';
                    html +='<td align="right">'+value.sgst+'</td>';
                    var cases1 = value.BilledQty / value.CaseQty;
                    html +='<td align="right">'+cases1+'</td>';
                    html +='<td align="right">'+value.BilledQty+'</td>';
                    html +='<td align="right">'+value.rtnqty+'</td>';
                    html +='<td align="right">'+value.NetChallanAmt+'</td>';
                    
                    html +='<td align="center"><button type="button" class="btn btn-info" onclick="get_bill_details(\''+value.TransID+'\')">Select</button></td>';
                    html +='</tr>';
                });
                
                $itemModal.find('tbody').html(html);
            });
            $('#sales_item_modal').modal('show');
        }
    }
  
});
</script>

<script>
    function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
    }
    
    
    

    function get_bill_details(bill_id){
        //alert(bill_id);
        var $data_table = $('#data_table');
        var added_trn_id = $("#tax_id").val();
        //alert(added_trn_id);
        var item_code = $("#item_code").val();
        var hsn_code = $("#hsn_val").val();
        var count_record = $("#countof_record").val();
        
        if(added_trn_id == bill_id || added_trn_id == "" || added_trn_id == null){
            
            
        requestGetJSON('cd_notes/get_bill_detail/'+ hsn_code +'/'+ bill_id+'/'+item_code).done(function (response) {
            
                $data_table.find('input[name="sale_id"]').val(response.TransID);
                if(count_record > 1){
                    var new_amt = response.sum_amt;
                    for (let i = 1; i < count_record; i++) {
                        
                        var new_hsn_code = $data_table.find('input[name="hsn_val'+i+'"]').val();
                        
                      if(hsn_code == new_hsn_code){
                          
                          
                          var new_order_paidamth = $data_table.find('input[name="paidamth'+i+'"]').val();
                          
                          //var new_amt = response.sum_amt - parseFloat(new_order_paidamth);
                          new_amt = new_amt - parseFloat(new_order_paidamth);
                      }
                    }
                    
                    $data_table.find('input[name="order_amt"]').val(new_amt);
                    
                }else{
                    $data_table.find('input[name="order_amt"]').val(response.sum_amt);
                }
                
                
               
                $('#tax_id').val(response.TransID);
                $('#sales_item_modal').modal('hide');
                $data_table.find('input[name="paidamth"]').focus();
            
            
        })
        
        }else{
                $('#sales_item_modal').modal('hide');
                alert("Single SalesID with multiple GST% is only accepted");
                $data_table.find('input[name="item_name_val"]').val('');
                $data_table.find('input[name="hsn_val"]').val('');
                $data_table.find('input[name="hsndesc_val"]').val('');
                $data_table.find('input[name="sale_id"]').val('');
                $data_table.find('input[name="cgst_per_val"]').val('');
                $data_table.find('input[name="sgst_per_val"]').val('');
                $data_table.find('input[name="igst_per_val"]').val('');
                
                $data_table.find('#item_name').html('');
                $data_table.find('#hsn').html('');
                $data_table.find('#hsndesc').html('');
                $data_table.find('#cgst').html('');
                $data_table.find('#sgst').html('');
                $data_table.find('#igst').html('');
                $("#item_code").focus();
                
            }
        
    }
</script>

</body>
</html>
