<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Sale_reports_model extends App_Model
{
    
    public function __construct()
    {
        parent::__construct(); 
    }

   public function get_company_detail()
     {  
         
        $selected_company = $this->session->userdata('root_company');
      
        
        $sql ='SELECT '.db_prefix().'rootcompany.*
        FROM '.db_prefix().'rootcompany WHERE id = '.$selected_company;
        
        
        $result = $this->db->query($sql)->row();
        
        return $result;
        
       
     }
     
     public function load_data($data)
     {  
         $from_date = to_sql_date($data["from_date"]);
         $to_date = to_sql_date($data["to_date"]);
        $fy = $this->session->userdata('finacial_year');
        $selected_company = $this->session->userdata('root_company');
      
        $sql1 = '('.db_prefix().'salesmaster.Transdate BETWEEN "'.$from_date.' 00:00:00" AND "'.$to_date.' 23:59:59")  ORDER BY ChallanID ASC';
        
        $sql ='SELECT '.db_prefix().'salesmaster.*,  
        (SELECT GROUP_CONCAT(company SEPARATOR ",") FROM '.db_prefix().'clients WHERE '.db_prefix().'clients.AccountID = '.db_prefix().'salesmaster.AccountID AND '.db_prefix().'clients.PlantID = '.$selected_company.') as AccountName, 
        (SELECT GROUP_CONCAT(StationName SEPARATOR ",") FROM '.db_prefix().'clients WHERE '.db_prefix().'clients.AccountID = '.db_prefix().'salesmaster.AccountID AND '.db_prefix().'clients.PlantID = '.$selected_company.') as StationName, 
        (SELECT COUNT(OrderID) FROM '.db_prefix().'ordermaster WHERE '.db_prefix().'ordermaster.ChallanID = '.db_prefix().'salesmaster.ChallanID AND '.db_prefix().'ordermaster.PlantID = '.$selected_company.') as Count_number, 
        (SELECT SUM(OrderAmt) FROM '.db_prefix().'ordermaster WHERE '.db_prefix().'ordermaster.ChallanID = '.db_prefix().'salesmaster.ChallanID AND '.db_prefix().'ordermaster.PlantID = '.$selected_company.') as Total_number
        FROM '.db_prefix().'salesmaster WHERE '.$sql1;
        
        /*echo $sql;
        die;*/
        $result = $this->db->query($sql)->result_array();
        
        return $result;
        
     }
     
    public function get_sale_item_group2($data)
     {  
        $from_date = to_sql_date($data["from_date"]);
         $to_date = to_sql_date($data["to_date"]);
         
         
        $fy = $this->session->userdata('finacial_year');
        $selected_company = $this->session->userdata('root_company');
      
        $sql1 = '(Transdate BETWEEN "'.$from_date.' 00:00:00" AND "'.$to_date.' 23:59:59")';
        
        //$sql1 .= ' AND OrderStatus ="O" AND PlantID = "'.$selected_company.'" AND FY = "'.$fy.'"';
        $sql1 .= ' AND PlantID = "'.$selected_company.'" AND FY = "'.$fy.'"';
        
        $sql ='SELECT '.db_prefix().'salesmaster.* FROM '.db_prefix().'salesmaster WHERE '.$sql1;
        
        $result = $this->db->query($sql)->result_array();
        if(empty($result)){
            return $result;
        }
        
        $order_ids = array();
        $item_ids = array();
        foreach ($result as $key => $value) {
               # code...
               array_push($order_ids, $value["OrderID"]);
            }
        
        if(empty($order_ids)){
            
        }else{
        
        $this->db->select('*');
      $this->db->from(db_prefix() . 'history');
      $this->db->where(db_prefix() . 'history.PlantID', $selected_company);
      $this->db->where(db_prefix() . 'history.FY', $fy);
      //$this->db->where_in("$order_ids");
      $this->db->where_in('OrderID',$order_ids);
      $result2 = $this->db->get()->result_array();

        foreach ($result2 as $key2 => $value2) {
               # code...
               array_push($item_ids, $value2["ItemID"]);
            }
        $item_ids_uniqu = array_unique($item_ids);
        
        $this->db->select('*');
      $this->db->from(db_prefix() . 'items');
      $this->db->where(db_prefix() . 'items.PlantID', $selected_company);
      $this->db->where(db_prefix() . 'items.isactive', "Y");
      $this->db->where_in('item_code',$item_ids_uniqu);
      $result3 = $this->db->get()->result_array();
        
        $item_group_ids = array();
        foreach ($result3 as $key3 => $value3) {
               # code...
               array_push($item_group_ids, $value3["subgroup_id"]);
            }
        $item_group_ids_uniqu = array_unique($item_group_ids);
        
        $this->db->select('*');
      $this->db->from(db_prefix() . 'items_sub_groups');
      //$this->db->where(db_prefix() . 'items_groups.PlantID', $selected_company);
      
      $this->db->where_in('id',$item_group_ids_uniqu);
      $result4 = $this->db->get()->result_array();
        
        return $result4;
        }
     }
     
    
    public function get_itemdetails_for_body_data($AccountId,$filterdata)
     { 
        $from_date = to_sql_date($filterdata["from_date"]);
        $to_date = to_sql_date($filterdata["to_date"]);
        $fy = $this->session->userdata('finacial_year');
        $selected_company = $this->session->userdata('root_company');
        $report_type = $filterdata["report_type"];
        
        $sql = 'SELECT SUM(NetChallanAmt) as amt_sum,AccountID,ItemID,SUM(tblhistory.BilledQty / tblhistory.CaseQty) AS sumcases,SUM(tblhistory.BilledQty) AS sumunit  FROM `tblhistory` WHERE TransDate2 BETWEEN "'.$from_date.' 00:00:00" AND "'.$to_date.' 23:59:59" AND AccountID IN('.$AccountId.') AND PlantID = '.$selected_company.' AND FY = "'.$fy.'"';
        if($report_type == "freshrtn"){
            $sql .= ' AND tblhistory.TType ="R" AND TType2="Fresh"';
        }elseif($report_type == "damage"){
            $sql .= ' AND tblhistory.TType ="R" AND TType2="Damage"';
        }elseif($report_type == "netsales"){
            //$sql .= ' AND tblhistory.TType ="R" AND TType2="Damage"';
        }elseif($report_type == "sales"){
            $sql .= ' AND tblhistory.TType ="O" AND TType2="Order"';
        }else{
            
        }
        $sql .= ' GROUP BY ItemID,AccountID';
        $result = $this->db->query($sql)->result_array();
        return $result;
    }
    
    public function get_itemdetails_for_footer_data($AccountId,$filterdata)
     { 
        $from_date = to_sql_date($filterdata["from_date"]);
        $to_date = to_sql_date($filterdata["to_date"]);
        $fy = $this->session->userdata('finacial_year');
        $selected_company = $this->session->userdata('root_company');
        $report_type = $filterdata["report_type"];
        
        $sql = 'SELECT SUM(NetChallanAmt) as amt_sum,AccountID,ItemID,SUM(tblhistory.BilledQty / tblhistory.CaseQty) AS sumcases,SUM(tblhistory.BilledQty) AS sumunit FROM `tblhistory` WHERE TransDate2 BETWEEN "'.$from_date.' 00:00:00" AND "'.$to_date.' 23:59:59" AND AccountID IN('.$AccountId.') AND PlantID = '.$selected_company.' AND FY = "'.$fy.'"';
        if($report_type == "freshrtn"){
            $sql .= ' AND tblhistory.TType ="R" AND TType2="Fresh"';
        }elseif($report_type == "damage"){
            $sql .= ' AND tblhistory.TType ="R" AND TType2="Damage"';
        }elseif($report_type == "netsales"){
            //$sql .= ' AND tblhistory.TType ="R" AND TType2="Damage"';
        }elseif($report_type == "sales"){
            $sql .= ' AND tblhistory.TType ="O" AND TType2="Order"';
        }else{
            
        }
        $sql .= ' GROUP BY ItemID';
        $result = $this->db->query($sql)->result_array();
        return $result;
    }
    
    
     public function get_orders_itemlist_new($filterdata,$item_group)
     {
        $from_date = to_sql_date($filterdata["from_date"]);
        $to_date = to_sql_date($filterdata["to_date"]); 
        $loc_type = $filterdata["loc_type"];
        $states = $filterdata["states"];
        $client_type = $filterdata["client_type"];
        $report_type = $filterdata["report_type"];
        $fy = $this->session->userdata('finacial_year');
        $selected_company = $this->session->userdata('root_company');
        
        $sql = 'SELECT tblsalesmaster.OrderID, tblhistory.ItemID,tblitems.description,tblhistory.AccountID,tblclients.StationName FROM `tblsalesmaster`
INNER JOIN tblhistory ON tblsalesmaster.OrderID=tblhistory.OrderID AND tblsalesmaster.PlantID = tblhistory.PlantID AND tblsalesmaster.FY = tblhistory.FY
INNER JOIN tblitems ON tblitems.item_code=tblhistory.ItemID AND tblitems.PlantID = tblhistory.PlantID';
if($states || $client_type){
     $sql .= ' INNER JOIN tblclients ON tblclients.AccountID=tblsalesmaster.AccountID AND tblclients.PlantID = tblsalesmaster.PlantID';
}else{
    $sql .= ' INNER JOIN tblclients ON tblclients.AccountID=tblsalesmaster.AccountID AND tblclients.PlantID = tblsalesmaster.PlantID';
}
if($loc_type){
     $sql .= ' INNER JOIN tblaccountlocations ON tblsalesmaster.AccountID=tblaccountlocations.AccountID AND tblsalesmaster.PlantID = tblaccountlocations.PlantID';
}
$sql .= ' WHERE tblsalesmaster.PlantID = '.$selected_company.' AND tblsalesmaster.FY = "'.$fy.'" AND tblsalesmaster.Transdate BETWEEN "'.$from_date.' 00:00:00" AND "'.$to_date.' 23:59:59" AND tblitems.subgroup_id IN('.$item_group.') AND tblhistory.BillID IS NOT NULL AND tblhistory.NetChallanAmt !=0.00';
/*if($loc_type == "3"){}else{
$sql .= ' AND tblsalesmaster.AccountID IN (SELECT AccountID FROM tblaccountlocations WHERE LocationTypeID ="'.$loc_type.'")';
 
}*/

if($loc_type == "3"){
    $sql .= ' AND tblaccountlocations.LocationTypeID IN(1,2)';
}else{
    $sql .= ' AND tblaccountlocations.LocationTypeID = '.$loc_type;
}
if($states){
    $sql .= ' AND tblclients.state ="'.$states.'"';
}
if($client_type){
    $sql .= ' AND tblclients.DistributorType ="'.$client_type.'"';
}


$sql .= ' GROUP BY tblhistory.ItemID,tblhistory.AccountID ORDER BY tblclients.StationName ASC';
        $result = $this->db->query($sql)->result_array();
        return $result;
         
     }
     
   
    public function get_commulative_data($data)
     {  
        $from_date = to_sql_date($data["from_date"]);
         $to_date = to_sql_date($data["to_date"]);
         
        $fy = $this->session->userdata('finacial_year');
        $selected_company = $this->session->userdata('root_company');
      
        $sql1 = '(Transdate2 BETWEEN "'.$from_date.' 00:00:00" AND "'.$to_date.' 23:59:59")';
        
        $sql1 .= ' AND OrderStatus ="C" AND PlantID = "'.$selected_company.'" AND FY = "'.$fy.'"';
        
        $sql ='SELECT '.db_prefix().'ordermaster.* FROM '.db_prefix().'ordermaster WHERE '.$sql1;
        
        $result = $this->db->query($sql)->result_array();
        if(empty($result)){
            return $result;
        }
        
        $order_ids = array();
        $item_ids = array();
        foreach ($result as $key => $value) {
               # code...
               array_push($order_ids, $value["OrderID"]);
            }
        
        $this->db->select('ItemID,description');
      $this->db->from(db_prefix() . 'history');
      $this->db->where(db_prefix() . 'history.PlantID', $selected_company);
      $this->db->where(db_prefix() . 'history.FY', $fy);
      //$this->db->where_in("$order_ids");
      $this->db->distinct();
      $this->db->where_in('OrderID',$order_ids);
      $result2 = $this->db->get()->result_array();
        return $result2;
        
     }
     
    public function get_body_commulative_data($data)
     {  
        $from_date = $data["from_date"];
         $to_date = $data["to_date"];
         
        $fy = $this->session->userdata('finacial_year');
        $selected_company = $this->session->userdata('root_company');
      
        $sql1 = '(date BETWEEN "'.$from_date.' 00:00:00" AND "'.$to_date.' 23:59:59")';
        
        $sql1 .= ' AND OrderStatus ="C" AND PlantID = "'.$selected_company.'" AND FY = "'.$fy.'"';
        
        $sql ='SELECT '.db_prefix().'ordermaster.* FROM '.db_prefix().'ordermaster WHERE '.$sql1;
        
        $result = $this->db->query($sql)->result_array();
        if(empty($result)){
            return $result;
        }
        
        $order_ids = array();
        $item_ids = array();
        foreach ($result as $key => $value) {
               # code...
               array_push($order_ids, $value["OrderID"]);
            }
        
        $this->db->select('ItemID,description');
      $this->db->from(db_prefix() . 'history');
      $this->db->where(db_prefix() . 'history.PlantID', $selected_company);
      $this->db->where(db_prefix() . 'history.FY', $fy);
      //$this->db->where_in("$order_ids");
      $this->db->distinct();
      $this->db->where_in('OrderID',$order_ids);
      $result2 = $this->db->get()->result_array();
        return $result2;
        
     }
     
     //-----------------------------------------------------
  public function get_reported_by_staff($id){
      
    
        $this->db->select('*');
       $this->db->where('job_position', $id);
       $records = $this->db->get(db_prefix() . 'staff')->result();
       return $records;
  }
  
   //-----------------------------------------------------
  public function get_state_name($state_id){
      
    
        $this->db->select('state_name');
       $this->db->where('id', $state_id);
       $state_name = $this->db->get(db_prefix() . 'xx_statelist')->row();
       return $state_name;
  }
  
  //-----------------------------------------------------
  public function get_client_type_name($client_type){
      
  $selected_company = $this->session->userdata('root_company');
        $this->db->select('name');
        $this->db->where('id', $client_type);
        $this->db->where('PlantID', $selected_company);
        $client_type_name = $this->db->get(db_prefix() . 'customers_groups')->row();
       return $client_type_name;
  }
  
  //-----------------------------------------------------
  public function get_item_group_name($item_group){
      
      $item_group_array = explode(",",$item_group);
        $this->db->select('name');
        $this->db->where_in('id', $item_group_array);
        $item_group_names = $this->db->get(db_prefix() . 'items_sub_groups')->result_array();
        $item_group_name = array();
        foreach ($item_group_names as $key => $value) {
    # code...
        array_push($item_group_name, $value["name"]);
      }
      $item_group_name_s = implode(", ", $item_group_name);
       return $item_group_name_s;
  }
   
}
